@echo off
setlocal enabledelayedexpansion
title FleetTrack Pro
color 0B

echo.
echo  ============================================================
echo    FleetTrack Pro - Vehicle Inspection Management System
echo  ============================================================
echo.

:: Get the directory of this bat file (no trailing backslash)
set ROOT=%~dp0
set ROOT=%ROOT:~0,-1%

set BACKEND=%ROOT%\backend
set FRONTEND=%ROOT%\frontend

echo  App folder: %ROOT%
echo.

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Node.js not found. Download from https://nodejs.org
    pause
    exit /b 1
)
echo  [OK] Node.js found.

:: Install backend dependencies
if not exist "%BACKEND%\node_modules\express" (
    echo  [SETUP] Installing backend packages - please wait...
    cd /d %BACKEND%
    call npm install
    if errorlevel 1 (
        echo  [ERROR] Backend install failed!
        pause
        exit /b 1
    )
    echo  [OK] Backend ready.
) else (
    echo  [OK] Backend packages present.
)

:: Install frontend dependencies
if not exist "%FRONTEND%\node_modules\vite" (
    echo  [SETUP] Installing frontend packages - please wait...
    cd /d %FRONTEND%
    call npm install
    if errorlevel 1 (
        echo  [ERROR] Frontend install failed!
        pause
        exit /b 1
    )
    echo  [OK] Frontend ready.
) else (
    echo  [OK] Frontend packages present.
)

:: Database setup
cd /d %BACKEND%
if not exist "%BACKEND%\prisma\fleet.db" (
    echo  [SETUP] Creating database...
    call npx prisma generate
    call npx prisma migrate deploy
    if errorlevel 1 (
        call npx prisma migrate dev --name init
    )
    echo  [SETUP] Seeding sample data...
    call node src\seed.js
    echo  [OK] Database created.
) else (
    echo  [OK] Database found.
)

:: Clear ports
echo  [..] Clearing ports...
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":3001 "') do taskkill /f /pid %%a >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":5173 "') do taskkill /f /pid %%a >nul 2>&1

:: Start backend
echo  [>>] Starting backend server...
cd /d %BACKEND%
start "FleetTrack-Backend" cmd /k "node src\index.js"
timeout /t 4 /nobreak >nul

:: Start frontend
echo  [>>] Starting frontend...
cd /d %FRONTEND%
start "FleetTrack-Frontend" cmd /k "npm run dev"
timeout /t 7 /nobreak >nul

:: Open browser
echo  [>>] Opening browser...
start "" http://localhost:5173

echo.
echo  ============================================================
echo   FleetTrack Pro is RUNNING
echo  ============================================================
echo   Browser: http://localhost:5173
echo   Login:   admin / admin123
echo.
echo   Keep this window open. Press any key to STOP the app.
echo  ============================================================
echo.
pause >nul

:: Shutdown
echo  Shutting down...
taskkill /f /fi "WINDOWTITLE eq FleetTrack-Backend*" >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq FleetTrack-Frontend*" >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":3001 "') do taskkill /f /pid %%a >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":5173 "') do taskkill /f /pid %%a >nul 2>&1
echo  Stopped. Goodbye!
timeout /t 2 /nobreak >nul
