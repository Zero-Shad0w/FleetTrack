import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Truck, Wrench, Shield, ClipboardCheck,
  FileText, History, LogOut, Menu, X, Moon, Sun,
  Users, Database, User, UserCheck, Palette
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useBranding } from '../../context/BrandingContext';
import { useDarkMode } from '../../context/DarkModeContext';

const roleColors = {
  admin:       'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
  inspector:   'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  coordinator: 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300',
  manager:     'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300',
  viewer:      'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
};

const roleLabels = {
  admin: 'Admin', inspector: 'Inspector', coordinator: 'Coordinator',
  manager: 'Manager', viewer: 'Viewer',
};

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout, canAccessVehicles, canAccessEmployees, canManageUsers, canManageBackup } = useAuth();
  const { branding } = useBranding();
  const { dark, toggle } = useDarkMode();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/login'); };

  const NavItem = ({ to, icon: Icon, label, end = false }) => (
    <NavLink to={to} end={end}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
          isActive
            ? 'bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400'
            : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'
        }`}
      onClick={() => setSidebarOpen(false)}>
      <Icon className="w-4 h-4 flex-shrink-0" />{label}
    </NavLink>
  );

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-950 overflow-hidden">
      {sidebarOpen && <div className="fixed inset-0 z-20 bg-black/40 md:hidden" onClick={() => setSidebarOpen(false)} />}

      <aside className={`fixed md:static inset-y-0 left-0 z-30 w-64 flex flex-col bg-white dark:bg-gray-900 border-r border-gray-100 dark:border-gray-800 transform transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100 dark:border-gray-800">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden" style={{ background: branding.logoData ? 'transparent' : branding.primaryColor || '#2563eb' }}>
            {branding.logoData
              ? <img src={branding.logoData} alt="Logo" className="w-full h-full object-contain p-0.5" />
              : <Truck className="w-5 h-5 text-white" />
            }
          </div>
          <div>
            <div className="text-sm font-bold text-gray-900 dark:text-white leading-tight">{branding.softwareName || 'FleetTrack'}</div>
            <div className="text-xs text-gray-400">Pro Edition</div>
          </div>
          <button className="ml-auto md:hidden" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
          <NavItem to="/" icon={LayoutDashboard} label="Dashboard" end />

          {/* Vehicle section — hidden from coordinator */}
          {canAccessVehicles && (
            <>
              <div className="pt-3 pb-1 px-3">
                <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Fleet</span>
              </div>
              <NavItem to="/vehicles"    icon={Truck}          label="Vehicles" />
              <NavItem to="/repairs"     icon={Wrench}         label="Repairs & Parts" />
              <NavItem to="/damage"      icon={Shield}         label="Damage Inspection" />
              <NavItem to="/equipment"   icon={ClipboardCheck} label="Equipment Check" />
              <NavItem to="/weekly-logs" icon={FileText}       label="Weekly Logs" />
              <NavItem to="/history"     icon={History}        label="Vehicle History" />
            </>
          )}

          {/* Employee section — hidden from inspector */}
          {canAccessEmployees && (
            <>
              <div className="pt-3 pb-1 px-3">
                <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">People</span>
              </div>
              <NavItem to="/employees" icon={UserCheck} label="Employees" />
            </>
          )}

          {/* Admin section */}
          {(canManageUsers || canManageBackup) && (
            <>
              <div className="pt-3 pb-1 px-3">
                <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Admin</span>
              </div>
              {canManageUsers  && <NavItem to="/admin/users"     icon={Users}    label="User Management" />}
              {canManageBackup && <NavItem to="/admin/backup"    icon={Database} label="Backup & Restore" />}
              {canManageUsers  && <NavItem to="/admin/branding"  icon={Palette}  label="Branding" />}
            </>
          )}
        </nav>

        {/* User */}
        <div className="p-3 border-t border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-gray-50 dark:bg-gray-800">
            <div className="w-8 h-8 bg-brand-100 dark:bg-brand-900/50 rounded-lg flex items-center justify-center flex-shrink-0">
              <User className="w-4 h-4 text-brand-600 dark:text-brand-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{user?.username}</div>
              <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${roleColors[user?.role] || roleColors.viewer}`}>
                {roleLabels[user?.role] || user?.role}
              </span>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-14 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 flex items-center px-4 gap-4 flex-shrink-0">
          <button className="md:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
          <div className="flex-1" />
          <button onClick={toggle} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            {dark ? <Sun className="w-4 h-4 text-yellow-400" /> : <Moon className="w-4 h-4 text-gray-500" />}
          </button>
          <button onClick={handleLogout} className="flex items-center gap-2 px-3 py-1.5 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </header>
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
