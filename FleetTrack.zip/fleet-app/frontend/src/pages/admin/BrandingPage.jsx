import React, { useState, useEffect, useRef } from 'react';
import { Upload, X, Save, RefreshCw, Eye, Palette, Type, Image, Check, Loader2 } from 'lucide-react';
import { PageHeader } from '../../components/ui';
import { useBranding, extractColorsFromImage } from '../../context/BrandingContext';
import { useToast } from '../../context/ToastContext';

const COLOR_PRESETS = [
  { name: 'Ocean Blue',   primary: '#2563eb', secondary: '#1d4ed8', accent: '#3b82f6', sidebar: '#ffffff', darkPrimary: '#3b82f6', darkSidebar: '#0f172a' },
  { name: 'Forest Green', primary: '#16a34a', secondary: '#15803d', accent: '#22c55e', sidebar: '#ffffff', darkPrimary: '#22c55e', darkSidebar: '#0f1f0f' },
  { name: 'Crimson Red',  primary: '#dc2626', secondary: '#b91c1c', accent: '#ef4444', sidebar: '#ffffff', darkPrimary: '#ef4444', darkSidebar: '#1f0f0f' },
  { name: 'Royal Purple', primary: '#7c3aed', secondary: '#6d28d9', accent: '#8b5cf6', sidebar: '#ffffff', darkPrimary: '#8b5cf6', darkSidebar: '#1a0f2e' },
  { name: 'Sunset Orange',primary: '#ea580c', secondary: '#c2410c', accent: '#f97316', sidebar: '#ffffff', darkPrimary: '#f97316', darkSidebar: '#1f1008' },
  { name: 'Slate Dark',   primary: '#475569', secondary: '#334155', accent: '#64748b', sidebar: '#f8fafc', darkPrimary: '#94a3b8', darkSidebar: '#0f172a' },
  { name: 'Teal',         primary: '#0d9488', secondary: '#0f766e', accent: '#14b8a6', sidebar: '#ffffff', darkPrimary: '#14b8a6', darkSidebar: '#0f1f1e' },
  { name: 'Pink',         primary: '#db2777', secondary: '#be185d', accent: '#ec4899', sidebar: '#ffffff', darkPrimary: '#ec4899', darkSidebar: '#1f0f18' },
];

export default function BrandingPage() {
  const { branding, updateBranding, removeLogo, loadBranding } = useBranding();
  const toast   = useToast();
  const fileRef = useRef();

  const [form, setForm] = useState({ ...branding });
  const [extracting, setExtracting] = useState(false);
  const [saving, setSaving]         = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [tab, setTab] = useState('logo'); // logo | colors | name

  useEffect(() => { setForm({ ...branding }); }, [branding]);

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Please upload an image file'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Logo must be under 5MB'); return; }

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const dataUrl = ev.target.result;
      setForm(f => ({ ...f, logoData: dataUrl }));

      // Auto-extract colors
      setExtracting(true);
      toast.info('Extracting colors from logo...');
      try {
        const colors = await extractColorsFromImage(dataUrl);
        if (colors) {
          setForm(f => ({
            ...f,
            logoData: dataUrl,
            primaryColor:   colors.primary,
            secondaryColor: colors.darker,
            accentColor:    colors.lighter,
            darkPrimary:    colors.lighter,
          }));
          toast.success('Colors extracted from logo! Review and save.');
        }
      } catch { /* use default colors */ }
      finally { setExtracting(false); }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const applyPreset = (preset) => {
    setForm(f => ({ ...f, ...preset }));
    toast.info(`Applied ${preset.name} preset`);
  };

  const handleSave = async () => {
    if (!form.softwareName?.trim()) return toast.error('Software name cannot be empty');
    setSaving(true);
    try {
      await updateBranding(form);
      toast.success('Branding saved and applied!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Save failed');
    } finally { setSaving(false); }
  };

  const handleRemoveLogo = async () => {
    try {
      await removeLogo();
      setForm(f => ({ ...f, logoData: null }));
      toast.success('Logo removed');
    } catch { toast.error('Failed to remove logo'); }
  };

  const handleReset = async () => {
    const defaults = {
      softwareName: 'FleetTrack Pro', primaryColor: '#2563eb', secondaryColor: '#1d4ed8',
      accentColor: '#3b82f6', sidebarColor: '#ffffff', textColor: '#111827',
      darkPrimary: '#3b82f6', darkSidebar: '#111827',
    };
    setForm(f => ({ ...f, ...defaults, logoData: null }));
    toast.info('Reset to defaults (click Save to apply)');
  };

  const logoSrc = form.logoData || branding.logoData;

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader
        title="Branding & Appearance"
        subtitle="Customize logo, colors and software name"
        actions={
          <div className="flex gap-2">
            <button onClick={handleReset} className="btn-secondary"><RefreshCw className="w-4 h-4" /> Reset</button>
            <button onClick={handleSave} disabled={saving} className="btn-primary">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving...' : 'Save & Apply'}
            </button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Settings */}
        <div className="lg:col-span-2 space-y-5">
          {/* Tabs */}
          <div className="flex gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl w-fit">
            {[['logo', Image, 'Logo'], ['colors', Palette, 'Colors'], ['name', Type, 'Name']].map(([key, Icon, label]) => (
              <button key={key} onClick={() => setTab(key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === key ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
                <Icon className="w-4 h-4" />{label}
              </button>
            ))}
          </div>

          {/* Logo Tab */}
          {tab === 'logo' && (
            <div className="card p-6 space-y-5">
              <h3 className="font-semibold text-gray-900 dark:text-white">Company Logo</h3>

              {/* Current logo display */}
              <div className="flex items-start gap-5">
                <div className="w-32 h-32 rounded-2xl border-2 border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-700 flex-shrink-0">
                  {logoSrc
                    ? <img src={logoSrc} alt="Logo" className="w-full h-full object-contain p-2" />
                    : <div className="text-center text-gray-400"><Image className="w-10 h-10 mx-auto mb-1" /><p className="text-xs">No logo</p></div>
                  }
                </div>
                <div className="flex-1 space-y-3">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Upload your company logo. PNG with transparent background works best. The logo will appear on the login page, sidebar, and in PDF reports.</p>
                  <div className="flex gap-2 flex-wrap">
                    <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                    <button onClick={() => fileRef.current.click()} className="btn-primary">
                      <Upload className="w-4 h-4" /> Upload Logo
                    </button>
                    {logoSrc && (
                      <button onClick={handleRemoveLogo} className="btn-danger">
                        <X className="w-4 h-4" /> Remove
                      </button>
                    )}
                  </div>
                  {extracting && (
                    <div className="flex items-center gap-2 text-sm text-brand-600 dark:text-brand-400">
                      <Loader2 className="w-4 h-4 animate-spin" /> Extracting colors from logo...
                    </div>
                  )}
                  <p className="text-xs text-gray-400">Max 5MB · PNG, JPG, SVG, WebP · Colors auto-extracted on upload</p>
                </div>
              </div>

              {/* Logo sizes preview */}
              {logoSrc && (
                <div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Logo Preview</p>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: 'Sidebar (36px)', size: 'w-9 h-9' },
                      { label: 'Login (64px)', size: 'w-16 h-16' },
                      { label: 'Report (96px)', size: 'w-24 h-24' },
                    ].map(({ label, size }) => (
                      <div key={label} className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 flex flex-col items-center gap-2">
                        <div className={`${size} flex items-center justify-center`}>
                          <img src={logoSrc} alt="" className="w-full h-full object-contain" />
                        </div>
                        <p className="text-xs text-gray-500 text-center">{label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Colors Tab */}
          {tab === 'colors' && (
            <div className="card p-6 space-y-5">
              <h3 className="font-semibold text-gray-900 dark:text-white">Color Theme</h3>

              {/* Presets */}
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Quick Presets</p>
                <div className="grid grid-cols-4 gap-2">
                  {COLOR_PRESETS.map(preset => (
                    <button key={preset.name} onClick={() => applyPreset(preset)}
                      className="group relative p-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-500 transition-all">
                      <div className="flex gap-1 justify-center mb-2">
                        <div className="w-5 h-5 rounded-full border border-white shadow-sm" style={{ background: preset.primary }} />
                        <div className="w-5 h-5 rounded-full border border-white shadow-sm" style={{ background: preset.secondary }} />
                        <div className="w-5 h-5 rounded-full border border-white shadow-sm" style={{ background: preset.accent }} />
                      </div>
                      <p className="text-xs text-center text-gray-600 dark:text-gray-400">{preset.name}</p>
                      {form.primaryColor === preset.primary && (
                        <div className="absolute top-1 right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom colors */}
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Custom Colors</p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    ['primaryColor',   'Primary Color',    'Main buttons, active states, links'],
                    ['secondaryColor', 'Secondary Color',  'Hover states, darker accents'],
                    ['accentColor',    'Accent Color',     'Highlights, lighter tones'],
                    ['sidebarColor',   'Sidebar BG (Light)', 'Sidebar background in light mode'],
                    ['darkPrimary',    'Primary (Dark)',    'Primary color in dark mode'],
                    ['darkSidebar',    'Sidebar BG (Dark)', 'Sidebar background in dark mode'],
                  ].map(([key, label, hint]) => (
                    <div key={key}>
                      <label className="form-label">{label}</label>
                      <div className="flex items-center gap-2">
                        <input type="color" value={form[key] || '#2563eb'}
                          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                          className="w-10 h-10 rounded-lg border border-gray-200 dark:border-gray-600 cursor-pointer p-1 bg-white dark:bg-gray-700" />
                        <input type="text" value={form[key] || '#2563eb'}
                          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                          className="form-input font-mono text-xs flex-1" placeholder="#2563eb" />
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">{hint}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Name Tab */}
          {tab === 'name' && (
            <div className="card p-6 space-y-5">
              <h3 className="font-semibold text-gray-900 dark:text-white">Software Name</h3>
              <div>
                <label className="form-label">Display Name</label>
                <input className="form-input text-lg" placeholder="FleetTrack Pro"
                  value={form.softwareName || ''} onChange={e => setForm(f => ({ ...f, softwareName: e.target.value }))} />
                <p className="text-xs text-gray-400 mt-1">This name appears on the login page, sidebar, browser tab, and all reports.</p>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4">
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">Preview</p>
                <div className="flex items-center gap-2">
                  {logoSrc && <img src={logoSrc} alt="" className="w-8 h-8 object-contain" />}
                  <div>
                    <div className="text-sm font-bold text-gray-900 dark:text-white">{form.softwareName || 'FleetTrack Pro'}</div>
                    <div className="text-xs text-gray-400">Pro Edition</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Live Preview */}
        <div className="space-y-4">
          <div className="card p-4">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Eye className="w-4 h-4" /> Live Preview
            </h3>

            {/* Mini sidebar preview */}
            <div className="rounded-xl overflow-hidden border border-gray-200 dark:border-gray-600 text-xs">
              {/* Sidebar */}
              <div className="flex h-48">
                <div className="w-28 flex flex-col p-2 gap-1" style={{ background: form.sidebarColor || '#ffffff' }}>
                  <div className="flex items-center gap-1.5 p-1.5 mb-1">
                    {logoSrc
                      ? <img src={logoSrc} alt="" className="w-5 h-5 object-contain" />
                      : <div className="w-5 h-5 rounded flex items-center justify-center text-white text-xs font-bold" style={{ background: form.primaryColor || '#2563eb' }}>F</div>
                    }
                    <span className="font-bold text-gray-800 truncate" style={{ fontSize: '9px' }}>{form.softwareName?.split(' ')[0] || 'Fleet'}</span>
                  </div>
                  {['Dashboard','Vehicles','Employees','Settings'].map((item, idx) => (
                    <div key={item} className="px-2 py-1 rounded text-gray-600 flex items-center gap-1" style={{
                      background: idx === 0 ? `${form.primaryColor || '#2563eb'}18` : 'transparent',
                      color: idx === 0 ? (form.primaryColor || '#2563eb') : '#6b7280',
                      fontSize: '9px'
                    }}>
                      <div className="w-2 h-2 rounded-sm bg-current opacity-60" />
                      {item}
                    </div>
                  ))}
                </div>
                {/* Content area */}
                <div className="flex-1 bg-gray-50 dark:bg-gray-800 p-2">
                  <div className="h-4 rounded mb-2" style={{ background: form.primaryColor || '#2563eb', opacity: 0.9 }} />
                  <div className="grid grid-cols-2 gap-1 mb-2">
                    {[0,1].map(i => <div key={i} className="h-8 bg-white dark:bg-gray-700 rounded border border-gray-100 dark:border-gray-600" />)}
                  </div>
                  <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded mb-1 w-3/4" />
                  <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded mb-2 w-1/2" />
                  <div className="flex gap-1">
                    <div className="px-2 py-1 rounded text-white text-[9px] font-medium" style={{ background: form.primaryColor || '#2563eb' }}>Save</div>
                    <div className="px-2 py-1 rounded text-[9px] font-medium bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300">Cancel</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Color swatches */}
            <div className="mt-4 space-y-2">
              <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Applied Colors</p>
              <div className="flex gap-2 flex-wrap">
                {[
                  ['Primary',   form.primaryColor],
                  ['Secondary', form.secondaryColor],
                  ['Accent',    form.accentColor],
                ].map(([label, color]) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <div className="w-5 h-5 rounded border border-white shadow-sm" style={{ background: color }} />
                    <span className="text-xs text-gray-500 dark:text-gray-400">{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Save reminder */}
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-3 text-xs text-amber-800 dark:text-amber-300">
            Changes are previewed live in this panel. Click <strong>Save & Apply</strong> to apply them across the entire app.
          </div>
        </div>
      </div>
    </div>
  );
}
