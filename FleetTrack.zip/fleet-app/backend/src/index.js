const express = require('express');
const cors = require('cors');

const authRoutes      = require('./routes/auth');
const vehicleRoutes   = require('./routes/vehicles');
const repairRoutes    = require('./routes/repairs');
const damageRoutes    = require('./routes/damage');
const equipmentRoutes = require('./routes/equipment');
const weeklyLogRoutes = require('./routes/weeklyLogs');
const dashboardRoutes = require('./routes/dashboard');
const userRoutes      = require('./routes/users');
const reportsRoutes   = require('./routes/reports');
const backupRoutes    = require('./routes/backup');
const employeeRoutes  = require('./routes/employees');
const equipmentTemplateRoutes = require('./routes/equipmentTemplate');
const brandingRoutes  = require('./routes/branding');

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.use('/api/auth',        authRoutes);
app.use('/api/vehicles',    vehicleRoutes);
app.use('/api/repairs',     repairRoutes);
app.use('/api/damage',      damageRoutes);
app.use('/api/equipment',   equipmentRoutes);
app.use('/api/weekly-logs', weeklyLogRoutes);
app.use('/api/dashboard',   dashboardRoutes);
app.use('/api/users',       userRoutes);
app.use('/api/reports',     reportsRoutes);
app.use('/api/backup',      backupRoutes);
app.use('/api/employees',   employeeRoutes);
app.use('/api/equipment',    equipmentTemplateRoutes);
app.use('/api/branding',    brandingRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', timestamp: new Date() }));

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(PORT, () => console.log(`Fleet Backend running on http://localhost:${PORT}`));
module.exports = app;
