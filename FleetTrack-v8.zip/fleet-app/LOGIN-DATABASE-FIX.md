# FleetTrack login / DATABASE_URL fix

This update fixes the missing `DATABASE_URL` error by preparing the backend environment **before** starting Express, Prisma, or Electron.

## Windows browser launch
1. Extract the ZIP to a new folder (do not delete or overwrite your old database).
2. If you have an existing `backend/prisma/fleet.db`, copy it into the extracted project's `backend/prisma/` folder **before the first launch**, with the app closed. Also copy your original `backend/.env` if you have one, to retain the original JWT secret and database URL.
3. Double-click `START_FleetTrack.bat`. On first launch it installs dependencies, creates `backend/.env` if missing, generates Prisma client, applies pending migrations, and seeds only when creating a new default local database.
4. Open the URL printed by the launcher. For desktop development, install root dependencies with `npm install` then run `npm run desktop:dev`.

## Troubleshooting
From `backend` run `node bootstrap.js`. The command prints the specific failure and does not reset or delete the database. If using an existing non-default DATABASE_URL, keep its original value. Never run `prisma migrate reset` on production data.

## What is not yet included
This is still a development build, not a standalone EXE. Local/shared database switching in Settings and packaged Windows installation require separate implementation and testing.
