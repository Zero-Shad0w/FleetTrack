@echo off
title FleetTrack — Database Fix
color 0E

echo.
echo  ============================================================
echo    FleetTrack Pro — Database Fix Utility
echo  ============================================================
echo.
echo  This will add any missing database columns.
echo  Your existing data will NOT be deleted.
echo.

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

cd /d %ROOT%

:: Install better-sqlite3 if needed
echo  [..] Checking dependencies...
if not exist "node_modules\better-sqlite3" (
    echo  [..] Installing better-sqlite3...
    call npm install better-sqlite3 --save
)

echo  [..] Running database fix...
node fix-database.js

echo.
echo  Press any key to close.
pause >nul
