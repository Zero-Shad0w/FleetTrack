// Safe, repeatable local database preparation. Never deletes or resets an existing database.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const root = __dirname;
const envFile = path.join(root, '.env');
const dbFile = path.join(root, 'prisma', 'fleet.db');
function fail(message) { console.error('[FleetTrack setup] ERROR: ' + message); process.exit(1); }
function run(args) {
  const prisma = path.join(root, 'node_modules', 'prisma', 'build', 'index.js');
  if (!fs.existsSync(prisma)) fail('Prisma is missing. Run npm install in backend first.');
  const result = spawnSync(process.execPath, [prisma, ...args], { cwd: root, env: process.env, stdio: 'inherit' });
  if (result.error || result.status !== 0) fail(`prisma ${args.join(' ')} failed; see output above.`);
}
try {
  fs.mkdirSync(path.dirname(dbFile), { recursive: true });
  if (!fs.existsSync(envFile)) {
    const secret = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(envFile, `DATABASE_URL="file:./fleet.db"\nJWT_SECRET="${secret}"\nPORT=3001\n`, { flag: 'wx', mode: 0o600 });
    console.log('[FleetTrack setup] Created backend/.env with a unique JWT secret.');
  }
  const lines = fs.readFileSync(envFile, 'utf8');
  const value = key => { const match = lines.match(new RegExp('^\\s*' + key + '\\s*=\\s*(.*)$', 'm')); return match ? match[1].trim().replace(/^['"]|['"]$/g, '') : ''; };
  if (!value('DATABASE_URL')) fail('DATABASE_URL is missing in backend/.env. Add DATABASE_URL="file:./fleet.db" (or your existing database location).');
  if (!value('JWT_SECRET')) fail('JWT_SECRET is missing in backend/.env. Restore your original secret to preserve active sessions.');
  if (!process.env.DATABASE_URL) process.env.DATABASE_URL = value('DATABASE_URL');
  if (!process.env.JWT_SECRET) process.env.JWT_SECRET = value('JWT_SECRET');
  const fresh = !fs.existsSync(dbFile) && process.env.DATABASE_URL === 'file:./fleet.db';
  run(['generate']);
  run(['migrate', 'deploy']);
  if (fresh) {
    console.log('[FleetTrack setup] New local database detected; creating initial users/sample data.');
    const result = spawnSync(process.execPath, ['src/seed.js'], { cwd: root, env: process.env, stdio: 'inherit' });
    if (result.error || result.status !== 0) fail('Initial seed failed. Check output above.');
  }
  console.log('[FleetTrack setup] Database configuration ready.');
} catch (e) { fail(e.message); }
