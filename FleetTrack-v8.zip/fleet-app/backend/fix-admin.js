const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function fix() {
  // Enable ALL users (set active = true where null or false)
  const result = await prisma.user.updateMany({
    where: { active: { not: true } },
    data: { active: true }
  });
  console.log(`Fixed ${result.count} user(s) — all accounts are now active.`);

  // Show all users
  const users = await prisma.user.findMany({
    select: { id: true, username: true, role: true, active: true }
  });
  console.log('\nCurrent users:');
  users.forEach(u => console.log(`  [${u.active ? 'ACTIVE' : 'DISABLED'}] ${u.username} (${u.role})`));
}

fix().catch(console.error).finally(() => prisma.$disconnect());
