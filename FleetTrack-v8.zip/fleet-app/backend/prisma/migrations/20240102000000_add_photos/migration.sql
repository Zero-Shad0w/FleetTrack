-- Add photos column to DamageInspection
ALTER TABLE "DamageInspection" ADD COLUMN "photos" TEXT;
