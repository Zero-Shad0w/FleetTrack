-- Add vehicle view photos
ALTER TABLE "Vehicle" ADD COLUMN "photoFront" TEXT;
ALTER TABLE "Vehicle" ADD COLUMN "photoRear"  TEXT;
ALTER TABLE "Vehicle" ADD COLUMN "photoLeft"  TEXT;
ALTER TABLE "Vehicle" ADD COLUMN "photoRight" TEXT;
ALTER TABLE "Vehicle" ADD COLUMN "photoTop"   TEXT;
