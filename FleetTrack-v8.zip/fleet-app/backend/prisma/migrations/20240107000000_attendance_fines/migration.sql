-- Employee Attendance
CREATE TABLE "EmployeeAttendance" (
  "id"          INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"  INTEGER NOT NULL,
  "date"        DATETIME NOT NULL,
  "checkIn"     TEXT,
  "checkOut"    TEXT,
  "status"      TEXT NOT NULL DEFAULT 'present',
  "hoursWorked" REAL,
  "overtime"    REAL,
  "notes"       TEXT,
  "approvedBy"  TEXT,
  "createdAt"   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);

-- Employee Fines
CREATE TABLE "EmployeeFine" (
  "id"             INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"     INTEGER NOT NULL,
  "title"          TEXT NOT NULL,
  "reason"         TEXT,
  "amount"         REAL NOT NULL,
  "deductionType"  TEXT NOT NULL DEFAULT 'once',
  "deductionDate"  DATETIME,
  "status"         TEXT NOT NULL DEFAULT 'pending',
  "issuedBy"       TEXT,
  "approvedBy"     TEXT,
  "notes"          TEXT,
  "relatedWarning" TEXT,
  "createdAt"      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);
