-- Add left and right side damage marker columns
ALTER TABLE "DamageInspection" ADD COLUMN "leftDamageMarkers"  TEXT;
ALTER TABLE "DamageInspection" ADD COLUMN "rightDamageMarkers" TEXT;
