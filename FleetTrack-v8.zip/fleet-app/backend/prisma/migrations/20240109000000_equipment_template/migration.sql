-- Equipment Template (saved list per vehicle)
CREATE TABLE "EquipmentTemplate" (
  "id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "vehicleId" INTEGER NOT NULL,
  "itemName"  TEXT NOT NULL,
  "category"  TEXT,
  "required"  BOOLEAN NOT NULL DEFAULT 1,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("vehicleId") REFERENCES "Vehicle"("id") ON DELETE CASCADE
);
