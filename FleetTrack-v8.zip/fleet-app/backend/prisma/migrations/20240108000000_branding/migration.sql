-- BrandingSettings table
CREATE TABLE "BrandingSettings" (
  "id"             INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "softwareName"   TEXT NOT NULL DEFAULT 'FleetTrack Pro',
  "logoData"       TEXT,
  "primaryColor"   TEXT NOT NULL DEFAULT '#2563eb',
  "secondaryColor" TEXT NOT NULL DEFAULT '#1d4ed8',
  "accentColor"    TEXT NOT NULL DEFAULT '#3b82f6',
  "sidebarColor"   TEXT NOT NULL DEFAULT '#ffffff',
  "textColor"      TEXT NOT NULL DEFAULT '#111827',
  "darkPrimary"    TEXT NOT NULL DEFAULT '#3b82f6',
  "darkSidebar"    TEXT NOT NULL DEFAULT '#111827',
  "updatedBy"      TEXT,
  "updatedAt"      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt"      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Insert default row
INSERT INTO "BrandingSettings" ("softwareName","primaryColor","secondaryColor","accentColor","sidebarColor","textColor","darkPrimary","darkSidebar","updatedAt")
VALUES ('FleetTrack Pro','#2563eb','#1d4ed8','#3b82f6','#ffffff','#111827','#3b82f6','#111827',CURRENT_TIMESTAMP);
