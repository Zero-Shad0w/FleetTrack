-- Employee table
CREATE TABLE "Employee" (
  "id"               INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"       TEXT NOT NULL UNIQUE,
  "firstName"        TEXT NOT NULL,
  "lastName"         TEXT NOT NULL,
  "gender"           TEXT,
  "dateOfBirth"      DATETIME,
  "personalNumber"   TEXT,
  "phone"            TEXT,
  "email"            TEXT,
  "address"          TEXT,
  "city"             TEXT,
  "country"          TEXT,
  "emergencyContact" TEXT,
  "emergencyPhone"   TEXT,
  "role"             TEXT,
  "department"       TEXT,
  "manager"          TEXT,
  "employmentStatus" TEXT NOT NULL DEFAULT 'active',
  "employmentType"   TEXT NOT NULL DEFAULT 'full_time',
  "hireDate"         DATETIME,
  "salary"           REAL,
  "notes"            TEXT,
  "profilePhoto"     TEXT,
  "archived"         BOOLEAN NOT NULL DEFAULT 0,
  "createdAt"        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Employee Warnings
CREATE TABLE "EmployeeWarning" (
  "id"               INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"       INTEGER NOT NULL,
  "title"            TEXT NOT NULL,
  "warningType"      TEXT,
  "severity"         TEXT NOT NULL DEFAULT 'minor',
  "description"      TEXT,
  "dateIssued"       DATETIME NOT NULL,
  "issuedBy"         TEXT,
  "reason"           TEXT,
  "relatedIncident"  TEXT,
  "actionTaken"      TEXT,
  "employeeResponse" TEXT,
  "attachments"      TEXT,
  "signature"        TEXT,
  "createdAt"        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);

-- Employee Tools
CREATE TABLE "EmployeeTool" (
  "id"           INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"   INTEGER NOT NULL,
  "toolName"     TEXT NOT NULL,
  "toolType"     TEXT,
  "serialNumber" TEXT,
  "assetNumber"  TEXT,
  "condition"    TEXT,
  "assignedDate" DATETIME,
  "returnDate"   DATETIME,
  "status"       TEXT NOT NULL DEFAULT 'assigned',
  "notes"        TEXT,
  "photos"       TEXT,
  "documents"    TEXT,
  "createdAt"    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);

-- Employee Complaints
CREATE TABLE "EmployeeComplaint" (
  "id"            INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId"    INTEGER NOT NULL,
  "title"         TEXT NOT NULL,
  "category"      TEXT,
  "priority"      TEXT NOT NULL DEFAULT 'medium',
  "description"   TEXT,
  "date"          DATETIME NOT NULL,
  "status"        TEXT NOT NULL DEFAULT 'open',
  "adminReply"    TEXT,
  "anonymous"     BOOLEAN NOT NULL DEFAULT 0,
  "attachments"   TEXT,
  "internalNotes" TEXT,
  "createdAt"     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);

-- Employee Documents
CREATE TABLE "EmployeeDocument" (
  "id"         INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "employeeId" INTEGER NOT NULL,
  "name"       TEXT NOT NULL,
  "category"   TEXT,
  "fileData"   TEXT,
  "fileType"   TEXT,
  "fileSize"   INTEGER,
  "expiryDate" DATETIME,
  "version"    INTEGER NOT NULL DEFAULT 1,
  "notes"      TEXT,
  "createdAt"  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
);
