const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function debug() {
  // Show raw date values stored in DB
  const rows = await prisma.$queryRawUnsafe(`SELECT id, employeeId, date, status FROM "EmployeeAttendance" ORDER BY id DESC LIMIT 10`);
  console.log('Raw attendance records:');
  rows.forEach(r => console.log(`  id:${r.id} empId:${r.employeeId} date:[${r.date}] status:${r.status}`));

  const today = new Date();
  console.log('\nToday values to match against:');
  console.log('  ISO slice 0-10:', today.toISOString().slice(0,10));
  console.log('  Local date:    ', `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`);

  // Try different matching strategies
  const t1 = await prisma.$queryRawUnsafe(`SELECT COUNT(*) as cnt FROM "EmployeeAttendance" WHERE date LIKE '${today.toISOString().slice(0,10)}%'`);
  console.log('\nLIKE ISO slice match:', Number(t1[0].cnt));

  const localDate = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  const t2 = await prisma.$queryRawUnsafe(`SELECT COUNT(*) as cnt FROM "EmployeeAttendance" WHERE date LIKE '${localDate}%'`);
  console.log('LIKE local date match:', Number(t2[0].cnt));

  const t3 = await prisma.$queryRawUnsafe(`SELECT COUNT(*) as cnt FROM "EmployeeAttendance" WHERE date(date) = date('now')`);
  console.log('date(date)=date(now) match:', Number(t3[0].cnt));

  const t4 = await prisma.$queryRawUnsafe(`SELECT COUNT(*) as cnt FROM "EmployeeAttendance" WHERE DATE(date) = '${localDate}'`);
  console.log('DATE(date)=localDate match:', Number(t4[0].cnt));
}

debug().catch(console.error).finally(() => prisma.$disconnect());
