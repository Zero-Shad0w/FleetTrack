// Runs as a Node process under Electron. Never overwrites an existing database.
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const dbUrl=process.env.DATABASE_URL||'';
if(!dbUrl.startsWith('file:'))throw Error('Local SQLite DATABASE_URL required');
const dbPath=dbUrl.slice(5);
fs.mkdirSync(path.dirname(dbPath),{recursive:true});
const isNew=!fs.existsSync(dbPath);
const prisma=path.join(__dirname,'node_modules/prisma/build/index.js');
if(!fs.existsSync(prisma))throw Error('Prisma CLI missing from installed package');
const result=spawnSync(process.execPath,[prisma,'migrate','deploy'],{cwd:__dirname,env:process.env,stdio:'inherit'});
if(result.status!==0)throw Error('Database migration failed. No reset was performed.');
if(isNew){const seeded=spawnSync(process.execPath,[path.join(__dirname,'src/seed.js')],{cwd:__dirname,env:process.env,stdio:'inherit'});if(seeded.status!==0)throw Error('Initial database seed failed');}
require('./src/index.js');
