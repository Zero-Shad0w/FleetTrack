/**
 * Fix attendance table columns
 * Run from: C:\FleetTrack\fleet-app\backend
 * Usage: node fix-attendance.js
 */

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function fix() {
  console.log('Checking EmployeeAttendance columns...\n');

  // Get current columns
  const cols = await prisma.$queryRawUnsafe(`PRAGMA table_info("EmployeeAttendance")`);
  const colNames = cols.map(c => c.name);
  console.log('Current columns:', colNames.join(', '));

  const toAdd = [
    { name: 'checkIn',     type: 'TEXT' },
    { name: 'checkOut',    type: 'TEXT' },
    { name: 'hoursWorked', type: 'REAL' },
    { name: 'overtime',    type: 'REAL' },
    { name: 'notes',       type: 'TEXT' },
    { name: 'approvedBy',  type: 'TEXT' },
    { name: 'updatedAt',   type: "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP" },
  ];

  for (const col of toAdd) {
    if (!colNames.includes(col.name)) {
      try {
        await prisma.$queryRawUnsafe(`ALTER TABLE "EmployeeAttendance" ADD COLUMN "${col.name}" ${col.type}`);
        console.log(`  ✓ Added column: ${col.name}`);
      } catch (e) {
        console.log(`  ✗ Failed ${col.name}: ${e.message}`);
      }
    } else {
      console.log(`  - Already exists: ${col.name}`);
    }
  }

  console.log('\n✅ Done! Restart the app now.');
}

fix().catch(console.error).finally(() => prisma.$disconnect());
