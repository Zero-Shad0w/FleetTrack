const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Role hierarchy and permissions
const ROLE_PERMISSIONS = {
  admin: {
    vehicles: true, employees: true, reports: true, dashboard: true,
    userManagement: true, backup: true, deleteAll: true, salary: true,
    warnings: true, complaints: true, allFiles: true
  },
  inspector: {
    vehicles: true, employees: false, reports: false, dashboard: true,
    userManagement: false, backup: false, deleteAll: false, salary: false,
    warnings: false, complaints: false, allFiles: false
  },
  coordinator: {
    vehicles: false, employees: true, reports: false, dashboard: true,
    userManagement: false, backup: false, deleteAll: false, salary: false,
    warnings: true, complaints: true, allFiles: true
  },
  manager: {
    vehicles: true, employees: true, reports: true, dashboard: true,
    userManagement: false, backup: false, deleteAll: false, salary: false,
    warnings: true, complaints: true, allFiles: true
  },
  viewer: {
    vehicles: true, employees: true, reports: false, dashboard: true,
    userManagement: false, backup: false, deleteAll: false, salary: false,
    warnings: false, complaints: false, allFiles: false
  }
};

const authenticate = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Access token required' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findUnique({ where: { id: decoded.id } });
    if (!user) return res.status(403).json({ error: 'Account not found' });
    if (user.active === false) return res.status(403).json({ error: 'Account disabled' });
    req.user = { ...decoded, role: user.role };
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

const requirePermission = (permission) => (req, res, next) => {
  const perms = ROLE_PERMISSIONS[req.user.role] || {};
  if (!perms[permission]) {
    return res.status(403).json({ error: `Access denied: requires ${permission} permission` });
  }
  next();
};

const logActivity = async (userId, action, details) => {
  try {
    await prisma.activityLog.create({ data: { userId, action, details } });
  } catch (e) { /* silent */ }
};

module.exports = { authenticate, requireRole, requirePermission, logActivity, ROLE_PERMISSIONS };
