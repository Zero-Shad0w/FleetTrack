const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.get('/stats', authenticate, async (req, res) => {
  try {
    const role = req.user.role;
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);
    const weekStart  = new Date(); weekStart.setDate(weekStart.getDate() - weekStart.getDay()); weekStart.setHours(0,0,0,0);
    const todayStart = new Date(); todayStart.setHours(0,0,0,0);

    // ── VEHICLE stats (admin, inspector, manager, viewer) ─────────────────────
    let vehicleStats = null;
    if (['admin','inspector','manager','viewer'].includes(role)) {
      const [totalVehicles, totalRepairs, repairCosts, recentLogs, upcomingExpiries, monthlyRepairs, recentDamage] = await Promise.all([
        prisma.vehicle.count(),
        prisma.repair.count(),
        prisma.repair.aggregate({ _sum: { totalCost: true } }),
        prisma.weeklyLog.findMany({
          take: 5, orderBy: { createdAt: 'desc' },
          include: { vehicle: { select: { vehicleId: true, make: true, model: true } } }
        }),
        prisma.vehicle.findMany({
          where: {
            OR: [
              { insuranceExpiry:   { lte: new Date(Date.now() + 30*24*60*60*1000) } },
              { registrationExpiry:{ lte: new Date(Date.now() + 30*24*60*60*1000) } },
              { serviceDueDate:    { lte: new Date(Date.now() + 30*24*60*60*1000) } },
            ]
          },
          select: { id:true, vehicleId:true, make:true, model:true, licensePlate:true, insuranceExpiry:true, registrationExpiry:true, serviceDueDate:true }
        }),
        prisma.repair.aggregate({ where: { repairDate: { gte: monthStart } }, _sum: { totalCost: true }, _count: true }),
        prisma.damageInspection.findMany({ take: 4, orderBy: { inspectionDate: 'desc' }, include: { vehicle: { select: { vehicleId: true, make: true, model: true } } } }),
      ]);
      vehicleStats = {
        totalVehicles, totalRepairs,
        totalRepairCost:   repairCosts._sum.totalCost || 0,
        monthlyRepairCost: monthlyRepairs._sum.totalCost || 0,
        monthlyRepairCount: monthlyRepairs._count,
        recentLogs, upcomingExpiries, recentDamage,
      };
    }

    // ── EMPLOYEE stats (admin, coordinator, manager, viewer) ──────────────────
    let employeeStats = null;
    if (['admin','coordinator','manager','viewer'].includes(role)) {
      const empExists = await prisma.employee.count().catch(() => -1);
      if (empExists >= 0) {
        const [
          totalEmployees, activeEmployees, onLeave, terminated,
          recentWarnings, openComplaints, pendingFines,
          todayAttendance, absentToday
        ] = await Promise.all([
          prisma.employee.count({ where: { archived: false } }),
          prisma.employee.count({ where: { archived: false, employmentStatus: 'active' } }),
          prisma.employee.count({ where: { archived: false, employmentStatus: 'on_leave' } }),
          prisma.employee.count({ where: { archived: false, employmentStatus: 'terminated' } }),
          prisma.employeeWarning.findMany({ take: 4, orderBy: { dateIssued: 'desc' }, include: { employee: { select: { firstName:true, lastName:true, employeeId:true, profilePhoto:true } } } }),
          prisma.employeeComplaint.count({ where: { status: 'open' } }),
          prisma.employeeFine.aggregate({ where: { status: 'pending' }, _sum: { amount: true }, _count: true }).catch(() => ({ _sum: { amount: 0 }, _count: 0 })),
          (async () => {
            try {
              // Match any date format by comparing the year-month-day portion
              const y = todayStart.getFullYear();
              const m = String(todayStart.getMonth()+1).padStart(2,'0');
              const d = String(todayStart.getDate()).padStart(2,'0');
              const rows = await prisma.$queryRawUnsafe(
                `SELECT CAST(COUNT(*) AS INTEGER) as cnt FROM "EmployeeAttendance"
                 WHERE strftime('%Y-%m-%d', date) = ? AND status IN ('present','remote','late')`,
                `${y}-${m}-${d}`
              );
              return parseInt(String(rows[0]?.cnt ?? 0));
            } catch (e) { return 0; }
          })(),
          (async () => {
            try {
              const y = todayStart.getFullYear();
              const m = String(todayStart.getMonth()+1).padStart(2,'0');
              const d = String(todayStart.getDate()).padStart(2,'0');
              const rows = await prisma.$queryRawUnsafe(
                `SELECT CAST(COUNT(*) AS INTEGER) as cnt FROM "EmployeeAttendance"
                 WHERE strftime('%Y-%m-%d', date) = ? AND status = 'absent'`,
                `${y}-${m}-${d}`
              );
              return parseInt(String(rows[0]?.cnt ?? 0));
            } catch (e) { return 0; }
          })(),
        ]);
        employeeStats = {
          totalEmployees:  parseInt(String(totalEmployees  ?? 0)),
          activeEmployees: parseInt(String(activeEmployees ?? 0)),
          onLeave:         parseInt(String(onLeave         ?? 0)),
          terminated:      parseInt(String(terminated      ?? 0)),
          openComplaints:  parseInt(String(openComplaints  ?? 0)),
          recentWarnings,
          pendingFinesAmount: pendingFines._sum.amount || 0,
          pendingFinesCount:  parseInt(String(pendingFines._count ?? 0)),
          todayPresent: parseInt(String(todayAttendance ?? 0)),
          todayAbsent:  parseInt(String(absentToday    ?? 0)),
        };
      }
    }

    // ── ADMIN extras ──────────────────────────────────────────────────────────
    let adminStats = null;
    if (role === 'admin') {
      const [totalUsers, activeUsers, recentActivity] = await Promise.all([
        prisma.user.count(),
        prisma.user.count({ where: { active: true } }),
        prisma.activityLog.findMany({ take: 6, orderBy: { createdAt: 'desc' }, include: { user: { select: { username:true, role:true } } } }),
      ]);
      adminStats = { totalUsers, activeUsers, recentActivity };
    }

    res.json({ role, vehicleStats, employeeStats, adminStats });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
