const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const { vehicleId, startDate, endDate, category } = req.query;
    const where = {};
    if (vehicleId) where.vehicleId = parseInt(vehicleId);
    if (category) where.category = { contains: category };
    if (startDate || endDate) {
      where.repairDate = {};
      if (startDate) where.repairDate.gte = new Date(startDate);
      if (endDate) where.repairDate.lte = new Date(endDate);
    }
    const repairs = await prisma.repair.findMany({
      where, orderBy: { repairDate: 'desc' }, include: { vehicle: { select: { vehicleId: true, make: true, model: true, licensePlate: true } } }
    });
    res.json(repairs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    data.vehicleId = parseInt(data.vehicleId);
    data.labourCost = parseFloat(data.labourCost || 0);
    data.partsCost = parseFloat(data.partsCost || 0);
    data.totalCost = data.labourCost + data.partsCost;
    data.mileage = data.mileage ? parseInt(data.mileage) : null;
    data.repairDate = new Date(data.repairDate);
    const repair = await prisma.repair.create({ data, include: { vehicle: { select: { vehicleId: true, make: true, model: true } } } });
    res.status(201).json(repair);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.createdAt; delete data.vehicle;
    if (data.vehicleId) data.vehicleId = parseInt(data.vehicleId);
    data.labourCost = parseFloat(data.labourCost || 0);
    data.partsCost = parseFloat(data.partsCost || 0);
    data.totalCost = data.labourCost + data.partsCost;
    if (data.mileage) data.mileage = parseInt(data.mileage);
    if (data.repairDate) data.repairDate = new Date(data.repairDate);
    const repair = await prisma.repair.update({ where: { id: parseInt(req.params.id) }, data });
    res.json(repair);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    await prisma.repair.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Repair deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
