const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requirePermission, logActivity } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

const EMP_FIELDS = [
  'employeeId','firstName','lastName','gender','dateOfBirth','personalNumber',
  'phone','email','address','city','country','emergencyContact','emergencyPhone',
  'role','department','manager','employmentStatus','employmentType','hireDate',
  'salary','notes','profilePhoto','archived'
];

const prepareEmployee = (body, userRole) => {
  const data = {};
  for (const key of EMP_FIELDS) {
    if (key in body) data[key] = body[key] === '' ? null : body[key];
  }
  // Salary only settable by admin/manager
  if (!['admin','manager'].includes(userRole)) delete data.salary;
  if (data.dateOfBirth) data.dateOfBirth = new Date(data.dateOfBirth);
  if (data.hireDate) data.hireDate = new Date(data.hireDate);
  if (typeof data.archived === 'string') data.archived = data.archived === 'true';
  return data;
};

// GET all employees
router.get('/', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const { search, status, department, type, archived } = req.query;
    const where = { archived: archived === 'true' ? true : false };
    if (status) where.employmentStatus = status;
    if (department) where.department = { contains: department };
    if (type) where.employmentType = type;
    if (search) {
      where.OR = [
        { firstName:    { contains: search } },
        { lastName:     { contains: search } },
        { employeeId:   { contains: search } },
        { email:        { contains: search } },
        { department:   { contains: search } },
        { role:         { contains: search } },
      ];
    }
    const employees = await prisma.employee.findMany({
      where, orderBy: { createdAt: 'desc' },
      select: {
        id: true, employeeId: true, firstName: true, lastName: true,
        gender: true, phone: true, email: true, role: true, department: true,
        manager: true, employmentStatus: true, employmentType: true,
        hireDate: true, profilePhoto: true, city: true, country: true,
        archived: true, createdAt: true, updatedAt: true,
        // salary only for admin/manager
        salary: req.user.role === 'admin' || req.user.role === 'manager' ? true : false,
      }
    });
    res.json(employees);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET single employee (full profile)
router.get('/:id', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const include = {
      warnings:   { orderBy: { dateIssued: 'desc' } },
      tools:      { orderBy: { createdAt: 'desc' } },
      complaints: { orderBy: { date: 'desc' } },
      documents:  { orderBy: { createdAt: 'desc' } },
    };
    // Hide salary from non-admin/manager
    const employee = await prisma.employee.findUnique({
      where: { id: parseInt(req.params.id) }, include
    });
    if (!employee) return res.status(404).json({ error: 'Employee not found' });
    if (!['admin','manager'].includes(req.user.role)) delete employee.salary;
    // Hide warnings/complaints from viewer/inspector
    if (!ROLE_PERMISSIONS[req.user.role]?.warnings) delete employee.warnings;
    if (!ROLE_PERMISSIONS[req.user.role]?.complaints) delete employee.complaints;
    res.json(employee);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// CREATE employee
router.post('/', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = prepareEmployee(req.body, req.user.role);
    if (!data.employeeId) return res.status(400).json({ error: 'Employee ID is required' });
    if (!data.firstName)  return res.status(400).json({ error: 'First name is required' });
    if (!data.lastName)   return res.status(400).json({ error: 'Last name is required' });
    const employee = await prisma.employee.create({ data });
    await logActivity(req.user.id, 'CREATE_EMPLOYEE', `Created employee: ${data.firstName} ${data.lastName}`);
    res.status(201).json(employee);
  } catch (err) {
    if (err.code === 'P2002') return res.status(400).json({ error: 'Employee ID already exists' });
    res.status(500).json({ error: err.message });
  }
});

// UPDATE employee
router.put('/:id', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = prepareEmployee(req.body, req.user.role);
    delete data.employeeId;
    const employee = await prisma.employee.update({
      where: { id: parseInt(req.params.id) }, data
    });
    await logActivity(req.user.id, 'UPDATE_EMPLOYEE', `Updated employee ID ${req.params.id}`);
    res.json(employee);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ARCHIVE (soft delete)
router.put('/:id/archive', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const emp = await prisma.employee.findUnique({ where: { id: parseInt(req.params.id) } });
    const employee = await prisma.employee.update({
      where: { id: parseInt(req.params.id) },
      data: { archived: !emp.archived }
    });
    await logActivity(req.user.id, employee.archived ? 'ARCHIVE_EMPLOYEE' : 'RESTORE_EMPLOYEE', `Employee ${emp.firstName} ${emp.lastName}`);
    res.json(employee);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE (admin only)
router.delete('/:id', authenticate, async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    await prisma.employee.delete({ where: { id: parseInt(req.params.id) } });
    await logActivity(req.user.id, 'DELETE_EMPLOYEE', `Deleted employee ID ${req.params.id}`);
    res.json({ message: 'Employee deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── WARNINGS ──────────────────────────────────────────────────────────────────
router.get('/:id/warnings', authenticate, requirePermission('warnings'), async (req, res) => {
  try {
    const warnings = await prisma.employeeWarning.findMany({
      where: { employeeId: parseInt(req.params.id) }, orderBy: { dateIssued: 'desc' }
    });
    res.json(warnings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/warnings', authenticate, requirePermission('warnings'), async (req, res) => {
  try {
    const data = { ...req.body, employeeId: parseInt(req.params.id) };
    if (data.dateIssued) data.dateIssued = new Date(data.dateIssued);
    if (data.attachments && typeof data.attachments === 'object') data.attachments = JSON.stringify(data.attachments);
    const warning = await prisma.employeeWarning.create({ data });
    res.status(201).json(warning);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id/warnings/:wid', authenticate, requirePermission('warnings'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.employeeId; delete data.createdAt;
    if (data.dateIssued) data.dateIssued = new Date(data.dateIssued);
    if (data.attachments && typeof data.attachments === 'object') data.attachments = JSON.stringify(data.attachments);
    const warning = await prisma.employeeWarning.update({ where: { id: parseInt(req.params.wid) }, data });
    res.json(warning);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/warnings/:wid', authenticate, async (req, res) => {
  try {
    if (!['admin','manager'].includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    await prisma.employeeWarning.delete({ where: { id: parseInt(req.params.wid) } });
    res.json({ message: 'Warning deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── TOOLS ─────────────────────────────────────────────────────────────────────
router.get('/:id/tools', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const tools = await prisma.employeeTool.findMany({
      where: { employeeId: parseInt(req.params.id) }, orderBy: { createdAt: 'desc' }
    });
    res.json(tools);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/tools', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = { ...req.body, employeeId: parseInt(req.params.id) };
    if (data.assignedDate) data.assignedDate = new Date(data.assignedDate);
    if (data.returnDate) data.returnDate = new Date(data.returnDate);
    if (data.photos && typeof data.photos === 'object') data.photos = JSON.stringify(data.photos);
    if (data.documents && typeof data.documents === 'object') data.documents = JSON.stringify(data.documents);
    const tool = await prisma.employeeTool.create({ data });
    res.status(201).json(tool);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id/tools/:tid', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.employeeId; delete data.createdAt;
    if (data.assignedDate) data.assignedDate = new Date(data.assignedDate);
    if (data.returnDate) data.returnDate = new Date(data.returnDate);
    if (data.photos && typeof data.photos === 'object') data.photos = JSON.stringify(data.photos);
    const tool = await prisma.employeeTool.update({ where: { id: parseInt(req.params.tid) }, data });
    res.json(tool);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/tools/:tid', authenticate, async (req, res) => {
  try {
    if (!['admin','manager','coordinator'].includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    await prisma.employeeTool.delete({ where: { id: parseInt(req.params.tid) } });
    res.json({ message: 'Tool deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── COMPLAINTS ────────────────────────────────────────────────────────────────
router.get('/:id/complaints', authenticate, requirePermission('complaints'), async (req, res) => {
  try {
    const complaints = await prisma.employeeComplaint.findMany({
      where: { employeeId: parseInt(req.params.id) }, orderBy: { date: 'desc' }
    });
    res.json(complaints);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/complaints', authenticate, requirePermission('complaints'), async (req, res) => {
  try {
    const data = { ...req.body, employeeId: parseInt(req.params.id) };
    if (data.date) data.date = new Date(data.date);
    if (data.attachments && typeof data.attachments === 'object') data.attachments = JSON.stringify(data.attachments);
    const complaint = await prisma.employeeComplaint.create({ data });
    res.status(201).json(complaint);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id/complaints/:cid', authenticate, requirePermission('complaints'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.employeeId; delete data.createdAt;
    if (data.date) data.date = new Date(data.date);
    if (data.attachments && typeof data.attachments === 'object') data.attachments = JSON.stringify(data.attachments);
    const complaint = await prisma.employeeComplaint.update({ where: { id: parseInt(req.params.cid) }, data });
    res.json(complaint);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/complaints/:cid', authenticate, async (req, res) => {
  try {
    if (!['admin','manager'].includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    await prisma.employeeComplaint.delete({ where: { id: parseInt(req.params.cid) } });
    res.json({ message: 'Complaint deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── DOCUMENTS ─────────────────────────────────────────────────────────────────
router.get('/:id/documents', authenticate, requirePermission('allFiles'), async (req, res) => {
  try {
    const documents = await prisma.employeeDocument.findMany({
      where: { employeeId: parseInt(req.params.id) }, orderBy: { createdAt: 'desc' },
      select: { id: true, name: true, category: true, fileType: true, fileSize: true, expiryDate: true, version: true, notes: true, createdAt: true }
    });
    res.json(documents);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id/documents/:did/download', authenticate, requirePermission('allFiles'), async (req, res) => {
  try {
    const doc = await prisma.employeeDocument.findUnique({ where: { id: parseInt(req.params.did) } });
    if (!doc) return res.status(404).json({ error: 'Document not found' });
    res.json(doc);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/documents', authenticate, requirePermission('allFiles'), async (req, res) => {
  try {
    const data = { ...req.body, employeeId: parseInt(req.params.id) };
    if (data.expiryDate) data.expiryDate = new Date(data.expiryDate);
    if (data.fileSize) data.fileSize = parseInt(data.fileSize);
    const doc = await prisma.employeeDocument.create({ data });
    res.status(201).json(doc);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/documents/:did', authenticate, async (req, res) => {
  try {
    if (!['admin','manager','coordinator'].includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    await prisma.employeeDocument.delete({ where: { id: parseInt(req.params.did) } });
    res.json({ message: 'Document deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Import missing ROLE_PERMISSIONS for the GET /:id handler
const { ROLE_PERMISSIONS } = require('../middleware/auth');

module.exports = router;

// ── ATTENDANCE ────────────────────────────────────────────────────────────────
// ── Helper: get actual columns of EmployeeAttendance ─────────────────────────
async function getAttendanceCols() {
  const info = await prisma.$queryRawUnsafe(`PRAGMA table_info("EmployeeAttendance")`);
  // Ensure table has required optional columns, add if missing
  const existing = info.map(c => c.name);
  const optional = [
    { name: 'checkIn',     type: 'TEXT' },
    { name: 'checkOut',    type: 'TEXT' },
    { name: 'hoursWorked', type: 'REAL' },
    { name: 'overtime',    type: 'REAL' },
    { name: 'notes',       type: 'TEXT' },
    { name: 'approvedBy',  type: 'TEXT' },
  ];
  for (const col of optional) {
    if (!existing.includes(col.name)) {
      await prisma.$queryRawUnsafe(`ALTER TABLE "EmployeeAttendance" ADD COLUMN "${col.name}" ${col.type}`);
    }
  }
  // Re-fetch after potential alterations
  const info2 = await prisma.$queryRawUnsafe(`PRAGMA table_info("EmployeeAttendance")`);
  return info2.map(c => c.name);
}

router.get('/:id/attendance', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const empId = parseInt(req.params.id);
    const { month, year } = req.query;
    let records;
    if (month && year) {
      const m = String(parseInt(month)).padStart(2,'0');
      const y = parseInt(year);
      records = await prisma.$queryRawUnsafe(
        `SELECT * FROM "EmployeeAttendance" WHERE employeeId = ? AND strftime('%Y-%m', date) = ? ORDER BY date DESC`,
        empId, `${y}-${m}`
      );
    } else {
      records = await prisma.$queryRawUnsafe(
        `SELECT * FROM "EmployeeAttendance" WHERE employeeId = ? ORDER BY date DESC`,
        empId
      );
    }
    res.json(records);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/attendance', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const empId      = parseInt(req.params.id);
    const date       = new Date(req.body.date).toISOString();
    const status     = req.body.status     || 'present';
    const checkIn    = req.body.checkIn    || null;
    const checkOut   = req.body.checkOut   || null;
    const hoursWorked= parseFloat(req.body.hoursWorked) || 0;
    const overtime   = parseFloat(req.body.overtime)    || 0;
    const notes      = req.body.notes      || null;
    const approvedBy = req.body.approvedBy || null;

    // Ensure columns exist, get actual column list
    const cols = await getAttendanceCols();
    const hasUpdatedAt = cols.includes('updatedAt');

    const colList = ['employeeId','date','status','checkIn','checkOut','hoursWorked','overtime','notes','approvedBy','createdAt'];
    const valList = [empId, date, status, checkIn, checkOut, hoursWorked, overtime, notes, approvedBy, "datetime('now')"];
    if (hasUpdatedAt) { colList.push('updatedAt'); valList.push("datetime('now')"); }

    const placeholders = valList.map((v,i) => typeof v === 'string' && v.startsWith('datetime') ? v : '?').join(',');
    const bindValues   = valList.filter(v => !(typeof v === 'string' && v.startsWith('datetime')));

    await prisma.$queryRawUnsafe(
      `INSERT INTO "EmployeeAttendance" (${colList.join(',')}) VALUES (${placeholders})`,
      ...bindValues
    );

    const records = await prisma.$queryRawUnsafe(
      `SELECT * FROM "EmployeeAttendance" WHERE employeeId = ? ORDER BY id DESC LIMIT 1`, empId
    );
    res.status(201).json(records[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id/attendance/:aid', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const aid        = parseInt(req.params.aid);
    const status     = req.body.status     || 'present';
    const checkIn    = req.body.checkIn    || null;
    const checkOut   = req.body.checkOut   || null;
    const hoursWorked= parseFloat(req.body.hoursWorked) || 0;
    const overtime   = parseFloat(req.body.overtime)    || 0;
    const notes      = req.body.notes      || null;
    const approvedBy = req.body.approvedBy || null;

    const cols = await getAttendanceCols();
    const hasUpdatedAt = cols.includes('updatedAt');

    let sql = `UPDATE "EmployeeAttendance" SET status=?, checkIn=?, checkOut=?, hoursWorked=?, overtime=?, notes=?, approvedBy=?`;
    if (hasUpdatedAt) sql += `, updatedAt=datetime('now')`;
    sql += ` WHERE id=?`;

    await prisma.$queryRawUnsafe(sql, status, checkIn, checkOut, hoursWorked, overtime, notes, approvedBy, aid);

    const records = await prisma.$queryRawUnsafe(`SELECT * FROM "EmployeeAttendance" WHERE id = ?`, aid);
    res.json(records[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/attendance/:aid', authenticate, async (req, res) => {
  try {
    if (!['admin','manager','coordinator'].includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    await prisma.$queryRawUnsafe(`DELETE FROM "EmployeeAttendance" WHERE id = ?`, parseInt(req.params.aid));
    res.json({ message: 'Record deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── FINES ─────────────────────────────────────────────────────────────────────
router.get('/:id/fines', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const fines = await prisma.employeeFine.findMany({
      where: { employeeId: parseInt(req.params.id) },
      orderBy: { createdAt: 'desc' }
    });
    res.json(fines);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/fines', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = { ...req.body, employeeId: parseInt(req.params.id) };
    data.amount = parseFloat(data.amount);
    if (data.deductionDate) data.deductionDate = new Date(data.deductionDate);
    const fine = await prisma.employeeFine.create({ data });
    res.status(201).json(fine);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id/fines/:fid', authenticate, requirePermission('employees'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.employeeId; delete data.createdAt;
    if (data.amount) data.amount = parseFloat(data.amount);
    if (data.deductionDate) data.deductionDate = new Date(data.deductionDate);
    const fine = await prisma.employeeFine.update({
      where: { id: parseInt(req.params.fid) }, data
    });
    res.json(fine);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id/fines/:fid', authenticate, async (req, res) => {
  try {
    if (!['admin','manager'].includes(req.user.role)) return res.status(403).json({ error: 'Admin/Manager only' });
    await prisma.employeeFine.delete({ where: { id: parseInt(req.params.fid) } });
    res.json({ message: 'Fine deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
