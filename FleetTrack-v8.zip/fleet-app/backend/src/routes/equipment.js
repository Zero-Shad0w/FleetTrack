const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const { vehicleId, weekNumber } = req.query;
    const where = {};
    if (vehicleId) where.vehicleId = parseInt(vehicleId);
    if (weekNumber) where.weekNumber = parseInt(weekNumber);
    const checks = await prisma.equipmentCheck.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: { vehicle: { select: { vehicleId: true, make: true, model: true, licensePlate: true } } }
    });
    res.json(checks);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/batch', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const { vehicleId, inspectionDate, inspectorName, weekNumber, items } = req.body;
    const created = await prisma.$transaction(
      items.map(item => prisma.equipmentCheck.create({
        data: {
          vehicleId: parseInt(vehicleId),
          inspectionDate: new Date(inspectionDate),
          inspectorName,
          weekNumber: weekNumber ? parseInt(weekNumber) : null,
          equipmentItem: item.equipmentItem,
          present: item.present,
          condition: item.condition,
          notes: item.notes || null
        }
      }))
    );
    res.status(201).json(created);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    data.vehicleId = parseInt(data.vehicleId);
    data.inspectionDate = new Date(data.inspectionDate);
    if (data.weekNumber) data.weekNumber = parseInt(data.weekNumber);
    const check = await prisma.equipmentCheck.create({ data });
    res.status(201).json(check);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.createdAt; delete data.vehicle;
    if (data.vehicleId) data.vehicleId = parseInt(data.vehicleId);
    if (data.inspectionDate) data.inspectionDate = new Date(data.inspectionDate);
    if (data.weekNumber) data.weekNumber = parseInt(data.weekNumber);
    const check = await prisma.equipmentCheck.update({ where: { id: parseInt(req.params.id) }, data });
    res.json(check);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    await prisma.equipmentCheck.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Equipment check deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
