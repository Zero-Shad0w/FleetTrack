const express = require('express');
const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, logActivity } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

const DB_PATH = path.join(__dirname, '../../prisma/fleet.db');
const BACKUP_DIR = path.join(__dirname, '../../backups');

// Ensure backups folder exists
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

// List all backups
router.get('/', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith('.db'))
      .map(f => {
        const fp = path.join(BACKUP_DIR, f);
        const stat = fs.statSync(fp);
        return { filename: f, size: stat.size, createdAt: stat.birthtime };
      })
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Also get DB records
    const records = await prisma.backup.findMany({ orderBy: { createdAt: 'desc' } });
    res.json({ backups: files, records });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Create manual backup
router.post('/create', authenticate, requireRole('admin'), async (req, res) => {
  try {
    if (!fs.existsSync(DB_PATH)) return res.status(404).json({ error: 'Database file not found' });

    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `fleet-backup-${ts}.db`;
    const destPath = path.join(BACKUP_DIR, filename);

    fs.copyFileSync(DB_PATH, destPath);
    const size = fs.statSync(destPath).size;

    await prisma.backup.create({
      data: { filename, size, createdBy: req.user.username }
    });
    await logActivity(req.user.id, 'CREATE_BACKUP', `Created backup: ${filename}`);

    res.json({ message: 'Backup created successfully', filename, size });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Download a backup
router.get('/download/:filename', authenticate, requireRole('admin'), (req, res) => {
  try {
    const filename = path.basename(req.params.filename); // sanitize
    const filePath = path.join(BACKUP_DIR, filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Backup not found' });
    res.download(filePath, filename);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Restore from a backup file (by filename in backups folder)
router.post('/restore/:filename', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const filename = path.basename(req.params.filename);
    const sourcePath = path.join(BACKUP_DIR, filename);
    if (!fs.existsSync(sourcePath)) return res.status(404).json({ error: 'Backup file not found' });

    // Create a safety backup before restore
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const safetyName = `pre-restore-${ts}.db`;
    fs.copyFileSync(DB_PATH, path.join(BACKUP_DIR, safetyName));

    // Copy backup over live db
    fs.copyFileSync(sourcePath, DB_PATH);
    await logActivity(req.user.id, 'RESTORE_BACKUP', `Restored from: ${filename}`);

    res.json({ message: `Database restored from ${filename}. A safety backup was created as ${safetyName}. Please restart the server.` });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Delete a backup
router.delete('/:filename', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const filename = path.basename(req.params.filename);
    const filePath = path.join(BACKUP_DIR, filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Backup not found' });
    fs.unlinkSync(filePath);
    await prisma.backup.deleteMany({ where: { filename } });
    await logActivity(req.user.id, 'DELETE_BACKUP', `Deleted backup: ${filename}`);
    res.json({ message: 'Backup deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Upload a backup file to restore from
router.post('/upload', authenticate, requireRole('admin'), express.raw({ type: 'application/octet-stream', limit: '200mb' }), async (req, res) => {
  try {
    const filename = req.headers['x-filename'] || `uploaded-${Date.now()}.db`;
    const safeName = path.basename(filename);
    const destPath = path.join(BACKUP_DIR, safeName);
    fs.writeFileSync(destPath, req.body);
    const size = fs.statSync(destPath).size;
    await prisma.backup.create({ data: { filename: safeName, size, createdBy: `Upload by ${req.user.username}` } });
    await logActivity(req.user.id, 'UPLOAD_BACKUP', `Uploaded backup: ${safeName}`);
    res.json({ message: 'Backup uploaded successfully', filename: safeName, size });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
