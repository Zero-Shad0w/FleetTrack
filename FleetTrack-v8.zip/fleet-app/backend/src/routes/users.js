const express = require('express');
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, logActivity } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// GET all users (admin only)
router.get('/', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: { id: true, username: true, email: true, role: true, active: true, lastLogin: true, createdAt: true },
      orderBy: { createdAt: 'desc' }
    });
    res.json(users);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET activity logs
router.get('/activity', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const logs = await prisma.activityLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: { user: { select: { username: true, role: true } } }
    });
    res.json(logs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// CREATE user
router.post('/', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const { username, email, password, role = 'viewer' } = req.body;
    if (!username || !email || !password) return res.status(400).json({ error: 'All fields required' });
    const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
    if (existing) return res.status(400).json({ error: 'Username or email already exists' });
    const hashed = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: { username, email, password: hashed, role },
      select: { id: true, username: true, email: true, role: true, active: true, createdAt: true }
    });
    await logActivity(req.user.id, 'CREATE_USER', `Created user: ${username} (${role})`);
    res.status(201).json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// UPDATE user
router.put('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const { username, email, role, active } = req.body;
    const data = {};
    if (username) data.username = username;
    if (email) data.email = email;
    if (role) data.role = role;
    if (typeof active === 'boolean') data.active = active;
    const user = await prisma.user.update({
      where: { id: parseInt(req.params.id) },
      data,
      select: { id: true, username: true, email: true, role: true, active: true, lastLogin: true, createdAt: true }
    });
    await logActivity(req.user.id, 'UPDATE_USER', `Updated user: ${user.username}`);
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// RESET password
router.put('/:id/reset-password', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    const hashed = await bcrypt.hash(newPassword, 10);
    const user = await prisma.user.update({ where: { id: parseInt(req.params.id) }, data: { password: hashed } });
    await logActivity(req.user.id, 'RESET_PASSWORD', `Reset password for: ${user.username}`);
    res.json({ message: 'Password reset successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// TOGGLE active
router.put('/:id/toggle-active', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const current = await prisma.user.findUnique({ where: { id: parseInt(req.params.id) } });
    if (!current) return res.status(404).json({ error: 'User not found' });
    if (current.id === req.user.id) return res.status(400).json({ error: 'Cannot disable your own account' });
    const user = await prisma.user.update({
      where: { id: parseInt(req.params.id) },
      data: { active: !current.active },
      select: { id: true, username: true, active: true }
    });
    await logActivity(req.user.id, user.active ? 'ENABLE_USER' : 'DISABLE_USER', `${user.active ? 'Enabled' : 'Disabled'} user: ${user.username}`);
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE user
router.delete('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete your own account' });
    const user = await prisma.user.findUnique({ where: { id: parseInt(req.params.id) } });
    await prisma.user.delete({ where: { id: parseInt(req.params.id) } });
    await logActivity(req.user.id, 'DELETE_USER', `Deleted user: ${user?.username}`);
    res.json({ message: 'User deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
