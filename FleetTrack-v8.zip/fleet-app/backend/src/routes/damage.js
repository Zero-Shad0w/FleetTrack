const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const { vehicleId } = req.query;
    const where = vehicleId ? { vehicleId: parseInt(vehicleId) } : {};
    const inspections = await prisma.damageInspection.findMany({
      where, orderBy: { inspectionDate: 'desc' },
      include: { vehicle: { select: { vehicleId: true, make: true, model: true, licensePlate: true } } }
    });
    res.json(inspections);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', authenticate, async (req, res) => {
  try {
    const inspection = await prisma.damageInspection.findUnique({
      where: { id: parseInt(req.params.id) },
      include: { vehicle: true }
    });
    if (!inspection) return res.status(404).json({ error: 'Inspection not found' });
    res.json(inspection);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

const prepareData = (data) => {
  if (data.vehicleId) data.vehicleId = parseInt(data.vehicleId);
  if (data.inspectionDate) data.inspectionDate = new Date(data.inspectionDate);
  if (data.mileage) data.mileage = parseInt(data.mileage);
  ['frontDamageMarkers','rearDamageMarkers','sideDamageMarkers','leftDamageMarkers','rightDamageMarkers','topDamageMarkers','photos'].forEach(key => {
    if (data[key] && typeof data[key] === 'object') data[key] = JSON.stringify(data[key]);
  });
  return data;
};

router.post('/', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = prepareData({ ...req.body });
    const inspection = await prisma.damageInspection.create({
      data,
      include: { vehicle: { select: { vehicleId: true, make: true, model: true } } }
    });
    res.status(201).json(inspection);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = prepareData({ ...req.body });
    delete data.id; delete data.createdAt; delete data.vehicle;
    const inspection = await prisma.damageInspection.update({
      where: { id: parseInt(req.params.id) }, data
    });
    res.json(inspection);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    await prisma.damageInspection.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Inspection deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
