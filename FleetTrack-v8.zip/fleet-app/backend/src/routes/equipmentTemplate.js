const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma  = new PrismaClient();

// GET template for a vehicle
router.get('/template/:vehicleId', authenticate, async (req, res) => {
  try {
    const items = await prisma.equipmentTemplate.findMany({
      where: { vehicleId: parseInt(req.params.vehicleId) },
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }]
    });
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// SAVE (replace) template for a vehicle
router.post('/template/:vehicleId', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const vehicleId = parseInt(req.params.vehicleId);
    const { items } = req.body; // array of { itemName, category, required, sortOrder }
    if (!Array.isArray(items)) return res.status(400).json({ error: 'items must be an array' });

    // Replace all template items for this vehicle
    await prisma.equipmentTemplate.deleteMany({ where: { vehicleId } });
    const created = await prisma.equipmentTemplate.createMany({
      data: items.map((item, idx) => ({
        vehicleId,
        itemName:  item.itemName,
        category:  item.category  || null,
        required:  item.required  !== false,
        sortOrder: item.sortOrder || idx,
      }))
    });
    const template = await prisma.equipmentTemplate.findMany({
      where: { vehicleId }, orderBy: [{ sortOrder: 'asc' }]
    });
    res.json(template);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ADD single item to template
router.post('/template/:vehicleId/item', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const vehicleId = parseInt(req.params.vehicleId);
    const count = await prisma.equipmentTemplate.count({ where: { vehicleId } });
    const item = await prisma.equipmentTemplate.create({
      data: {
        vehicleId,
        itemName:  req.body.itemName,
        category:  req.body.category || null,
        required:  req.body.required !== false,
        sortOrder: count,
      }
    });
    res.status(201).json(item);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE single template item
router.delete('/template/:vehicleId/item/:id', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    await prisma.equipmentTemplate.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Item removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// LOAD template into a new equipment check (pre-populate)
router.get('/template/:vehicleId/load', authenticate, async (req, res) => {
  try {
    const vehicleId = parseInt(req.params.vehicleId);
    const [template, vehicle] = await Promise.all([
      prisma.equipmentTemplate.findMany({
        where: { vehicleId }, orderBy: [{ sortOrder: 'asc' }]
      }),
      prisma.vehicle.findUnique({ where: { id: vehicleId } })
    ]);
    res.json({ template, vehicle });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
