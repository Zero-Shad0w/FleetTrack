const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Generate full vehicle PDF report as HTML (printed via browser)
router.get('/vehicle/:id', authenticate, async (req, res) => {
  try {
    const vehicle = await prisma.vehicle.findUnique({
      where: { id: parseInt(req.params.id) },
      include: {
        repairs: { orderBy: { repairDate: 'desc' } },
        damageInspections: { orderBy: { inspectionDate: 'desc' } },
        equipmentChecks: { orderBy: { createdAt: 'desc' } },
        weeklyLogs: { orderBy: { inspectionDate: 'desc' } },
      }
    });
    if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });

    const fmt = (d) => d ? new Date(d).toLocaleDateString('de-DE', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
    const fmtCost = (n) => `€${(n || 0).toLocaleString('de-DE', { minimumFractionDigits: 2 })}`;
    const totalRepairCost = vehicle.repairs.reduce((s, r) => s + (r.totalCost || 0), 0);
    const generatedAt = new Date().toLocaleString('de-DE');

    const parseJSON = (s) => { try { return JSON.parse(s || '[]'); } catch { return []; } };

    const totalMarkers = (insp) =>
      ['frontDamageMarkers','rearDamageMarkers','sideDamageMarkers','topDamageMarkers']
        .reduce((s, k) => s + parseJSON(insp[k]).length, 0);

    // Build equipment grouped by date
    const equipGroups = vehicle.equipmentChecks.reduce((acc, item) => {
      const key = item.inspectionDate.toISOString().split('T')[0];
      if (!acc[key]) acc[key] = { date: item.inspectionDate, inspector: item.inspectorName, items: [] };
      acc[key].items.push(item);
      return acc;
    }, {});

    // Damage photos as inline images
    const buildPhotoSection = (insp) => {
      const photos = parseJSON(insp.photos);
      if (!photos.length) return '';
      return `
        <div class="photo-grid">
          ${photos.map(p => `
            <div class="photo-item">
              <img src="${p.dataUrl}" alt="${p.name || 'Damage photo'}" />
              ${p.caption ? `<p class="photo-caption">${p.caption}</p>` : ''}
            </div>
          `).join('')}
        </div>`;
    };

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>Vehicle Report — ${vehicle.vehicleId}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; color: #1a1a1a; background: white; }
  .page { padding: 28px 32px; max-width: 900px; margin: 0 auto; }

  /* Header */
  .report-header { background: #1d4ed8; color: white; padding: 20px 24px; border-radius: 10px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-start; }
  .report-header h1 { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
  .report-header .sub { font-size: 12px; opacity: 0.8; }
  .report-header .meta { text-align: right; font-size: 10px; opacity: 0.75; }

  /* Sections */
  .section { margin-bottom: 22px; page-break-inside: avoid; }
  .section-title { font-size: 13px; font-weight: 700; color: #1d4ed8; border-bottom: 2px solid #dbeafe; padding-bottom: 6px; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
  .section-title::before { content: ''; display: inline-block; width: 4px; height: 16px; background: #1d4ed8; border-radius: 2px; }

  /* Info grid */
  .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
  .info-item { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; }
  .info-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; margin-bottom: 2px; }
  .info-value { font-size: 11px; font-weight: 600; color: #0f172a; }

  /* Tables */
  table { width: 100%; border-collapse: collapse; font-size: 10px; }
  th { background: #f1f5f9; padding: 7px 8px; text-align: left; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; }
  td { padding: 6px 8px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  tr:nth-child(even) td { background: #fafafa; }
  .total-row td { background: #eff6ff !important; font-weight: 700; color: #1d4ed8; border-top: 2px solid #bfdbfe; }

  /* Badges */
  .badge { display: inline-block; padding: 2px 7px; border-radius: 9999px; font-size: 9px; font-weight: 600; }
  .badge-green { background: #dcfce7; color: #166534; }
  .badge-red { background: #fee2e2; color: #991b1b; }
  .badge-blue { background: #dbeafe; color: #1e40af; }
  .badge-orange { background: #ffedd5; color: #9a3412; }

  /* Photos */
  .photo-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 8px; }
  .photo-item img { width: 100%; height: 120px; object-fit: cover; border-radius: 6px; border: 1px solid #e2e8f0; }
  .photo-caption { font-size: 9px; color: #64748b; margin-top: 3px; text-align: center; }

  /* Summary cards */
  .summary-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; }
  .summary-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center; }
  .summary-card .val { font-size: 18px; font-weight: 700; color: #1d4ed8; }
  .summary-card .lbl { font-size: 9px; color: #64748b; text-transform: uppercase; margin-top: 2px; }

  /* Damage markers legend */
  .damage-legend { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 8px; }
  .damage-legend-item { display: flex; align-items: center; gap: 4px; font-size: 9px; }
  .legend-dot { width: 10px; height: 10px; border-radius: 50%; }

  /* Equipment check */
  .equip-item { display: inline-flex; align-items: center; gap: 4px; margin: 2px; padding: 2px 6px; border-radius: 4px; font-size: 9px; }
  .equip-present { background: #dcfce7; color: #166534; }
  .equip-missing { background: #fee2e2; color: #991b1b; }

  /* Footer */
  .footer { margin-top: 28px; padding-top: 14px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 9px; color: #94a3b8; }

  /* Page break */
  .page-break { page-break-before: always; }
  @media print {
    body { font-size: 10px; }
    .page { padding: 16px 20px; }
  }
</style>
</head>
<body>
<div class="page">

  <!-- Header -->
  <div class="report-header">
    <div>
      <h1>FleetTrack Pro — Vehicle Report</h1>
      <div class="sub">${vehicle.vehicleId} &nbsp;·&nbsp; ${vehicle.make} ${vehicle.model} &nbsp;·&nbsp; ${vehicle.licensePlate}</div>
    </div>
    <div class="meta">
      <div>Generated: ${generatedAt}</div>
      <div>${vehicle.companyName || 'Fleet Management'}</div>
    </div>
  </div>

  <!-- Summary Cards -->
  <div class="summary-cards">
    <div class="summary-card"><div class="val">${vehicle.repairs.length}</div><div class="lbl">Total Repairs</div></div>
    <div class="summary-card"><div class="val">${fmtCost(totalRepairCost)}</div><div class="lbl">Repair Cost</div></div>
    <div class="summary-card"><div class="val">${vehicle.damageInspections.length}</div><div class="lbl">Inspections</div></div>
    <div class="summary-card"><div class="val">${vehicle.weeklyLogs.length}</div><div class="lbl">Weekly Logs</div></div>
  </div>

  <!-- Vehicle Details -->
  <div class="section">
    <div class="section-title">Vehicle Information</div>
    <div class="info-grid">
      ${[
        ['Vehicle ID', vehicle.vehicleId], ['License Plate', vehicle.licensePlate], ['VIN Number', vehicle.vinNumber],
        ['Make', vehicle.make], ['Model', vehicle.model], ['Year', vehicle.year],
        ['Color', vehicle.color], ['Fuel Type', vehicle.fuelType], ['Transmission', vehicle.transmission],
        ['Company', vehicle.companyName], ['Assigned To', vehicle.assignedEmployee], ['Department', vehicle.department],
        ['Insurance Provider', vehicle.insuranceProvider], ['Insurance Expiry', fmt(vehicle.insuranceExpiry)], ['Reg. Expiry', fmt(vehicle.registrationExpiry)],
        ['Service Due', fmt(vehicle.serviceDueDate)], ['Current Mileage', vehicle.mileage ? `${vehicle.mileage.toLocaleString()} km` : '—'], ['Notes', vehicle.notes],
      ].map(([l, v]) => `
        <div class="info-item">
          <div class="info-label">${l}</div>
          <div class="info-value">${v || '—'}</div>
        </div>
      `).join('')}
    </div>
  </div>

  <!-- Repairs -->
  <div class="section">
    <div class="section-title">Repairs & Maintenance (${vehicle.repairs.length} records)</div>
    ${vehicle.repairs.length === 0 ? '<p style="color:#94a3b8;font-size:10px;">No repairs recorded.</p>' : `
    <table>
      <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Workshop</th><th>Mileage</th><th>Labour</th><th>Parts</th><th>Total</th><th>Invoice</th><th>Authorised By</th></tr></thead>
      <tbody>
        ${vehicle.repairs.map(r => `
          <tr>
            <td>${fmt(r.repairDate)}</td>
            <td>${r.description}</td>
            <td><span class="badge badge-blue">${r.category || '—'}</span></td>
            <td>${r.workshop || '—'}</td>
            <td>${r.mileage ? r.mileage.toLocaleString() + ' km' : '—'}</td>
            <td>${fmtCost(r.labourCost)}</td>
            <td>${fmtCost(r.partsCost)}</td>
            <td><strong>${fmtCost(r.totalCost)}</strong></td>
            <td>${r.invoiceNumber || '—'}</td>
            <td>${r.authorisedBy || '—'}</td>
          </tr>
        `).join('')}
        <tr class="total-row">
          <td colspan="7">TOTAL REPAIR COST</td>
          <td colspan="3">${fmtCost(totalRepairCost)}</td>
        </tr>
      </tbody>
    </table>`}
  </div>

  <!-- Damage Inspections -->
  <div class="section page-break">
    <div class="section-title">Damage Inspections (${vehicle.damageInspections.length} records)</div>
    ${vehicle.damageInspections.length === 0 ? '<p style="color:#94a3b8;font-size:10px;">No damage inspections recorded.</p>' : 
      vehicle.damageInspections.map(insp => `
        <div style="border:1px solid #e2e8f0;border-radius:8px;padding:12px;margin-bottom:12px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <div>
              <strong style="font-size:12px;">${fmt(insp.inspectionDate)}</strong>
              <span style="color:#64748b;margin-left:8px;">Inspector: ${insp.inspectorName}</span>
              ${insp.mileage ? `<span style="color:#64748b;margin-left:8px;">${insp.mileage.toLocaleString()} km</span>` : ''}
            </div>
            <div>
              ${totalMarkers(insp) > 0 
                ? `<span class="badge badge-red">${totalMarkers(insp)} damage markers</span>` 
                : `<span class="badge badge-green">No damage markers</span>`}
              ${parseJSON(insp.photos).length > 0 
                ? `<span class="badge badge-blue" style="margin-left:4px;">${parseJSON(insp.photos).length} photos</span>` 
                : ''}
            </div>
          </div>
          ${insp.damageNotes ? `<div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:4px;padding:6px 10px;margin-bottom:8px;font-size:10px;color:#9a3412;"><strong>Notes:</strong> ${insp.damageNotes}</div>` : ''}
          ${insp.signature ? `<div style="font-size:10px;color:#64748b;">Signed: <em>${insp.signature}</em></div>` : ''}
          ${buildPhotoSection(insp)}
        </div>
      `).join('')
    }
  </div>

  <!-- Weekly Logs -->
  <div class="section">
    <div class="section-title">Weekly Inspection Logs (${vehicle.weeklyLogs.length} records)</div>
    ${vehicle.weeklyLogs.length === 0 ? '<p style="color:#94a3b8;font-size:10px;">No weekly logs recorded.</p>' : `
    <table>
      <thead><tr><th>Date</th><th>Employee</th><th>Mileage</th><th>Fuel</th><th>Damage</th><th>Equipment</th><th>Comments</th><th>Signature</th></tr></thead>
      <tbody>
        ${vehicle.weeklyLogs.map(log => `
          <tr>
            <td>${fmt(log.inspectionDate)}</td>
            <td>${log.employeeName}</td>
            <td>${log.mileage ? log.mileage.toLocaleString() + ' km' : '—'}</td>
            <td>${log.fuelLevel || '—'}</td>
            <td><span class="badge ${log.damageFound ? 'badge-red' : 'badge-green'}">${log.damageFound ? 'Yes' : 'None'}</span></td>
            <td><span class="badge ${log.equipmentComplete ? 'badge-green' : 'badge-red'}">${log.equipmentComplete ? 'Complete' : 'Incomplete'}</span></td>
            <td>${log.comments || '—'}</td>
            <td><em>${log.signature || '—'}</em></td>
          </tr>
        `).join('')}
      </tbody>
    </table>`}
  </div>

  <!-- Equipment Checks -->
  <div class="section">
    <div class="section-title">Equipment Check History</div>
    ${Object.keys(equipGroups).length === 0 ? '<p style="color:#94a3b8;font-size:10px;">No equipment checks recorded.</p>' :
      Object.entries(equipGroups).slice(0, 10).map(([key, group]) => {
        const missing = group.items.filter(i => !i.present).length;
        return `
          <div style="border:1px solid #e2e8f0;border-radius:6px;padding:10px;margin-bottom:8px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
              <strong>${fmt(group.date)} — ${group.inspector}</strong>
              <span class="badge ${missing > 0 ? 'badge-red' : 'badge-green'}">${missing > 0 ? `${missing} missing` : 'All present'}</span>
            </div>
            <div>
              ${group.items.map(item => `
                <span class="equip-item ${item.present ? 'equip-present' : 'equip-missing'}">
                  ${item.present ? '✓' : '✗'} ${item.equipmentItem}${item.condition && item.condition !== 'N/A' ? ` (${item.condition})` : ''}
                </span>
              `).join('')}
            </div>
          </div>
        `;
      }).join('')
    }
  </div>

  <!-- Footer -->
  <div class="footer">
    <div>FleetTrack Pro — Vehicle Inspection Management System</div>
    <div>Report generated: ${generatedAt} &nbsp;·&nbsp; Vehicle: ${vehicle.vehicleId}</div>
  </div>

</div>
</body>
</html>`;

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
