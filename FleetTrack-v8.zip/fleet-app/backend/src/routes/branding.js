const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// GET branding (public — needed for login page)
router.get('/', async (req, res) => {
  try {
    let branding = await prisma.brandingSettings.findFirst();
    if (!branding) {
      branding = await prisma.brandingSettings.create({
        data: { softwareName: 'FleetTrack Pro' }
      });
    }
    // Never send full logo on list — only name and colors
    const { logoData, ...safe } = branding;
    safe.hasLogo = !!logoData;
    res.json(safe);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET full branding including logo (authenticated)
router.get('/full', authenticate, async (req, res) => {
  try {
    let branding = await prisma.brandingSettings.findFirst();
    if (!branding) branding = await prisma.brandingSettings.create({ data: {} });
    res.json(branding);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// UPDATE branding (admin only)
router.put('/', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const {
      softwareName, logoData, primaryColor, secondaryColor, accentColor,
      sidebarColor, textColor, darkPrimary, darkSidebar
    } = req.body;

    let branding = await prisma.brandingSettings.findFirst();
    const data = {
      updatedBy: req.user.username,
      updatedAt: new Date(),
    };

    if (softwareName !== undefined)   data.softwareName   = softwareName;
    if (logoData !== undefined)       data.logoData       = logoData;
    if (primaryColor !== undefined)   data.primaryColor   = primaryColor;
    if (secondaryColor !== undefined) data.secondaryColor = secondaryColor;
    if (accentColor !== undefined)    data.accentColor    = accentColor;
    if (sidebarColor !== undefined)   data.sidebarColor   = sidebarColor;
    if (textColor !== undefined)      data.textColor      = textColor;
    if (darkPrimary !== undefined)    data.darkPrimary    = darkPrimary;
    if (darkSidebar !== undefined)    data.darkSidebar    = darkSidebar;

    if (branding) {
      branding = await prisma.brandingSettings.update({ where: { id: branding.id }, data });
    } else {
      branding = await prisma.brandingSettings.create({ data });
    }

    const { logoData: ld, ...safe } = branding;
    safe.hasLogo = !!ld;
    res.json(safe);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE logo only
router.delete('/logo', authenticate, requireRole('admin'), async (req, res) => {
  try {
    const branding = await prisma.brandingSettings.findFirst();
    if (branding) {
      await prisma.brandingSettings.update({ where: { id: branding.id }, data: { logoData: null } });
    }
    res.json({ message: 'Logo removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
