const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Allowed vehicle fields — prevents unknown field errors if migration hasn't run yet
const VEHICLE_FIELDS = [
  'companyName','vehicleId','licensePlate','vinNumber','make','model','year','color',
  'fuelType','transmission','assignedEmployee','department','insuranceProvider',
  'insuranceExpiry','registrationExpiry','mileage','serviceDueDate','notes',
  'photoFront','photoRear','photoLeft','photoRight','photoTop'
];

const prepareVehicle = (body) => {
  const data = {};
  for (const key of VEHICLE_FIELDS) {
    if (key in body) data[key] = body[key] === '' ? null : body[key];
  }
  if (data.year)               data.year               = data.year    ? parseInt(data.year)    : null;
  if (data.mileage !== undefined) data.mileage          = data.mileage ? parseInt(data.mileage) : null;
  if (data.insuranceExpiry)    data.insuranceExpiry     = new Date(data.insuranceExpiry);
  if (data.registrationExpiry) data.registrationExpiry  = new Date(data.registrationExpiry);
  if (data.serviceDueDate)     data.serviceDueDate       = new Date(data.serviceDueDate);
  return data;
};

router.get('/', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const { search } = req.query;
    const where = search ? {
      OR: [
        { vehicleId:        { contains: search } },
        { licensePlate:     { contains: search } },
        { make:             { contains: search } },
        { model:            { contains: search } },
        { assignedEmployee: { contains: search } },
      ]
    } : {};
    const vehicles = await prisma.vehicle.findMany({ where, orderBy: { createdAt: 'desc' } });
    res.json(vehicles);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const vehicle = await prisma.vehicle.findUnique({
      where: { id: parseInt(req.params.id) },
      include: { repairs: true, damageInspections: true, equipmentChecks: true, weeklyLogs: true }
    });
    if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });
    res.json(vehicle);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', authenticate, requirePermission('vehicles'), requireRole('admin', 'inspector', 'manager'), async (req, res) => {
  try {
    const data = prepareVehicle(req.body);
    if (!data.vehicleId)    return res.status(400).json({ error: 'Vehicle ID is required' });
    if (!data.licensePlate) return res.status(400).json({ error: 'License plate is required' });
    if (!data.make)         return res.status(400).json({ error: 'Make is required' });
    if (!data.model)        return res.status(400).json({ error: 'Model is required' });
    const vehicle = await prisma.vehicle.create({ data });
    res.status(201).json(vehicle);
  } catch (err) {
    if (err.code === 'P2002') return res.status(400).json({ error: 'Vehicle ID already exists' });
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, requirePermission('vehicles'), requireRole('admin', 'inspector', 'manager'), async (req, res) => {
  try {
    const data = prepareVehicle(req.body);
    delete data.vehicleId; // don't allow changing the unique ID
    const vehicle = await prisma.vehicle.update({
      where: { id: parseInt(req.params.id) }, data
    });
    res.json(vehicle);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requirePermission('vehicles'), requireRole('admin'), async (req, res) => {
  try {
    await prisma.vehicle.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Vehicle deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
