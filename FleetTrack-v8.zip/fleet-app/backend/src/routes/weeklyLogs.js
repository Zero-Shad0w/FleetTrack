const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, requirePermission('vehicles'), async (req, res) => {
  try {
    const { vehicleId, employeeName, startDate, endDate, page = 1, limit = 20 } = req.query;
    const where = {};
    if (vehicleId) where.vehicleId = parseInt(vehicleId);
    if (employeeName) where.employeeName = { contains: employeeName };
    if (startDate || endDate) {
      where.inspectionDate = {};
      if (startDate) where.inspectionDate.gte = new Date(startDate);
      if (endDate) where.inspectionDate.lte = new Date(endDate);
    }
    const total = await prisma.weeklyLog.count({ where });
    const logs = await prisma.weeklyLog.findMany({
      where, orderBy: { inspectionDate: 'desc' },
      skip: (parseInt(page) - 1) * parseInt(limit),
      take: parseInt(limit),
      include: { vehicle: { select: { vehicleId: true, make: true, model: true, licensePlate: true } } }
    });
    res.json({ logs, total, page: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    data.vehicleId = parseInt(data.vehicleId);
    data.inspectionDate = new Date(data.inspectionDate);
    if (data.mileage) data.mileage = parseInt(data.mileage);
    const log = await prisma.weeklyLog.create({ data, include: { vehicle: { select: { vehicleId: true, make: true, model: true } } } });
    res.status(201).json(log);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', authenticate, requireRole('admin', 'inspector'), async (req, res) => {
  try {
    const data = { ...req.body };
    delete data.id; delete data.createdAt; delete data.vehicle;
    if (data.vehicleId) data.vehicleId = parseInt(data.vehicleId);
    if (data.inspectionDate) data.inspectionDate = new Date(data.inspectionDate);
    if (data.mileage) data.mileage = parseInt(data.mileage);
    const log = await prisma.weeklyLog.update({ where: { id: parseInt(req.params.id) }, data });
    res.json(log);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requireRole('admin'), async (req, res) => {
  try {
    await prisma.weeklyLog.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ message: 'Log deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
