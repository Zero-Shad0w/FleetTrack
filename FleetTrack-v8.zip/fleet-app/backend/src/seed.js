const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create users
  const adminPass = await bcrypt.hash('admin123', 10);
  const inspectorPass = await bcrypt.hash('inspector123', 10);
  const viewerPass = await bcrypt.hash('viewer123', 10);

  await prisma.user.upsert({ where: { username: 'admin' }, update: {}, create: { username: 'admin', email: 'admin@fleet.com', password: adminPass, role: 'admin' } });
  await prisma.user.upsert({ where: { username: 'inspector1' }, update: {}, create: { username: 'inspector1', email: 'inspector@fleet.com', password: inspectorPass, role: 'inspector' } });
  await prisma.user.upsert({ where: { username: 'viewer1' }, update: {}, create: { username: 'viewer1', email: 'viewer@fleet.com', password: viewerPass, role: 'viewer' } });

  const coordinatorPass = await bcrypt.hash('coordinator123', 10);
  const managerPass     = await bcrypt.hash('manager123', 10);
  await prisma.user.upsert({ where: { username: 'coordinator1' }, update: {}, create: { username: 'coordinator1', email: 'coordinator@fleet.com', password: coordinatorPass, role: 'coordinator' } });
  await prisma.user.upsert({ where: { username: 'manager1' },     update: {}, create: { username: 'manager1',     email: 'manager@fleet.com',     password: managerPass,     role: 'manager' } });

  // Create vehicles
  const v1 = await prisma.vehicle.upsert({
    where: { vehicleId: 'VH-001' }, update: {},
    create: {
      companyName: 'FleetCo Ltd', vehicleId: 'VH-001', licensePlate: 'ABC 123 GP',
      vinNumber: 'WV1ZZZ2KZ9H123456', make: 'Volkswagen', model: 'Caddy', year: 2021,
      color: 'White', fuelType: 'Diesel', transmission: 'Manual',
      assignedEmployee: 'John Smith', department: 'Logistics',
      insuranceProvider: 'Mutual Insurance', insuranceExpiry: new Date('2025-06-30'),
      registrationExpiry: new Date('2025-08-31'), mileage: 45230,
      serviceDueDate: new Date('2025-03-15'), notes: 'Main delivery vehicle'
    }
  });

  const v2 = await prisma.vehicle.upsert({
    where: { vehicleId: 'VH-002' }, update: {},
    create: {
      companyName: 'FleetCo Ltd', vehicleId: 'VH-002', licensePlate: 'DEF 456 GP',
      vinNumber: 'WV1ZZZ2KZ9H654321', make: 'Toyota', model: 'Hilux', year: 2020,
      color: 'Silver', fuelType: 'Diesel', transmission: 'Automatic',
      assignedEmployee: 'Jane Doe', department: 'Operations',
      insuranceProvider: 'Shield Insurance', insuranceExpiry: new Date('2025-09-30'),
      registrationExpiry: new Date('2025-12-31'), mileage: 82100,
      serviceDueDate: new Date('2025-04-01'), notes: 'Utility vehicle'
    }
  });

  const v3 = await prisma.vehicle.upsert({
    where: { vehicleId: 'VH-003' }, update: {},
    create: {
      companyName: 'FleetCo Ltd', vehicleId: 'VH-003', licensePlate: 'GHI 789 GP',
      vinNumber: 'WV1ZZZ2KZ9H789012', make: 'Ford', model: 'Transit', year: 2022,
      color: 'Blue', fuelType: 'Petrol', transmission: 'Manual',
      assignedEmployee: 'Bob Johnson', department: 'Sales',
      insuranceProvider: 'National Insurance', insuranceExpiry: new Date('2025-11-30'),
      registrationExpiry: new Date('2026-01-31'), mileage: 23450,
      serviceDueDate: new Date('2025-05-01'), notes: 'Sales team vehicle'
    }
  });

  // Create repairs
  await prisma.repair.createMany({
    data: [
      { vehicleId: v1.id, repairDate: new Date('2024-11-15'), description: 'Oil change and filter', category: 'Service', workshop: 'QuickLube', mileage: 40000, labourCost: 350, partsCost: 120, totalCost: 470, invoiceNumber: 'INV-001', authorisedBy: 'Fleet Manager' },
      { vehicleId: v1.id, repairDate: new Date('2024-12-10'), description: 'Front brake pads replacement', category: 'Brakes', workshop: 'BrakePro', mileage: 43000, labourCost: 600, partsCost: 450, totalCost: 1050, invoiceNumber: 'INV-002', authorisedBy: 'Fleet Manager' },
      { vehicleId: v2.id, repairDate: new Date('2024-10-20'), description: 'Tyre rotation and balance', category: 'Tyres', workshop: 'TyreWorld', mileage: 78000, labourCost: 250, partsCost: 0, totalCost: 250, invoiceNumber: 'INV-003', authorisedBy: 'Fleet Manager' },
      { vehicleId: v2.id, repairDate: new Date('2024-12-01'), description: 'Air filter replacement', category: 'Service', workshop: 'AutoService', mileage: 81000, labourCost: 200, partsCost: 80, totalCost: 280, invoiceNumber: 'INV-004', authorisedBy: 'Fleet Manager' },
      { vehicleId: v3.id, repairDate: new Date('2024-11-05'), description: 'Windshield wiper blades', category: 'Maintenance', workshop: 'Parts Direct', mileage: 20000, labourCost: 100, partsCost: 150, totalCost: 250, invoiceNumber: 'INV-005', authorisedBy: 'Fleet Manager' },
    ]
  });

  // Create weekly logs
  await prisma.weeklyLog.createMany({
    data: [
      { vehicleId: v1.id, inspectionDate: new Date('2025-01-06'), employeeName: 'John Smith', mileage: 44500, fuelLevel: '75%', damageFound: false, equipmentComplete: true, comments: 'All good', signature: 'J. Smith' },
      { vehicleId: v1.id, inspectionDate: new Date('2025-01-13'), employeeName: 'John Smith', mileage: 45000, fuelLevel: '50%', damageFound: false, equipmentComplete: true, comments: 'Minor scratch on bumper noted', signature: 'J. Smith' },
      { vehicleId: v2.id, inspectionDate: new Date('2025-01-06'), employeeName: 'Jane Doe', mileage: 81500, fuelLevel: '100%', damageFound: false, equipmentComplete: false, comments: 'Missing first aid kit', signature: 'J. Doe' },
    ]
  });

  console.log('Seed complete!');
  console.log('Login credentials:');
  console.log('  Admin:     admin / admin123');
  console.log('  Inspector: inspector1 / inspector123');
  console.log('  Coordinator: coordinator1 / coordinator123');
  console.log('  Manager: manager1 / manager123');
  console.log('  Viewer:    viewer1 / viewer123');
}

main().catch(console.error).finally(() => prisma.$disconnect());
