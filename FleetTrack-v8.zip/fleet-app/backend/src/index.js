require('./load-env');
const express = require('express');
const cors = require('cors');

const authRoutes      = require('./routes/auth');
const vehicleRoutes   = require('./routes/vehicles');
const repairRoutes    = require('./routes/repairs');
const damageRoutes    = require('./routes/damage');
const equipmentRoutes = require('./routes/equipment');
const weeklyLogRoutes = require('./routes/weeklyLogs');
const dashboardRoutes = require('./routes/dashboard');
const userRoutes      = require('./routes/users');
const reportsRoutes   = require('./routes/reports');
const backupRoutes    = require('./routes/backup');
const employeeRoutes  = require('./routes/employees');
const equipmentTemplateRoutes = require('./routes/equipmentTemplate');
const brandingRoutes  = require('./routes/branding');

const app  = express();
const PORT = Number(process.env.FLEET_BACKEND_PORT || process.env.PORT || 3001);
const FRONTEND_PORT = Number(process.env.FLEET_FRONTEND_PORT || 5173);

app.use(cors({ origin: [`http://localhost:${FRONTEND_PORT}`, `http://127.0.0.1:${FRONTEND_PORT}`], credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.use('/api/auth',        authRoutes);
app.use('/api/vehicles',    vehicleRoutes);
app.use('/api/repairs',     repairRoutes);
app.use('/api/damage',      damageRoutes);
app.use('/api/equipment',   equipmentRoutes);
app.use('/api/weekly-logs', weeklyLogRoutes);
app.use('/api/dashboard',   dashboardRoutes);
app.use('/api/users',       userRoutes);
app.use('/api/reports',     reportsRoutes);
app.use('/api/backup',      backupRoutes);
app.use('/api/employees',   employeeRoutes);
app.use('/api/equipment',    equipmentTemplateRoutes);
app.use('/api/branding',    brandingRoutes);

app.get('/api/health', async (req, res) => {
  try {
    const { PrismaClient } = require('@prisma/client');
    const db = new PrismaClient();
    try { await db.$queryRaw`SELECT 1`; res.json({ status: 'ok', database: 'connected', timestamp: new Date() }); }
    finally { await db.$disconnect(); }
  } catch (err) { console.error('Database health check failed:', err.message); res.status(503).json({ status: 'error', database: 'unavailable' }); }
});

// Desktop production UI (browser access remains possible on localhost).
const path = require('path');
const fs = require('fs');
const uiDir = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(path.join(uiDir, 'index.html'))) {
  app.use(express.static(uiDir));
  app.get('*', (req, res) => res.sendFile(path.join(uiDir, 'index.html')));
}

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(PORT, () => console.log(`Fleet Backend running on http://localhost:${PORT}`));
module.exports = app;
