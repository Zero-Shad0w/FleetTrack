# FleetTrack Pro v4 — Neon Command visual refresh

This update is based on the v3 login-reload-fix development package. It updates **appearance only**, keeping the vehicle, employee, inspection, API, authentication, SQLite schema and launcher code intact.

- Default theme is dark on fresh installs; users who explicitly selected light mode retain their preference.
- Near-black navy surfaces, red neon actions, soft glows, glass-style cards, refined tables and inputs.
- Adds a Neon Command preset in Admin > Branding. Existing saved company branding takes precedence; select the new preset and Save & Apply to adopt its accent colors.
- Existing SA icon and browser/Electron development modes are retained.
- Print styles retain a clean paper background.

This is a development ZIP, **not** a compiled EXE. No Windows runtime or complete UI regression testing was performed.

To upgrade safely: close FleetTrack, extract to a new folder, copy your existing database and original backend .env (if any), then run START_FleetTrack.bat. Never overwrite an existing populated SQLite database with a blank one.
