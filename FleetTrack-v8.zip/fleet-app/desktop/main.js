const {app, BrowserWindow, dialog, shell} = require('electron');
const {spawn} = require('child_process');
const path = require('path');
const fs = require('fs');
const http = require('http');
let child;
const packaged = app.isPackaged;
const root = path.resolve(__dirname, '..');
const unpacked = packaged ? root.replace('app.asar', 'app.asar.unpacked') : root;
const backend = path.join(unpacked, 'backend');
const configFile = path.join(app.getPath('userData'), 'desktop-settings.json');
function port(v, fallback) {const n=Number(v);return Number.isInteger(n)&&n>=1024&&n<=65535?n:fallback;}
function wait(url, timeout=45000) {return new Promise((resolve,reject)=>{const until=Date.now()+timeout;const check=()=>{http.get(url,r=>{r.resume();if(r.statusCode===200)resolve();else retry();}).on('error',retry);};function retry(){if(Date.now()>until)reject(new Error('Server did not start. See startup.log in FleetTrack app data.'));else setTimeout(check,350);}check();});}
app.whenReady().then(async()=>{
 try {
  const settings=fs.existsSync(configFile)?JSON.parse(fs.readFileSync(configFile,'utf8')):{};
  const portNum=port(settings.backendPort,3001);
  const dataDir=path.join(app.getPath('userData'),'data');fs.mkdirSync(dataDir,{recursive:true});
  const dbPath=path.join(dataDir,'fleet.db');
  const env={...process.env,ELECTRON_RUN_AS_NODE:'1',FLEET_BACKEND_PORT:String(portNum),FLEET_FRONTEND_PORT:String(portNum),DATABASE_URL:'file:'+dbPath.replace(/\\/g,'/'),JWT_SECRET:''};
  const secretFile=path.join(dataDir,'jwt-secret');
  if(!fs.existsSync(secretFile)){const crypto=require('crypto');fs.writeFileSync(secretFile,crypto.randomBytes(48).toString('hex'));}
  env.JWT_SECRET=fs.readFileSync(secretFile,'utf8').trim();
  const log=fs.openSync(path.join(app.getPath('userData'),'startup.log'),'a');
  child=spawn(process.execPath,[path.join(backend,'desktop-start.js')],{cwd:backend,env,stdio:['ignore',log,log],windowsHide:true});
  child.on('error',e=>dialog.showErrorBox('FleetTrack backend',e.message));
  await wait('http://127.0.0.1:'+portNum+'/api/health');
  const win=new BrowserWindow({width:1500,height:920,minWidth:1050,minHeight:680,backgroundColor:'#060b16',icon:path.join(unpacked,'SA_icon.ico'),webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
  win.webContents.setWindowOpenHandler(({url})=>{if(url.startsWith('https://'))shell.openExternal(url);return {action:'deny'};});
  await win.loadURL('http://127.0.0.1:'+portNum+'/');
 }catch(e){dialog.showErrorBox('FleetTrack startup error',String(e.message||e));app.quit();}
});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(child)try{child.kill();}catch(_){}});
