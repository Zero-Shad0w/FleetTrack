# FleetTrack desktop development preview

This is an incremental **development shell**, not a standalone EXE installer. It preserves the original browser mode and application source.

1. Install Node.js and run `npm install` in the project root, then `npm run setup`.
2. Set up Prisma/database using the existing project instructions.
3. Copy `fleet-desktop-settings.example.json` to `fleet-desktop-settings.json`.
4. Edit `backendPort` and `frontendPort` if desired, then run `npm run desktop:dev`.
5. Browser mode remains available using `npm start`.

The `SA_icon.ico` file is used for the Electron window. Windows NSIS installer creation, a packaged production backend, safe process shutdown, and a Settings UI are **not implemented yet**.

`databaseMode` is reserved for a future implementation. Only local SQLite is supported in this preview; do not point SQLite at a shared network file. A shared database requires a central server API and explicit migration/backup flow.

**Security:** The original application authentication and existing code have not been audited. The desktop development mode launches Vite and Express as local processes and should not be treated as a production installer.
