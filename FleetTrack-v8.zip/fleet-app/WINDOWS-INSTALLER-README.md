# FleetTrack Pro Windows installer build kit

This is a **build kit**, not a precompiled EXE. On Windows 10/11, install Node.js LTS, then double-click `BUILD-WINDOWS-EXE.bat`. The installer should appear in `installer-output/` after a successful build. Internet is required for initial dependencies.

The installed app opens an Electron window, **not the external browser**. The backend serves the production React build on localhost. Existing browser development mode remains available with `START_FleetTrack.bat`.

The desktop database is stored under the current Windows user's Electron app data (`FleetTrack Pro/data/fleet.db`), not the installation directory. Back it up before changing versions. Existing data is not automatically imported from earlier ZIP versions. Do not delete older installations or databases until migration is verified.

Backend port can be set in `%APPDATA%/fleettrack-pro/desktop-settings.json` with `{"backendPort":3001}` before launching. This build does not implement a tested shared database mode or an in-app settings panel.

**Not validated on Windows**: Native Windows packaging, Prisma engine resolution, first-run database initialization and login require an actual Windows test. If startup fails, check `startup.log` in the app data directory.
