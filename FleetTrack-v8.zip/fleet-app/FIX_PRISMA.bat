@echo off
title FleetTrack — Fix Prisma Cache
color 0E

echo.
echo  Clearing Prisma client cache and regenerating...
echo.

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "BACKEND=%ROOT%\backend"

cd /d %BACKEND%

echo  [1] Deleting cached Prisma client...
if exist "node_modules\.prisma" (
    rmdir /s /q "node_modules\.prisma"
    echo  [OK] Cache cleared.
) else (
    echo  [OK] No cache found.
)

echo  [2] Regenerating Prisma client...
call npx prisma generate
if errorlevel 1 (
    echo  [ERROR] Prisma generate failed!
    pause
    exit /b 1
)
echo  [OK] Prisma client regenerated.

echo.
echo  Done! Now start the app with START_FleetTrack.bat
echo.
pause
