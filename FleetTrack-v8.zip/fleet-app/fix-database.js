/**
 * Run this script to fix the database directly.
 * It adds any missing columns without needing Prisma migrations.
 * 
 * Usage: node fix-database.js
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, 'backend', 'prisma', 'fleet.db');

if (!fs.existsSync(DB_PATH)) {
  console.error('ERROR: Database not found at:', DB_PATH);
  console.log('Make sure you run this from the fleet-app folder.');
  process.exit(1);
}

console.log('Found database at:', DB_PATH);
const db = new Database(DB_PATH);

// Helper: check if column exists
function columnExists(table, column) {
  const cols = db.pragma(`table_info(${table})`);
  return cols.some(c => c.name === column);
}

// Helper: add column if missing
function addColumnIfMissing(table, column, type, defaultVal = 'NULL') {
  if (!columnExists(table, column)) {
    try {
      db.exec(`ALTER TABLE "${table}" ADD COLUMN "${column}" ${type}`);
      console.log(`  ✓ Added column: ${table}.${column}`);
    } catch (e) {
      console.log(`  ✗ Failed to add ${table}.${column}: ${e.message}`);
    }
  } else {
    console.log(`  - Already exists: ${table}.${column}`);
  }
}

console.log('\nChecking and fixing database columns...\n');

// ── Vehicle photo columns ─────────────────────────────────────────────────────
console.log('Vehicle table:');
addColumnIfMissing('Vehicle', 'photoFront', 'TEXT');
addColumnIfMissing('Vehicle', 'photoRear',  'TEXT');
addColumnIfMissing('Vehicle', 'photoLeft',  'TEXT');
addColumnIfMissing('Vehicle', 'photoRight', 'TEXT');
addColumnIfMissing('Vehicle', 'photoTop',   'TEXT');

// ── DamageInspection photos + left/right columns ─────────────────────────────
console.log('\nDamageInspection table:');
addColumnIfMissing('DamageInspection', 'photos', 'TEXT');
addColumnIfMissing('DamageInspection', 'leftDamageMarkers',  'TEXT');
addColumnIfMissing('DamageInspection', 'rightDamageMarkers', 'TEXT');

// ── User active / lastLogin ───────────────────────────────────────────────────
console.log('\nUser table:');
addColumnIfMissing('User', 'active',    'BOOLEAN NOT NULL DEFAULT 1');
addColumnIfMissing('User', 'lastLogin', 'DATETIME');

// Fix existing users that have active = NULL → set to 1
try {
  const result = db.prepare(`UPDATE "User" SET "active" = 1 WHERE "active" IS NULL`).run();
  if (result.changes > 0) console.log(`  ✓ Fixed ${result.changes} user(s) with NULL active status`);
} catch (e) {}

// ── ActivityLog table ─────────────────────────────────────────────────────────
console.log('\nActivityLog table:');
const tables = db.pragma('table_list').map(t => t.name);
if (!tables.includes('ActivityLog')) {
  try {
    db.exec(`
      CREATE TABLE "ActivityLog" (
        "id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        "userId"    INTEGER NOT NULL,
        "action"    TEXT NOT NULL,
        "details"   TEXT,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
      )
    `);
    console.log('  ✓ Created ActivityLog table');
  } catch (e) { console.log('  ✗', e.message); }
} else {
  console.log('  - ActivityLog table already exists');
}

// ── Backup table ──────────────────────────────────────────────────────────────
console.log('\nBackup table:');
if (!tables.includes('Backup')) {
  try {
    db.exec(`
      CREATE TABLE "Backup" (
        "id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        "filename"  TEXT NOT NULL,
        "size"      INTEGER,
        "createdBy" TEXT,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('  ✓ Created Backup table');
  } catch (e) { console.log('  ✗', e.message); }
} else {
  console.log('  - Backup table already exists');
}


// ── Employee tables ───────────────────────────────────────────────────────────
const empTables = db.pragma('table_list').map(t => t.name);

console.log('\nEmployee tables:');
if (!empTables.includes('Employee')) {
  db.exec(`CREATE TABLE "Employee" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" TEXT NOT NULL UNIQUE,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "gender" TEXT, "dateOfBirth" DATETIME, "personalNumber" TEXT,
    "phone" TEXT, "email" TEXT, "address" TEXT, "city" TEXT, "country" TEXT,
    "emergencyContact" TEXT, "emergencyPhone" TEXT, "role" TEXT,
    "department" TEXT, "manager" TEXT,
    "employmentStatus" TEXT NOT NULL DEFAULT 'active',
    "employmentType" TEXT NOT NULL DEFAULT 'full_time',
    "hireDate" DATETIME, "salary" REAL, "notes" TEXT, "profilePhoto" TEXT,
    "archived" BOOLEAN NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  console.log('  ✓ Created Employee table');
} else { console.log('  - Employee table already exists'); }

if (!empTables.includes('EmployeeWarning')) {
  db.exec(`CREATE TABLE "EmployeeWarning" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "title" TEXT NOT NULL,
    "warningType" TEXT, "severity" TEXT NOT NULL DEFAULT 'minor',
    "description" TEXT, "dateIssued" DATETIME NOT NULL, "issuedBy" TEXT,
    "reason" TEXT, "relatedIncident" TEXT, "actionTaken" TEXT,
    "employeeResponse" TEXT, "attachments" TEXT, "signature" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeWarning table');
} else { console.log('  - EmployeeWarning already exists'); }

if (!empTables.includes('EmployeeTool')) {
  db.exec(`CREATE TABLE "EmployeeTool" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "toolName" TEXT NOT NULL,
    "toolType" TEXT, "serialNumber" TEXT, "assetNumber" TEXT,
    "condition" TEXT, "assignedDate" DATETIME, "returnDate" DATETIME,
    "status" TEXT NOT NULL DEFAULT 'assigned',
    "notes" TEXT, "photos" TEXT, "documents" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeTool table');
} else { console.log('  - EmployeeTool already exists'); }

if (!empTables.includes('EmployeeComplaint')) {
  db.exec(`CREATE TABLE "EmployeeComplaint" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "title" TEXT NOT NULL,
    "category" TEXT, "priority" TEXT NOT NULL DEFAULT 'medium',
    "description" TEXT, "date" DATETIME NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'open',
    "adminReply" TEXT, "anonymous" BOOLEAN NOT NULL DEFAULT 0,
    "attachments" TEXT, "internalNotes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeComplaint table');
} else { console.log('  - EmployeeComplaint already exists'); }

if (!empTables.includes('EmployeeDocument')) {
  db.exec(`CREATE TABLE "EmployeeDocument" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "name" TEXT NOT NULL,
    "category" TEXT, "fileData" TEXT, "fileType" TEXT, "fileSize" INTEGER,
    "expiryDate" DATETIME, "version" INTEGER NOT NULL DEFAULT 1,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeDocument table');
} else { console.log('  - EmployeeDocument already exists'); }


// ── BrandingSettings table ────────────────────────────────────────────────────
const allTables2 = db.pragma('table_list').map(t => t.name);
console.log('\nBranding table:');
if (!allTables2.includes('BrandingSettings')) {
  db.exec(`CREATE TABLE "BrandingSettings" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "softwareName" TEXT NOT NULL DEFAULT 'FleetTrack Pro',
    "logoData" TEXT,
    "primaryColor" TEXT NOT NULL DEFAULT '#2563eb',
    "secondaryColor" TEXT NOT NULL DEFAULT '#1d4ed8',
    "accentColor" TEXT NOT NULL DEFAULT '#3b82f6',
    "sidebarColor" TEXT NOT NULL DEFAULT '#ffffff',
    "textColor" TEXT NOT NULL DEFAULT '#111827',
    "darkPrimary" TEXT NOT NULL DEFAULT '#3b82f6',
    "darkSidebar" TEXT NOT NULL DEFAULT '#111827',
    "updatedBy" TEXT,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  db.exec(`INSERT INTO "BrandingSettings" ("softwareName","primaryColor","secondaryColor","accentColor","sidebarColor","textColor","darkPrimary","darkSidebar","updatedAt") VALUES ('FleetTrack Pro','#2563eb','#1d4ed8','#3b82f6','#ffffff','#111827','#3b82f6','#111827',datetime('now'))`);
  console.log('  ✓ Created BrandingSettings table with defaults');
} else { console.log('  - BrandingSettings already exists'); }

// ── Attendance & Fines tables ─────────────────────────────────────────────────
console.log('\nAttendance & Fines tables:');
if (!allTables2.includes('EmployeeAttendance')) {
  db.exec(`CREATE TABLE "EmployeeAttendance" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "date" DATETIME NOT NULL,
    "checkIn" TEXT, "checkOut" TEXT, "status" TEXT NOT NULL DEFAULT 'present',
    "hoursWorked" REAL, "overtime" REAL, "notes" TEXT, "approvedBy" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeAttendance');
} else { console.log('  - EmployeeAttendance already exists'); }

if (!allTables2.includes('EmployeeFine')) {
  db.exec(`CREATE TABLE "EmployeeFine" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "employeeId" INTEGER NOT NULL, "title" TEXT NOT NULL, "reason" TEXT,
    "amount" REAL NOT NULL, "deductionType" TEXT NOT NULL DEFAULT 'once',
    "deductionDate" DATETIME, "status" TEXT NOT NULL DEFAULT 'pending',
    "issuedBy" TEXT, "approvedBy" TEXT, "notes" TEXT, "relatedWarning" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("employeeId") REFERENCES "Employee"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EmployeeFine');
} else { console.log('  - EmployeeFine already exists'); }


// ── Fix EmployeeAttendance missing columns ────────────────────────────────────
console.log('\nFixing EmployeeAttendance columns:');
addColumnIfMissing('EmployeeAttendance', 'overtime',   'REAL');
addColumnIfMissing('EmployeeAttendance', 'approvedBy', 'TEXT');
addColumnIfMissing('EmployeeAttendance', 'checkIn',    'TEXT');
addColumnIfMissing('EmployeeAttendance', 'checkOut',   'TEXT');
addColumnIfMissing('EmployeeAttendance', 'hoursWorked','REAL');
addColumnIfMissing('EmployeeAttendance', 'notes',      'TEXT');


// ── Final: ensure EmployeeAttendance has correct columns ─────────────────────
console.log('\nFinal attendance column check:');
const attCols = db.pragma('table_info(EmployeeAttendance)').map(c => c.name);
console.log('  Current columns:', attCols.join(', '));
['checkIn','checkOut','hoursWorked','overtime','notes','approvedBy'].forEach(col => {
  if (!attCols.includes(col)) {
    const type = ['hoursWorked','overtime'].includes(col) ? 'REAL' : 'TEXT';
    db.exec(`ALTER TABLE "EmployeeAttendance" ADD COLUMN "${col}" ${type}`);
    console.log('  ✓ Added:', col);
  } else {
    console.log('  - OK:', col);
  }
});
// updatedAt — add only if missing, with a default so existing rows are fine
if (!attCols.includes('updatedAt')) {
  db.exec(`ALTER TABLE "EmployeeAttendance" ADD COLUMN "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  console.log('  ✓ Added: updatedAt');
} else {
  console.log('  - OK: updatedAt');
}


// ── EquipmentTemplate table ───────────────────────────────────────────────────
const allTables3 = db.pragma('table_list').map(t => t.name);
console.log('\nEquipmentTemplate table:');
if (!allTables3.includes('EquipmentTemplate')) {
  db.exec(`CREATE TABLE "EquipmentTemplate" (
    "id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "vehicleId" INTEGER NOT NULL,
    "itemName"  TEXT NOT NULL,
    "category"  TEXT,
    "required"  BOOLEAN NOT NULL DEFAULT 1,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("vehicleId") REFERENCES "Vehicle"("id") ON DELETE CASCADE
  )`);
  console.log('  ✓ Created EquipmentTemplate table');
} else { console.log('  - EquipmentTemplate already exists'); }

db.close();

console.log('\n✅ Database fix complete!');
console.log('Restart the app and try adding a vehicle again.\n');
