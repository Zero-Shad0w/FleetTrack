# FleetTrack Pro — Vehicle Inspection Management System

A full-stack fleet vehicle management web application with inspection tracking, damage reporting, repair management, and equipment checklists.

---

## Features

- **Dashboard** — Overview of fleet status, expiry alerts, recent inspections
- **Vehicle Management** — Full CRUD with search, validation, and expiry tracking
- **Repairs & Parts** — Log repairs with auto-calculated costs, filters, and print reports
- **Damage Inspection** — Interactive SVG vehicle diagrams with clickable damage markers (dent, scratch, crack, chip)
- **Equipment Checklist** — Weekly equipment inventory with conditional formatting
- **Weekly Inspection Logs** — Recurring log entries with pagination and filters
- **Vehicle History** — Full timeline view per vehicle across all record types
- **Authentication** — JWT-based login with Admin / Inspector / Viewer roles
- **Dark Mode** — Full dark mode toggle
- **Print Support** — Print-friendly pages for all reports

---

## Tech Stack

| Layer      | Technology             |
|------------|------------------------|
| Frontend   | React 18 + Vite        |
| Styling    | Tailwind CSS           |
| Icons      | Lucide React           |
| Backend    | Node.js + Express      |
| Database   | SQLite (via Prisma ORM)|
| Auth       | JWT + bcrypt           |

---

## Prerequisites

- **Node.js** v18 or higher
- **npm** v8 or higher

---

## Installation & Setup

### Step 1 — Clone / Extract the project

```bash
cd fleet-app
```

### Step 2 — Install all dependencies

```bash
# Install root tools
npm install

# Install backend and frontend dependencies
npm run setup
```

### Step 3 — Set up the database

```bash
npm run db:setup
```

This will:
- Generate Prisma client
- Create the SQLite database
- Run all migrations
- Seed sample data (3 vehicles, repairs, logs)

### Step 4 — Start the application

```bash
# Option A: Start both together (recommended)
npm start

# Option B: Start separately
npm run dev:backend   # Terminal 1 → http://localhost:3001
npm run dev:frontend  # Terminal 2 → http://localhost:5173
```

Open **http://localhost:5173** in your browser.

---

## Login Credentials

| Role      | Username     | Password       |
|-----------|--------------|----------------|
| Admin     | `admin`      | `admin123`     |
| Inspector | `inspector1` | `inspector123` |
| Viewer    | `viewer1`    | `viewer123`    |

### Role Permissions

| Feature           | Admin | Inspector | Viewer |
|-------------------|-------|-----------|--------|
| View all data     | ✅    | ✅        | ✅     |
| Add/Edit records  | ✅    | ✅        | ❌     |
| Delete records    | ✅    | ❌        | ❌     |

---

## Project Structure

```
fleet-app/
├── backend/
│   ├── prisma/
│   │   └── schema.prisma          # Database schema
│   ├── src/
│   │   ├── index.js               # Express server entry point
│   │   ├── seed.js                # Sample data seeder
│   │   ├── middleware/
│   │   │   └── auth.js            # JWT authentication middleware
│   │   └── routes/
│   │       ├── auth.js            # Login / register / me
│   │       ├── vehicles.js        # Vehicle CRUD
│   │       ├── repairs.js         # Repair CRUD
│   │       ├── damage.js          # Damage inspection CRUD
│   │       ├── equipment.js       # Equipment check CRUD
│   │       ├── weeklyLogs.js      # Weekly log CRUD with pagination
│   │       └── dashboard.js       # Stats & alerts
│   ├── .env                       # Environment variables
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── App.jsx                # Router + providers
    │   ├── main.jsx               # Entry point
    │   ├── index.css              # Tailwind + global styles
    │   ├── context/
    │   │   ├── AuthContext.jsx    # Auth state
    │   │   ├── ToastContext.jsx   # Toast notifications
    │   │   └── DarkModeContext.jsx
    │   ├── components/
    │   │   ├── layout/
    │   │   │   └── Layout.jsx     # Sidebar + header
    │   │   └── ui/
    │   │       └── index.jsx      # Modal, StatCard, etc.
    │   ├── pages/
    │   │   ├── LoginPage.jsx
    │   │   ├── Dashboard.jsx
    │   │   ├── VehiclesPage.jsx
    │   │   ├── RepairsPage.jsx
    │   │   ├── DamagePage.jsx     # SVG damage markers
    │   │   ├── EquipmentPage.jsx
    │   │   ├── WeeklyLogsPage.jsx
    │   │   └── HistoryPage.jsx
    │   └── utils/
    │       └── api.js             # Axios instance
    └── package.json
```

---

## Database Tables

| Table              | Description                              |
|--------------------|------------------------------------------|
| `User`             | Login accounts with roles                |
| `Vehicle`          | Fleet vehicle registry                   |
| `Repair`           | Repair and parts records                 |
| `DamageInspection` | Damage reports with SVG marker positions |
| `EquipmentCheck`   | Weekly equipment inventory items         |
| `WeeklyLog`        | Driver inspection log entries            |

---

## Environment Variables

The backend `.env` file contains:

```env
DATABASE_URL="file:./fleet.db"
JWT_SECRET="fleet-inspection-super-secret-key-2024"
PORT=3001
NODE_ENV=development
```

**For production**, change `JWT_SECRET` to a long random string.

---

## Common Commands

```bash
# Reset database completely
cd backend
rm -f prisma/fleet.db
npx prisma migrate dev --name init
node src/seed.js

# View database in browser UI
cd backend && npx prisma studio

# Build frontend for production
cd frontend && npm run build
```

---

## Printing Reports

All pages have a **Print** button. The print stylesheet hides navigation, filters, and action buttons, producing clean reports. Use your browser's print dialog (Ctrl+P) to print or save as PDF.

---

## Troubleshooting

**Port already in use:**
```bash
# Kill processes on ports 3001 and 5173
npx kill-port 3001 5173
```

**Database errors:**
```bash
cd backend && npx prisma generate
```

**"Cannot find module @prisma/client":**
```bash
cd backend && npm install && npx prisma generate
```
