@echo off
setlocal
cd /d "%~dp0"
title FleetTrack Pro - Launcher
set "ROOT=%~dp0"
echo ==========================================
echo FleetTrack Pro - Safe startup
 echo ==========================================
where node >nul 2>&1
if errorlevel 1 goto no_node
if not exist "%ROOT%backend\node_modules\prisma" (
 echo Installing backend dependencies...
 pushd "%ROOT%backend"
 call npm install
 if errorlevel 1 goto fail_pop
 popd
)
if not exist "%ROOT%frontend\node_modules\vite" (
 echo Installing frontend dependencies...
 pushd "%ROOT%frontend"
 call npm install
 if errorlevel 1 goto fail_pop
 popd
)
pushd "%ROOT%backend"
node bootstrap.js
if errorlevel 1 goto fail_pop
popd
set "FLEET_BACKEND_PORT=3001"
set "FLEET_FRONTEND_PORT=5173"
if exist "%ROOT%fleet-desktop-settings.json" (
 for /f "usebackq tokens=1,2 delims=," %%A in (`node -e "const c=require('./fleet-desktop-settings.json');console.log((c.backendPort||3001)+','+(c.frontendPort||5173))"`) do (
  set "FLEET_BACKEND_PORT=%%A"
  set "FLEET_FRONTEND_PORT=%%B"
 )
)
echo Starting backend and frontend. Do not close their windows while using FleetTrack.
start "FleetTrack-Backend" /D "%ROOT%backend" cmd /k "node src\index.js"
start "FleetTrack-Frontend" /D "%ROOT%frontend" cmd /k "npm run dev"
echo.
echo Open http://localhost:%FLEET_FRONTEND_PORT% in your browser.
echo If a port is occupied, stop the other program first. No processes were force-killed.
pause
exit /b 0
:no_node
echo ERROR: Node.js is not installed. Install Node.js LTS from https://nodejs.org
pause
exit /b 1
:fail_pop
popd
:fail
echo ERROR: Setup failed. Review the message above. Your database has not been reset.
pause
exit /b 1
