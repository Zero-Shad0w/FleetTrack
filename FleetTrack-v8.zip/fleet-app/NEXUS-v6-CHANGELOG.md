# FleetTrack NEXUS v6 visual redesign

A visible frontend styling upgrade with angular high-contrast command center panels, red/cyan-tinted navy palette, grid texture, glow focus, active navigation rails, table treatments and updated sidebar subtitle. No backend/database or permissions changes.

## Verify
1. Stop ALL older FleetTrack Vite/Node windows.
2. Extract into a NEW folder and start this version.
3. Select Dark Mode (existing light-mode preferences are respected).
4. Open the port printed by this version and hard refresh Ctrl+Shift+R.
5. Sidebar must display NEXUS // COMMAND CENTER — if it does not, you are running an older frontend.

Windows installer and end-to-end runtime tests are not included.
