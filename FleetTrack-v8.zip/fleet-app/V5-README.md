V5 theme visibility fix. Stop the old server first; start this copy and hard-refresh Ctrl+Shift+R. If Light Mode was previously selected, toggle Dark Mode. Existing data and backend unchanged.
