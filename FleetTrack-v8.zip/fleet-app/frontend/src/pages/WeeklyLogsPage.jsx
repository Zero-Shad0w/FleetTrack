import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, FileText, Search, ChevronLeft, ChevronRight, Printer } from 'lucide-react';
import api from '../utils/api';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, PageHeader, SearchInput } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { format } from 'date-fns';

const EMPTY = {
  vehicleId: '', inspectionDate: format(new Date(), 'yyyy-MM-dd'),
  employeeName: '', mileage: '', fuelLevel: '100%',
  damageFound: false, equipmentComplete: true, comments: '', signature: ''
};
const FUEL_LEVELS = ['100%', '75%', '50%', '25%', 'Empty'];

export default function WeeklyLogsPage() {
  const [data, setData] = useState({ logs: [], total: 0, page: 1, totalPages: 1 });
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [filterVehicle, setFilterVehicle] = useState('');
  const [filterEmployee, setFilterEmployee] = useState('');
  const [filterStart, setFilterStart] = useState('');
  const [filterEnd, setFilterEnd] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [deleteId, setDeleteId] = useState(null);
  const { canEdit, isAdmin } = useAuth();
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const params = { page, limit: 15 };
      if (filterVehicle) params.vehicleId = filterVehicle;
      if (filterEmployee) params.employeeName = filterEmployee;
      if (filterStart) params.startDate = filterStart;
      if (filterEnd) params.endDate = filterEnd;
      const [logs, v] = await Promise.all([api.get('/weekly-logs', { params }), api.get('/vehicles')]);
      setData(logs.data);
      setVehicles(v.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [page, filterVehicle, filterEmployee, filterStart, filterEnd]);

  const openNew = () => { setForm({ ...EMPTY, vehicleId: filterVehicle || '' }); setEditing(null); setModalOpen(true); };
  const openEdit = (log) => {
    setEditing(log);
    setForm({ ...log, inspectionDate: format(new Date(log.inspectionDate), 'yyyy-MM-dd'), vehicleId: log.vehicleId });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.vehicleId || !form.employeeName) return toast.error('Vehicle and employee name are required');
    try {
      if (editing) { await api.put(`/weekly-logs/${editing.id}`, form); toast.success('Log updated'); }
      else { await api.post('/weekly-logs', form); toast.success('Log saved'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/weekly-logs/${deleteId}`); toast.success('Log deleted'); load(); }
    catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Weekly Inspection Logs"
        subtitle={`${data.total} total records`}
        actions={<>
          <button onClick={() => window.print()} className="btn-secondary no-print"><Printer className="w-4 h-4" /> Print</button>
          {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Log</button>}
        </>}
      />

      {/* Filters */}
      <div className="card p-4 mb-4 flex flex-wrap gap-3 no-print">
        <select className="form-select w-52" value={filterVehicle} onChange={e => { setFilterVehicle(e.target.value); setPage(1); }}>
          <option value="">All Vehicles</option>
          {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
        </select>
        <input className="form-input w-44" placeholder="Filter by employee..." value={filterEmployee}
          onChange={e => { setFilterEmployee(e.target.value); setPage(1); }} />
        <input type="date" className="form-input w-40" value={filterStart}
          onChange={e => { setFilterStart(e.target.value); setPage(1); }} />
        <input type="date" className="form-input w-40" value={filterEnd}
          onChange={e => { setFilterEnd(e.target.value); setPage(1); }} />
        <button onClick={() => { setFilterVehicle(''); setFilterEmployee(''); setFilterStart(''); setFilterEnd(''); setPage(1); }}
          className="btn-secondary text-xs">Clear</button>
      </div>

      {loading ? <LoadingSpinner /> : data.logs.length === 0 ? (
        <EmptyState icon={FileText} title="No logs found" message="Add your first weekly inspection log."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Log</button>} />
      ) : (
        <>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                    {['Date','Vehicle','Employee','Mileage','Fuel','Damage','Equipment','Comments','Signature',''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                  {data.logs.map((log, i) => (
                    <tr key={log.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''}`}>
                      <td className="px-4 py-3 whitespace-nowrap text-gray-600 dark:text-gray-400">{format(new Date(log.inspectionDate), 'dd MMM yyyy')}</td>
                      <td className="px-4 py-3 font-mono text-xs font-medium text-brand-700 dark:text-brand-400 whitespace-nowrap">{log.vehicle?.vehicleId}</td>
                      <td className="px-4 py-3 text-gray-700 dark:text-gray-300">{log.employeeName}</td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{log.mileage ? `${log.mileage.toLocaleString()} km` : '—'}</td>
                      <td className="px-4 py-3">
                        <FuelBar level={log.fuelLevel} />
                      </td>
                      <td className="px-4 py-3">
                        <span className={log.damageFound ? 'badge-red' : 'badge-green'}>
                          {log.damageFound ? 'Yes' : 'None'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={log.equipmentComplete ? 'badge-green' : 'badge-red'}>
                          {log.equipmentComplete ? 'Complete' : 'Incomplete'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400 max-w-xs truncate">{log.comments || '—'}</td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 italic text-xs">{log.signature || '—'}</td>
                      <td className="px-4 py-3 no-print">
                        <div className="flex items-center gap-1">
                          {canEdit && <button onClick={() => openEdit(log)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>}
                          {isAdmin && <button onClick={() => setDeleteId(log.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          {data.totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Showing {((page - 1) * 15) + 1}–{Math.min(page * 15, data.total)} of {data.total} records
              </p>
              <div className="flex items-center gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                {Array.from({ length: Math.min(5, data.totalPages) }, (_, i) => {
                  const pg = page <= 3 ? i + 1 : page - 2 + i;
                  if (pg > data.totalPages) return null;
                  return (
                    <button key={pg} onClick={() => setPage(pg)}
                      className={`w-8 h-8 text-sm rounded-lg font-medium transition-colors ${pg === page ? 'bg-brand-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400'}`}>
                      {pg}
                    </button>
                  );
                })}
                <button onClick={() => setPage(p => Math.min(data.totalPages, p + 1))} disabled={page === data.totalPages} className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Log Entry' : 'New Log Entry'} size="md">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Vehicle *</label>
              <select className="form-select" value={form.vehicleId} onChange={e => setForm(p => ({ ...p, vehicleId: e.target.value }))} required>
                <option value="">Select...</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Date</label>
              <input className="form-input" type="date" {...f('inspectionDate')} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Employee Name *</label>
              <input className="form-input" placeholder="Full name" {...f('employeeName')} />
            </div>
            <div>
              <label className="form-label">Mileage (km)</label>
              <input className="form-input" type="number" placeholder="45000" {...f('mileage')} />
            </div>
          </div>
          <div>
            <label className="form-label">Fuel Level</label>
            <select className="form-select" {...f('fuelLevel')}>
              {FUEL_LEVELS.map(l => <option key={l}>{l}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <label className="flex items-center gap-3 p-3 border border-gray-200 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
              <input type="checkbox" className="w-4 h-4 rounded" checked={form.damageFound} onChange={e => setForm(p => ({ ...p, damageFound: e.target.checked }))} />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Damage Found</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-200 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
              <input type="checkbox" className="w-4 h-4 rounded" checked={form.equipmentComplete} onChange={e => setForm(p => ({ ...p, equipmentComplete: e.target.checked }))} />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Equipment Complete</span>
            </label>
          </div>
          <div>
            <label className="form-label">Comments</label>
            <textarea className="form-input h-20 resize-none" placeholder="Any comments or observations..." {...f('comments')} />
          </div>
          <div>
            <label className="form-label">Signature</label>
            <input className="form-input" placeholder="Type full name as signature" {...f('signature')} />
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Add Log'}</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Log" message="Are you sure you want to delete this log entry?" danger />
    </div>
  );
}

function FuelBar({ level }) {
  const pct = { '100%': 100, '75%': 75, '50%': 50, '25%': 25, 'Empty': 0 }[level] ?? 50;
  const color = pct > 50 ? 'bg-green-500' : pct > 25 ? 'bg-yellow-500' : 'bg-red-500';
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs text-gray-500">{level || '—'}</span>
    </div>
  );
}
