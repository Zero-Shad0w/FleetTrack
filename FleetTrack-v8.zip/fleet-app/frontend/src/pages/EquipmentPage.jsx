import React, { useState, useEffect, useRef } from 'react';
import {
  Plus, ClipboardCheck, Trash2, Save, CheckCircle, XCircle,
  Printer, Settings, ChevronDown, ChevronUp, GripVertical,
  FileText, Truck, Edit2, X, AlertCircle
} from 'lucide-react';
import api from '../utils/api';
import { LoadingSpinner, PageHeader, Modal, ConfirmDialog } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { format, getWeek } from 'date-fns';

const DEFAULT_ITEMS = [
  'Jelek Sigurie',
  'Kapele Sigurie',
  'Trekendeshi',
  'Vinci',
  'Goma Rezerve',
  'Dana Rg6/RG7.5',
  'Dana',
  'Skallper',
  'Shtrafsigera',
  'Sinkor',
];
const CONDITIONS = ['Good','Fair','Poor','N/A'];

// ── Template Manager Modal ────────────────────────────────────────────────────
function TemplateModal({ open, onClose, vehicleId, vehicleName, onSaved }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newItem, setNewItem] = useState('');
  const [saving, setSaving] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (!open || !vehicleId) return;
    setLoading(true);
    api.get(`/equipment/template/${vehicleId}`)
      .then(r => setItems(r.data.length > 0 ? r.data : DEFAULT_ITEMS.map((n,i) => ({ itemName:n, category:'', required:true, sortOrder:i }))))
      .finally(() => setLoading(false));
  }, [open, vehicleId]);

  const addItem = () => {
    if (!newItem.trim()) return;
    setItems(prev => [...prev, { itemName: newItem.trim(), category:'', required:true, sortOrder: prev.length }]);
    setNewItem('');
  };

  const removeItem = (idx) => setItems(prev => prev.filter((_,i) => i !== idx));
  const toggleRequired = (idx) => setItems(prev => prev.map((item,i) => i===idx ? {...item, required:!item.required} : item));

  const loadDefaults = () => {
    setItems(DEFAULT_ITEMS.map((n,i) => ({ itemName:n, category:'', required:true, sortOrder:i })));
    toast.info('Default items loaded — click Save to apply');
  };

  const handleSave = async () => {
    if (items.length === 0) return toast.error('Add at least one item');
    setSaving(true);
    try {
      await api.post(`/equipment/template/${vehicleId}`, { items });
      toast.success(`Template saved for ${vehicleName}`);
      onSaved();
      onClose();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title={`Equipment Template — ${vehicleName}`} size="md">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Define the standard equipment list for this vehicle. This list will be pre-loaded every time you run a check.
          </p>
          <button onClick={loadDefaults} className="btn-secondary text-xs flex-shrink-0 ml-3">
            Load Defaults
          </button>
        </div>

        {loading ? <LoadingSpinner /> : (
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2.5 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <GripVertical className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <span className="flex-1 text-sm text-gray-900 dark:text-gray-100">{item.itemName}</span>
                <button onClick={() => toggleRequired(idx)} title={item.required ? 'Required' : 'Optional'}
                  className={`text-xs px-2 py-0.5 rounded font-medium flex-shrink-0 transition-colors ${item.required ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-gray-200 text-gray-500 dark:bg-gray-600 dark:text-gray-400'}`}>
                  {item.required ? 'Required' : 'Optional'}
                </button>
                <button onClick={() => removeItem(idx)} className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-2">
          <input className="form-input flex-1 text-sm" placeholder="Add equipment item..."
            value={newItem} onChange={e => setNewItem(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addItem()} />
          <button onClick={addItem} className="btn-secondary"><Plus className="w-4 h-4" /></button>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 text-xs text-blue-700 dark:text-blue-300">
          <strong>{items.length} items</strong> in template · Required items are highlighted in red during checks
        </div>
      </div>

      <div className="flex gap-3 justify-end mt-5 pt-4 border-t border-gray-100 dark:border-gray-700">
        <button onClick={onClose} className="btn-secondary">Cancel</button>
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save Template'}
        </button>
      </div>
    </Modal>
  );
}

// ── Printable Inspection Form ─────────────────────────────────────────────────
function printInspectionForm(vehicle, items, checkData) {
  const now = new Date();
  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<title>Vehicle Inspection Form — ${vehicle?.vehicleId || ''}</title>
<style>
  * { box-sizing: border-box; margin:0; padding:0; }
  body { font-family: Arial, sans-serif; font-size: 11px; color: #111; background: white; padding: 20px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1d4ed8; padding-bottom: 14px; margin-bottom: 18px; }
  .header h1 { font-size: 20px; font-weight: 800; color: #1d4ed8; }
  .header .sub { font-size: 11px; color: #64748b; margin-top: 2px; }
  .info-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 8px; margin-bottom: 16px; }
  .info-box { border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; }
  .info-label { font-size: 9px; text-transform: uppercase; color: #64748b; margin-bottom: 3px; letter-spacing: 0.5px; }
  .info-value { font-size: 12px; font-weight: 600; color: #0f172a; min-height: 16px; }
  .section-title { font-size: 12px; font-weight: 700; color: #1d4ed8; border-bottom: 1px solid #dbeafe; padding-bottom: 5px; margin: 16px 0 10px; text-transform: uppercase; letter-spacing: 0.5px; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #f1f5f9; padding: 7px 8px; text-align: left; font-size: 10px; font-weight: 700; color: #475569; border: 1px solid #e2e8f0; }
  td { padding: 7px 8px; border: 1px solid #e2e8f0; vertical-align: middle; }
  tr:nth-child(even) td { background: #fafafa; }
  .check-box { width: 16px; height: 16px; border: 2px solid #94a3b8; border-radius: 3px; display: inline-block; }
  .check-box.checked { background: #22c55e; border-color: #22c55e; position: relative; }
  .check-box.checked::after { content: '✓'; position: absolute; top: -2px; left: 2px; color: white; font-size: 12px; font-weight: bold; }
  .check-box.missing { background: #ef4444; border-color: #ef4444; }
  .check-box.missing::after { content: '✗'; position: absolute; top: -2px; left: 2px; color: white; font-size: 12px; font-weight: bold; }
  .status-present { color: #16a34a; font-weight: 600; }
  .status-missing  { color: #dc2626; font-weight: 600; }
  .required-badge { background: #fee2e2; color: #991b1b; font-size: 8px; padding: 1px 4px; border-radius: 3px; font-weight: 600; }
  .signature-section { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 24px; }
  .sig-box { border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; }
  .sig-line { border-bottom: 1px solid #cbd5e1; height: 48px; margin: 8px 0 4px; }
  .sig-label { font-size: 9px; color: #64748b; }
  .sig-name { font-size: 9px; color: #64748b; margin-top: 4px; }
  .footer { margin-top: 20px; padding-top: 10px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 9px; color: #94a3b8; }
  .summary-bar { display: flex; gap: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; margin-bottom: 12px; }
  .summary-item { text-align: center; }
  .summary-val { font-size: 18px; font-weight: 700; }
  .summary-lbl { font-size: 9px; color: #64748b; text-transform: uppercase; }
  .present-val { color: #16a34a; }
  .missing-val  { color: #dc2626; }
  @media print { body { padding: 10px; } }
</style>
</head>
<body>

<div class="header">
  <div>
    <h1>Vehicle Inspection Form</h1>
    <div class="sub">Equipment & Condition Check — Field Copy</div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:11px;color:#64748b;">Date: ${format(now,'dd MMMM yyyy')}</div>
    <div style="font-size:11px;color:#64748b;">Time: ${format(now,'HH:mm')}</div>
    <div style="font-size:11px;color:#64748b;">Form #: INS-${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}</div>
  </div>
</div>

<!-- Vehicle Info -->
<div class="info-grid">
  <div class="info-box"><div class="info-label">Vehicle ID</div><div class="info-value">${vehicle?.vehicleId || ''}</div></div>
  <div class="info-box"><div class="info-label">Make / Model</div><div class="info-value">${vehicle?.make || ''} ${vehicle?.model || ''}</div></div>
  <div class="info-box"><div class="info-label">License Plate</div><div class="info-value">${vehicle?.licensePlate || ''}</div></div>
  <div class="info-box"><div class="info-label">Year</div><div class="info-value">${vehicle?.year || ''}</div></div>
  <div class="info-box"><div class="info-label">Assigned Employee</div><div class="info-value">${vehicle?.assignedEmployee || ''}</div></div>
  <div class="info-box"><div class="info-label">Department</div><div class="info-value">${vehicle?.department || ''}</div></div>
  <div class="info-box"><div class="info-label">Current Mileage</div><div class="info-value">${checkData?.mileage || '____________'} km</div></div>
  <div class="info-box"><div class="info-label">Fuel Level</div><div class="info-value">${checkData?.fuelLevel || '____________'}</div></div>
  <div class="info-box"><div class="info-label">Inspector Name</div><div class="info-value">${checkData?.inspectorName || '____________'}</div></div>
</div>

<!-- Summary -->
${items.length > 0 ? `
<div class="summary-bar">
  <div class="summary-item"><div class="summary-val present-val">${items.filter(i=>i.present!==false).length}</div><div class="summary-lbl">Present</div></div>
  <div class="summary-item"><div class="summary-val missing-val">${items.filter(i=>i.present===false).length}</div><div class="summary-lbl">Missing</div></div>
  <div class="summary-item"><div class="summary-val">${items.length}</div><div class="summary-lbl">Total Items</div></div>
</div>` : ''}

<!-- Equipment Checklist -->
<div class="section-title">Equipment Checklist</div>
<table>
  <thead>
    <tr>
      <th style="width:30px;">#</th>
      <th>Equipment Item</th>
      <th style="width:60px;text-align:center;">Present</th>
      <th style="width:60px;text-align:center;">Missing</th>
      <th style="width:100px;">Condition</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    ${items.map((item, idx) => `
    <tr>
      <td style="text-align:center;color:#94a3b8;">${idx+1}</td>
      <td>
        ${item.itemName || item.equipmentItem}
        ${item.required ? '<span class="required-badge">REQ</span>' : ''}
      </td>
      <td style="text-align:center;">
        <div class="check-box ${item.present===true?'checked':''}" style="margin:auto;"></div>
      </td>
      <td style="text-align:center;">
        <div class="check-box ${item.present===false?'missing':''}" style="margin:auto;"></div>
      </td>
      <td>${item.condition || '____________'}</td>
      <td style="min-width:120px;">${item.notes || ''}</td>
    </tr>`).join('')}
    ${items.length === 0 ? Array.from({length:13},(_,i)=>`
    <tr>
      <td style="text-align:center;color:#94a3b8;">${i+1}</td>
      <td>&nbsp;</td>
      <td style="text-align:center;"><div class="check-box" style="margin:auto;"></div></td>
      <td style="text-align:center;"><div class="check-box" style="margin:auto;"></div></td>
      <td></td><td></td>
    </tr>`).join('') : ''}
  </tbody>
</table>

<!-- Damage Section -->
<div class="section-title">Damage / Defects Observed</div>
<table>
  <thead><tr><th>Location</th><th>Description</th><th>Severity</th><th>Reported To</th></tr></thead>
  <tbody>
    ${[1,2,3].map(()=>`<tr><td style="height:22px;"></td><td></td><td></td><td></td></tr>`).join('')}
  </tbody>
</table>

<!-- General Notes -->
<div class="section-title">General Notes / Comments</div>
<div style="border:1px solid #e2e8f0;border-radius:6px;min-height:60px;padding:8px;"></div>

<!-- Signatures -->
<div class="signature-section">
  <div class="sig-box">
    <div style="font-size:11px;font-weight:700;color:#0f172a;margin-bottom:6px;">Inspector Signature</div>
    <div class="sig-line"></div>
    <div class="sig-label">Full Name: ___________________________</div>
    <div class="sig-name">Date: _____________ Time: _____________</div>
  </div>
  <div class="sig-box">
    <div style="font-size:11px;font-weight:700;color:#0f172a;margin-bottom:6px;">Driver / Operator Signature</div>
    <div class="sig-line"></div>
    <div class="sig-label">Full Name: ___________________________</div>
    <div class="sig-name">Date: _____________ Time: _____________</div>
  </div>
</div>

<div class="footer">
  <div>Vehicle Inspection Form · ${vehicle?.vehicleId || ''} · ${format(now,'dd MMM yyyy')}</div>
  <div>This form must be signed by both parties and kept on file.</div>
</div>

</body>
</html>`;

  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  setTimeout(() => win.print(), 600);
}

// ── Main EquipmentPage ────────────────────────────────────────────────────────
export default function EquipmentPage() {
  const [vehicles, setVehicles]       = useState([]);
  const [history, setHistory]         = useState([]);
  const [loading, setLoading]         = useState(true);
  const [filterVehicle, setFilterVehicle] = useState('');

  // New check state
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [vehicleDetail, setVehicleDetail]     = useState(null);
  const [inspectorName, setInspectorName]     = useState('');
  const [inspDate, setInspDate]               = useState(format(new Date(),'yyyy-MM-dd'));
  const [weekNum, setWeekNum]                 = useState(getWeek(new Date()));
  const [mileage, setMileage]                 = useState('');
  const [fuelLevel, setFuelLevel]             = useState('');
  const [items, setItems]                     = useState([]);
  const [customItem, setCustomItem]           = useState('');
  const [templateOpen, setTemplateOpen]       = useState(false);
  const [templateVehicle, setTemplateVehicle] = useState(null);
  const [historyExpanded, setHistoryExpanded] = useState({});

  const { canEdit, canEditVehicles } = useAuth();
  const toast = useToast();

  useEffect(() => {
    Promise.all([api.get('/vehicles'), api.get('/equipment', { params: filterVehicle ? { vehicleId: filterVehicle } : {} })])
      .then(([v, e]) => { setVehicles(v.data); setHistory(e.data); })
      .finally(() => setLoading(false));
  }, [filterVehicle]);

  // Load vehicle detail + template when vehicle selected
  useEffect(() => {
    if (!selectedVehicle) { setItems([]); setVehicleDetail(null); return; }
    const v = vehicles.find(v => v.id === parseInt(selectedVehicle));
    setVehicleDetail(v || null);
    // Load template for this vehicle
    api.get(`/equipment/template/${selectedVehicle}`)
      .then(r => {
        if (r.data.length > 0) {
          setItems(r.data.map(t => ({ equipmentItem: t.itemName, present: true, condition: 'Good', notes: '', required: t.required })));
          toast.info(`Loaded ${r.data.length} items from saved template`);
        } else {
          setItems(DEFAULT_ITEMS.map(name => ({ equipmentItem: name, present: true, condition: 'Good', notes: '', required: true })));
        }
      })
      .catch(() => {
        setItems(DEFAULT_ITEMS.map(name => ({ equipmentItem: name, present: true, condition: 'Good', notes: '', required: true })));
      });
  }, [selectedVehicle]);

  const addCustomItem = () => {
    if (!customItem.trim()) return;
    setItems(prev => [...prev, { equipmentItem: customItem.trim(), present: true, condition: 'Good', notes: '', required: false }]);
    setCustomItem('');
  };

  const updateItem = (idx, field, value) => {
    setItems(prev => prev.map((item, i) => i === idx ? { ...item, [field]: value } : item));
  };

  const removeItem = (idx) => setItems(prev => prev.filter((_,i) => i !== idx));

  const handleSave = async () => {
    if (!selectedVehicle || !inspectorName) return toast.error('Select a vehicle and enter inspector name');
    try {
      await api.post('/equipment/batch', {
        vehicleId: selectedVehicle, inspectionDate: inspDate,
        inspectorName, weekNumber: weekNum, items
      });
      toast.success('Equipment check saved!');
      // Refresh history
      const e = await api.get('/equipment', { params: filterVehicle ? { vehicleId: filterVehicle } : {} });
      setHistory(e.data);
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handlePrint = () => {
    printInspectionForm(vehicleDetail, items, { mileage, fuelLevel, inspectorName });
  };

  const handlePrintBlank = (vehicle) => {
    api.get(`/equipment/template/${vehicle.id}`)
      .then(r => {
        const tmplItems = r.data.length > 0
          ? r.data.map(t => ({ equipmentItem: t.itemName, required: t.required }))
          : DEFAULT_ITEMS.map(n => ({ equipmentItem: n, required: true }));
        printInspectionForm(vehicle, tmplItems, {});
      })
      .catch(() => printInspectionForm(vehicle, [], {}));
  };

  const presentCount = items.filter(i => i.present).length;
  const missingCount = items.filter(i => !i.present).length;

  // Group history
  const grouped = history.reduce((acc, item) => {
    const key = `${item.vehicleId}-${item.inspectionDate?.split('T')[0]}`;
    if (!acc[key]) acc[key] = { vehicle: item.vehicle, date: item.inspectionDate, items: [] };
    acc[key].items.push(item);
    return acc;
  }, {});

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <PageHeader title="Equipment Checklist" subtitle="Vehicle equipment inventory & inspections" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ── New Check ─────────────────────────────────────────────────── */}
        {canEdit && (
          <div className="card p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900 dark:text-white">New Equipment Check</h3>
              {selectedVehicle && (
                <div className="flex gap-2">
                  <button onClick={handlePrint} className="btn-secondary text-xs py-1.5">
                    <Printer className="w-3.5 h-3.5" /> Print Form
                  </button>
                  {canEditVehicles && (
                    <button onClick={() => { setTemplateVehicle(vehicleDetail); setTemplateOpen(true); }} className="btn-secondary text-xs py-1.5">
                      <Settings className="w-3.5 h-3.5" /> Template
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="form-label">Vehicle *</label>
                <select className="form-select" value={selectedVehicle} onChange={e => setSelectedVehicle(e.target.value)}>
                  <option value="">Select vehicle...</option>
                  {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
                </select>
              </div>
              <div>
                <label className="form-label">Inspector *</label>
                <input className="form-input" placeholder="Full name" value={inspectorName} onChange={e => setInspectorName(e.target.value)} />
              </div>
              <div>
                <label className="form-label">Date</label>
                <input className="form-input" type="date" value={inspDate} onChange={e => setInspDate(e.target.value)} />
              </div>
              <div>
                <label className="form-label">Mileage (km)</label>
                <input className="form-input" type="number" placeholder="45000" value={mileage} onChange={e => setMileage(e.target.value)} />
              </div>
              <div>
                <label className="form-label">Fuel Level</label>
                <select className="form-select" value={fuelLevel} onChange={e => setFuelLevel(e.target.value)}>
                  {['','100%','75%','50%','25%','Empty'].map(l => <option key={l} value={l}>{l || 'Select...'}</option>)}
                </select>
              </div>
            </div>

            {/* Summary bar */}
            {items.length > 0 && (
              <div className="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg text-sm">
                <span className="flex items-center gap-1.5 text-green-600 dark:text-green-400 font-medium">
                  <CheckCircle className="w-4 h-4" /> {presentCount} Present
                </span>
                <span className="flex items-center gap-1.5 text-red-600 dark:text-red-400 font-medium">
                  <XCircle className="w-4 h-4" /> {missingCount} Missing
                </span>
                <span className="text-gray-400 text-xs ml-auto">{items.length} total items</span>
              </div>
            )}

            {/* Items */}
            {items.length > 0 && (
              <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
                {items.map((item, idx) => (
                  <div key={idx} className={`flex items-start gap-2 p-3 rounded-lg border transition-all ${item.present ? 'border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800' : 'border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800'}`}>
                    <button onClick={() => updateItem(idx,'present',!item.present)}
                      className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all ${item.present ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300 dark:border-gray-500 bg-white dark:bg-gray-700'}`}>
                      {item.present && <CheckCircle className="w-3 h-3" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{item.equipmentItem}</span>
                        {item.required && <span className="text-[10px] px-1.5 py-0.5 bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 rounded font-medium">REQ</span>}
                      </div>
                      {item.present && (
                        <div className="flex gap-2 mt-1.5">
                          <select className="form-select py-1 text-xs flex-1" value={item.condition} onChange={e => updateItem(idx,'condition',e.target.value)}>
                            {CONDITIONS.map(c => <option key={c}>{c}</option>)}
                          </select>
                          <input className="form-input py-1 text-xs flex-1" placeholder="Notes..." value={item.notes} onChange={e => updateItem(idx,'notes',e.target.value)} />
                        </div>
                      )}
                    </div>
                    <button onClick={() => removeItem(idx)} className="text-gray-400 hover:text-red-500 flex-shrink-0 mt-0.5 transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add custom */}
            <div className="flex gap-2">
              <input className="form-input flex-1 text-sm" placeholder="Add extra item for this check..." value={customItem}
                onChange={e => setCustomItem(e.target.value)} onKeyDown={e => e.key==='Enter' && addCustomItem()} />
              <button onClick={addCustomItem} className="btn-secondary"><Plus className="w-4 h-4" /></button>
            </div>

            <div className="flex gap-2 pt-1">
              <button onClick={handleSave} className="btn-primary flex-1 justify-center">
                <Save className="w-4 h-4" /> Save Check
              </button>
              <button onClick={handlePrint} className="btn-secondary" title="Print inspection form">
                <Printer className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ── History ──────────────────────────────────────────────────── */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 dark:text-white">Check History</h3>
            <select className="form-select w-48 text-sm" value={filterVehicle} onChange={e => setFilterVehicle(e.target.value)}>
              <option value="">All Vehicles</option>
              {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
            </select>
          </div>

          {loading ? <LoadingSpinner /> : Object.keys(grouped).length === 0 ? (
            <div className="card p-8 text-center text-sm text-gray-400">No checks recorded yet.</div>
          ) : Object.entries(grouped).slice(0,10).map(([key, group]) => {
            const missing  = group.items.filter(i => !i.present).length;
            const isOpen   = historyExpanded[key];
            return (
              <div key={key} className="card overflow-hidden">
                <button className={`w-full px-4 py-3 border-b flex items-center justify-between ${missing>0 ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'}`}
                  onClick={() => setHistoryExpanded(e => ({ ...e, [key]: !e[key] }))}>
                  <div className="flex items-center gap-3">
                    <div className="text-left">
                      <span className="font-medium text-sm text-gray-900 dark:text-white">{group.vehicle?.vehicleId} — {group.vehicle?.make} {group.vehicle?.model}</span>
                      <span className="text-xs text-gray-500 ml-2">{format(new Date(group.date),'dd MMM yyyy')}</span>
                    </div>
                    <span className={missing>0?'badge-red':'badge-green'}>{missing>0?`${missing} missing`:'All present'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={e => { e.stopPropagation(); handlePrintBlank(group.vehicle || {}); }}
                      className="p-1.5 hover:bg-white/60 dark:hover:bg-gray-700/60 rounded-lg text-gray-500 hover:text-brand-600 transition-colors" title="Print form">
                      <Printer className="w-4 h-4" />
                    </button>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
                  </div>
                </button>
                {isOpen && (
                  <div className="p-3 grid grid-cols-2 gap-1">
                    {group.items.map(item => (
                      <div key={item.id} className="flex items-center gap-2 text-xs py-1">
                        {item.present
                          ? <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                          : <XCircle    className="w-3.5 h-3.5 text-red-500   flex-shrink-0" />
                        }
                        <span className={item.present ? 'text-gray-700 dark:text-gray-300' : 'text-red-600 dark:text-red-400 font-semibold'}>{item.equipmentItem}</span>
                        {item.condition && item.condition !== 'Good' && <span className="text-gray-400 ml-auto">({item.condition})</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Vehicle template manager row */}
      {canEditVehicles && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-gray-500" /> Equipment Templates
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Manage saved equipment lists per vehicle. Templates are auto-loaded when starting a check.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {vehicles.map(v => (
              <div key={v.id} className="flex items-center justify-between p-3 border border-gray-100 dark:border-gray-700 rounded-xl hover:shadow-sm transition-shadow">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-gray-900 dark:text-white truncate">{v.vehicleId}</div>
                  <div className="text-xs text-gray-400 truncate">{v.make} {v.model}</div>
                </div>
                <div className="flex gap-1 flex-shrink-0 ml-2">
                  <button onClick={() => handlePrintBlank(v)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-gray-500 hover:text-brand-600 transition-colors" title="Print blank form">
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => { setTemplateVehicle(v); setTemplateOpen(true); }} className="p-1.5 hover:bg-brand-50 dark:hover:bg-brand-900/30 rounded-lg text-gray-500 hover:text-brand-600 transition-colors" title="Edit template">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Template Modal */}
      <TemplateModal
        open={templateOpen}
        onClose={() => { setTemplateOpen(false); setTemplateVehicle(null); }}
        vehicleId={templateVehicle?.id}
        vehicleName={templateVehicle ? `${templateVehicle.vehicleId} — ${templateVehicle.make} ${templateVehicle.model}` : ''}
        onSaved={() => {
          if (selectedVehicle && templateVehicle?.id === parseInt(selectedVehicle)) {
            // Reload items for current check
            api.get(`/equipment/template/${selectedVehicle}`)
              .then(r => {
                if (r.data.length > 0)
                  setItems(r.data.map(t => ({ equipmentItem: t.itemName, present: true, condition: 'Good', notes: '', required: t.required })));
              });
          }
        }}
      />
    </div>
  );
}
