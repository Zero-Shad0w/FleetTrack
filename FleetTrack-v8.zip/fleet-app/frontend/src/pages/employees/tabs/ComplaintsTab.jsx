import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, MessageSquare, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format } from 'date-fns';

const STATUS_COLORS = { open: 'badge-yellow', in_review: 'badge-blue', resolved: 'badge-green', closed: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium' };
const PRIORITY_COLORS = { low: 'badge-green', medium: 'badge-yellow', high: 'badge-orange', urgent: 'badge-red' };
const CATEGORIES = ['HR Request','Workplace Issue','Harassment','Safety Concern','Suggestion','Complaint','Other'];
const STATUSES   = ['open','in_review','resolved','closed'];
const PRIORITIES = ['low','medium','high','urgent'];

const EMPTY_C = {
  title: '', category: 'Complaint', priority: 'medium', description: '',
  date: format(new Date(), 'yyyy-MM-dd'), status: 'open', adminReply: '',
  anonymous: false, internalNotes: '',
};

export default function ComplaintsTab({ employeeId, canEdit }) {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [modalOpen, setModalOpen]   = useState(false);
  const [editing, setEditing]       = useState(null);
  const [form, setForm]             = useState(EMPTY_C);
  const [deleteId, setDeleteId]     = useState(null);
  const [expanded, setExpanded]     = useState(null);
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/complaints`);
      setComplaints(data);
    } catch { /* permission denied */ }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId]);

  const openNew  = () => { setForm(EMPTY_C); setEditing(null); setModalOpen(true); };
  const openEdit = (c) => {
    setEditing(c);
    setForm({ ...c, date: format(new Date(c.date), 'yyyy-MM-dd') });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim()) return toast.error('Title is required');
    try {
      if (editing) { await api.put(`/employees/${employeeId}/complaints/${editing.id}`, form); toast.success('Updated'); }
      else         { await api.post(`/employees/${employeeId}/complaints`, form);               toast.success('Complaint added'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/employees/${employeeId}/complaints/${deleteId}`); toast.success('Deleted'); load(); }
    catch (err) { toast.error('Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const open = complaints.filter(c => c.status === 'open').length;

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-purple-500" /> Complaints & Reports
          {open > 0 && <span className="badge-yellow">{open} open</span>}
        </h3>
        {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Complaint</button>}
      </div>

      {complaints.length === 0 ? (
        <EmptyState icon={MessageSquare} title="No complaints" message="No complaints or reports recorded."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add</button>} />
      ) : (
        <div className="space-y-3">
          {complaints.map(c => (
            <div key={c.id} className="border border-gray-100 dark:border-gray-700 rounded-xl overflow-hidden">
              <div className="p-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                onClick={() => setExpanded(expanded === c.id ? null : c.id)}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-gray-900 dark:text-white text-sm">{c.anonymous ? '🔒 Anonymous' : c.title}</span>
                      <span className={STATUS_COLORS[c.status] || 'badge-blue'}>{c.status.replace('_',' ')}</span>
                      <span className={PRIORITY_COLORS[c.priority] || 'badge-blue'}>{c.priority}</span>
                      <span className="badge-blue text-xs">{c.category}</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1 flex items-center gap-3">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{format(new Date(c.date), 'dd MMM yyyy')}</span>
                    </div>
                  </div>
                  {canEdit && (
                    <div className="flex gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                      <button onClick={() => openEdit(c)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600"><Edit2 className="w-3.5 h-3.5" /></button>
                      <button onClick={() => setDeleteId(c.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  )}
                </div>
              </div>

              {expanded === c.id && (
                <div className="px-4 pb-4 border-t border-gray-50 dark:border-gray-700 pt-3 space-y-3">
                  {c.description && <div><p className="text-xs font-medium text-gray-500 mb-1">Description</p><p className="text-sm text-gray-700 dark:text-gray-300">{c.description}</p></div>}
                  {c.adminReply  && (
                    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                      <p className="text-xs font-medium text-green-700 dark:text-green-400 mb-1 flex items-center gap-1"><CheckCircle className="w-3 h-3" />Admin Reply</p>
                      <p className="text-sm text-green-900 dark:text-green-300">{c.adminReply}</p>
                    </div>
                  )}
                  {c.internalNotes && (
                    <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                      <p className="text-xs font-medium text-gray-500 mb-1">Internal Notes</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{c.internalNotes}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Complaint' : 'New Complaint / Report'} size="md">
        <div className="space-y-4">
          <div><label className="form-label">Title *</label><input className="form-input" placeholder="Complaint title" {...f('title')} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="form-label">Category</label>
              <select className="form-select" {...f('category')}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select>
            </div>
            <div><label className="form-label">Priority</label>
              <select className="form-select" {...f('priority')}>{PRIORITIES.map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase()+p.slice(1)}</option>)}</select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="form-label">Date</label><input className="form-input" type="date" {...f('date')} /></div>
            <div><label className="form-label">Status</label>
              <select className="form-select" {...f('status')}>{STATUSES.map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}</select>
            </div>
          </div>
          <div><label className="form-label">Description</label><textarea className="form-input h-20 resize-none" {...f('description')} /></div>
          <div><label className="form-label">Admin Reply</label><textarea className="form-input h-16 resize-none" placeholder="Reply from management..." {...f('adminReply')} /></div>
          <div><label className="form-label">Internal Notes</label><textarea className="form-input h-16 resize-none" placeholder="Internal notes (not visible to employee)" {...f('internalNotes')} /></div>
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" checked={form.anonymous} onChange={e => setForm(p => ({ ...p, anonymous: e.target.checked }))} className="rounded" />
            <span className="text-sm text-gray-700 dark:text-gray-300">🔒 Anonymous complaint</span>
          </label>
        </div>
        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Submit'}</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Complaint" message="Permanently delete this complaint record?" danger />
    </div>
  );
}
