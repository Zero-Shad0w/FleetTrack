import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, AlertTriangle, Clock } from 'lucide-react';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format } from 'date-fns';

const SEVERITY = { minor: 'badge-yellow', moderate: 'badge-orange', serious: 'badge-red', final: 'bg-red-200 text-red-900 dark:bg-red-900/50 dark:text-red-300 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium' };
const TYPES = ['Verbal Warning','Written Warning','Performance Warning','Conduct Warning','Attendance Warning','Safety Warning','Other'];

const EMPTY_W = {
  title: '', warningType: 'Written Warning', severity: 'minor', description: '',
  dateIssued: format(new Date(), 'yyyy-MM-dd'), issuedBy: '', reason: '',
  relatedIncident: '', actionTaken: '', employeeResponse: '', signature: '',
};

export default function WarningsTab({ employeeId, canEdit }) {
  const [warnings, setWarnings] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing]   = useState(null);
  const [form, setForm]         = useState(EMPTY_W);
  const [deleteId, setDeleteId] = useState(null);
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/warnings`);
      setWarnings(data);
    } catch { /* permission denied = empty */ }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId]);

  const openNew  = () => { setForm(EMPTY_W); setEditing(null); setModalOpen(true); };
  const openEdit = (w) => {
    setEditing(w);
    setForm({ ...w, dateIssued: format(new Date(w.dateIssued), 'yyyy-MM-dd') });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim()) return toast.error('Title is required');
    try {
      if (editing) { await api.put(`/employees/${employeeId}/warnings/${editing.id}`, form); toast.success('Warning updated'); }
      else         { await api.post(`/employees/${employeeId}/warnings`, form);              toast.success('Warning added'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/employees/${employeeId}/warnings/${deleteId}`); toast.success('Warning deleted'); load(); }
    catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-orange-500" /> Warnings & Disciplinary Actions
          {warnings.length > 0 && <span className="badge-red">{warnings.length}</span>}
        </h3>
        {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Warning</button>}
      </div>

      {warnings.length === 0 ? (
        <EmptyState icon={AlertTriangle} title="No warnings" message="No disciplinary actions recorded."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Warning</button>} />
      ) : (
        <div className="space-y-3">
          {warnings.map(w => (
            <div key={w.id} className="border border-gray-100 dark:border-gray-700 rounded-xl p-4 hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-xl flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-gray-900 dark:text-white text-sm">{w.title}</span>
                      <span className={SEVERITY[w.severity] || 'badge-yellow'}>{w.severity}</span>
                      <span className="badge-blue text-xs">{w.warningType}</span>
                    </div>
                    {w.description && <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{w.description}</p>}
                    <div className="flex items-center gap-4 mt-2 text-xs text-gray-400 flex-wrap">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{format(new Date(w.dateIssued), 'dd MMM yyyy')}</span>
                      {w.issuedBy && <span>Issued by: {w.issuedBy}</span>}
                      {w.actionTaken && <span>Action: {w.actionTaken}</span>}
                    </div>
                    {w.employeeResponse && (
                      <div className="mt-2 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2 text-xs text-blue-800 dark:text-blue-300">
                        <strong>Employee Response:</strong> {w.employeeResponse}
                      </div>
                    )}
                  </div>
                </div>
                {canEdit && (
                  <div className="flex gap-1 flex-shrink-0">
                    <button onClick={() => openEdit(w)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>
                    <button onClick={() => setDeleteId(w.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Warning' : 'Add Warning'} size="lg">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Title *</label><input className="form-input" placeholder="Warning title" {...f('title')} /></div>
          <div><label className="form-label">Type</label>
            <select className="form-select" {...f('warningType')}>{TYPES.map(t => <option key={t}>{t}</option>)}</select>
          </div>
          <div><label className="form-label">Severity</label>
            <select className="form-select" {...f('severity')}>
              {['minor','moderate','serious','final'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
            </select>
          </div>
          <div><label className="form-label">Date Issued</label><input className="form-input" type="date" {...f('dateIssued')} /></div>
          <div><label className="form-label">Issued By</label><input className="form-input" placeholder="Manager name" {...f('issuedBy')} /></div>
          <div className="col-span-2"><label className="form-label">Description</label><textarea className="form-input h-20 resize-none" {...f('description')} /></div>
          <div className="col-span-2"><label className="form-label">Reason</label><input className="form-input" {...f('reason')} /></div>
          <div><label className="form-label">Related Incident</label><input className="form-input" {...f('relatedIncident')} /></div>
          <div><label className="form-label">Action Taken</label><input className="form-input" {...f('actionTaken')} /></div>
          <div className="col-span-2"><label className="form-label">Employee Response</label><textarea className="form-input h-16 resize-none" {...f('employeeResponse')} /></div>
          <div className="col-span-2"><label className="form-label">Signature</label><input className="form-input" placeholder="Type full name as signature" {...f('signature')} /></div>
        </div>
        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Add Warning'}</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Warning" message="Permanently delete this warning record?" danger />
    </div>
  );
}
