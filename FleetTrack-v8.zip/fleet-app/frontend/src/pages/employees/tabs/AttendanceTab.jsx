import React, { useState, useEffect } from 'react';
import {
  ChevronLeft, ChevronRight, Calendar, CheckCircle, XCircle,
  AlertCircle, Coffee, Edit2, Trash2, Clock, MoreHorizontal,
  Loader2
} from 'lucide-react';
import { Modal, ConfirmDialog, LoadingSpinner } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format, getDaysInMonth, startOfMonth, getDay } from 'date-fns';

const DEFAULT_SHIFT_HOURS = 8;

const STATUS_CONFIG = {
  present:        { label: 'Present',        bg: 'bg-green-500',   ring: 'ring-green-400',  text: 'text-green-700 dark:text-green-400',  badge: 'badge-green',  dot: '#22c55e' },
  absent:         { label: 'Absent',         bg: 'bg-red-500',     ring: 'ring-red-400',    text: 'text-red-700 dark:text-red-400',      badge: 'badge-red',    dot: '#ef4444' },
  late:           { label: 'Late',           bg: 'bg-yellow-500',  ring: 'ring-yellow-400', text: 'text-yellow-700 dark:text-yellow-400',badge: 'badge-yellow', dot: '#eab308' },
  half_day:       { label: 'Half Day',       bg: 'bg-orange-400',  ring: 'ring-orange-400', text: 'text-orange-700 dark:text-orange-400',badge: 'badge-yellow', dot: '#f97316' },
  on_leave:       { label: 'On Leave',       bg: 'bg-blue-500',    ring: 'ring-blue-400',   text: 'text-blue-700 dark:text-blue-400',    badge: 'badge-blue',   dot: '#3b82f6' },
  public_holiday: { label: 'Holiday',        bg: 'bg-purple-500',  ring: 'ring-purple-400', text: 'text-purple-700 dark:text-purple-400',badge: 'badge-blue',   dot: '#8b5cf6' },
  remote:         { label: 'Remote',         bg: 'bg-teal-500',    ring: 'ring-teal-400',   text: 'text-teal-700 dark:text-teal-400',    badge: 'badge-green',  dot: '#14b8a6' },
};

const QUICK_STATUSES = ['present','absent','late','half_day','on_leave','remote','public_holiday'];

const EMPTY_DETAIL = {
  checkIn: '08:00', checkOut: '17:00', hoursWorked: '8', overtime: '0',
  notes: '', approvedBy: '', status: 'present',
};

export default function AttendanceTab({ employeeId, canEdit }) {
  const [records, setRecords]     = useState([]);
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(null); // dateStr being saved
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode]   = useState('calendar');
  const [detailOpen, setDetailOpen]   = useState(false);
  const [detailRecord, setDetailRecord] = useState(null);
  const [detailForm, setDetailForm]   = useState(EMPTY_DETAIL);
  const [deleteId, setDeleteId]   = useState(null);
  const [quickMenuDate, setQuickMenuDate] = useState(null); // date showing status picker
  const toast = useToast();

  const month = currentDate.getMonth() + 1;
  const year  = currentDate.getFullYear();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/attendance`, { params: { month, year } });
      setRecords(data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId, month, year]);

  // ── Quick mark: one click = present with default 8h shift ────────────────
  const quickMark = async (dateStr, status = 'present') => {
    if (!canEdit) return;
    setSaving(dateStr);
    setQuickMenuDate(null);
    try {
      const existing = getRecordForDate(dateStr);
      const payload = {
        date: dateStr,
        status,
        hoursWorked: ['present','remote','late'].includes(status) ? DEFAULT_SHIFT_HOURS : (status === 'half_day' ? 4 : 0),
        overtime: 0,
        checkIn:  ['present','remote','late'].includes(status) ? '08:00' : '',
        checkOut: ['present','remote','late'].includes(status) ? '17:00' : '',
      };
      if (existing) {
        await api.put(`/employees/${employeeId}/attendance/${existing.id}`, payload);
      } else {
        await api.post(`/employees/${employeeId}/attendance`, payload);
      }
      await load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save');
    } finally { setSaving(null); }
  };

  // ── Remove a record ───────────────────────────────────────────────────────
  const handleDelete = async () => {
    try {
      await api.delete(`/employees/${employeeId}/attendance/${deleteId}`);
      toast.success('Record removed');
      load();
    } catch { toast.error('Delete failed'); }
  };

  // ── Open detail editor ────────────────────────────────────────────────────
  const openDetail = (rec, dateStr) => {
    setDetailRecord(rec);
    setDetailForm({
      checkIn:     rec?.checkIn     || '08:00',
      checkOut:    rec?.checkOut    || '17:00',
      hoursWorked: rec?.hoursWorked?.toString() || '8',
      overtime:    rec?.overtime?.toString()    || '0',
      notes:       rec?.notes       || '',
      approvedBy:  rec?.approvedBy  || '',
      status:      rec?.status      || 'present',
      date:        dateStr || (rec ? format(new Date(rec.date), 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd')),
    });
    setDetailOpen(true);
  };

  const saveDetail = async () => {
    try {
      const payload = {
        ...detailForm,
        hoursWorked: parseFloat(detailForm.hoursWorked) || 0,
        overtime:    parseFloat(detailForm.overtime)    || 0,
      };
      if (detailRecord) {
        await api.put(`/employees/${employeeId}/attendance/${detailRecord.id}`, payload);
      } else {
        await api.post(`/employees/${employeeId}/attendance`, payload);
      }
      toast.success('Attendance saved');
      setDetailOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Save failed');
    }
  };

  // ── Helpers ───────────────────────────────────────────────────────────────
  const getRecordForDate = (dateStr) =>
    records.find(r => format(new Date(r.date), 'yyyy-MM-dd') === dateStr);

  const daysInMonth    = getDaysInMonth(currentDate);
  const firstDayOfWeek = getDay(startOfMonth(currentDate));

  const prevMonth = () => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() + 1, 1));

  // Stats
  const presentCount = records.filter(r => ['present','remote'].includes(r.status)).length;
  const absentCount  = records.filter(r => r.status === 'absent').length;
  const lateCount    = records.filter(r => r.status === 'late').length;
  const totalHours   = records.reduce((s, r) => s + (r.hoursWorked || 0), 0);
  const totalOT      = records.reduce((s, r) => s + (r.overtime    || 0), 0);

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Calendar className="w-4 h-4 text-brand-500" /> Attendance
        </h3>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-lg">
            {[['calendar','Calendar'],['list','List']].map(([v,l]) => (
              <button key={v} onClick={() => setViewMode(v)}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${viewMode===v ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-5 gap-2 mb-5">
        {[
          ['Present',  presentCount,          'text-green-600  dark:text-green-400'],
          ['Absent',   absentCount,           'text-red-600    dark:text-red-400'],
          ['Late',     lateCount,             'text-yellow-600 dark:text-yellow-400'],
          ['Hours',    totalHours.toFixed(1), 'text-brand-600  dark:text-brand-400'],
          ['Overtime', totalOT.toFixed(1),    'text-purple-600 dark:text-purple-400'],
        ].map(([lbl, val, cls]) => (
          <div key={lbl} className="card p-3 text-center">
            <div className={`text-lg font-bold ${cls}`}>{val}</div>
            <div className="text-xs text-gray-400 mt-0.5">{lbl}</div>
          </div>
        ))}
      </div>

      {/* ── CALENDAR VIEW ──────────────────────────────────────────────────── */}
      {viewMode === 'calendar' && (
        <div className="card overflow-hidden">
          {/* Month nav */}
          <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100 dark:border-gray-700">
            <button onClick={prevMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"><ChevronLeft className="w-4 h-4 text-gray-500" /></button>
            <span className="font-semibold text-gray-900 dark:text-white">{format(currentDate, 'MMMM yyyy')}</span>
            <button onClick={nextMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"><ChevronRight className="w-4 h-4 text-gray-500" /></button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 border-b border-gray-100 dark:border-gray-700">
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
              <div key={d} className="py-2 text-center text-xs font-semibold text-gray-400 uppercase tracking-wide">{d}</div>
            ))}
          </div>

          {/* Days */}
          <div className="grid grid-cols-7">
            {/* Empty offset */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`e${i}`} className="h-20 border-b border-r border-gray-50 dark:border-gray-700/40 bg-gray-50/50 dark:bg-gray-800/30" />
            ))}

            {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(day => {
              const dateStr  = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
              const rec      = getRecordForDate(dateStr);
              const cfg      = rec ? STATUS_CONFIG[rec.status] : null;
              const isToday  = format(new Date(), 'yyyy-MM-dd') === dateStr;
              const isFuture = new Date(dateStr) > new Date();
              const isWeekend = (firstDayOfWeek + day - 1) % 7 === 0 || (firstDayOfWeek + day - 1) % 7 === 6;
              const isSaving = saving === dateStr;
              const showMenu = quickMenuDate === dateStr;

              return (
                <div key={day} className={`h-20 border-b border-r border-gray-50 dark:border-gray-700/40 relative ${isWeekend ? 'bg-gray-50/60 dark:bg-gray-800/40' : ''}`}>
                  {/* Day number */}
                  <div className="absolute top-1.5 left-2">
                    <span className={`text-xs font-semibold w-5 h-5 flex items-center justify-center rounded-full ${isToday ? 'bg-brand-600 text-white' : 'text-gray-600 dark:text-gray-400'}`}>
                      {day}
                    </span>
                  </div>

                  {/* Loading spinner */}
                  {isSaving && (
                    <div className="absolute inset-0 flex items-center justify-center bg-white/60 dark:bg-gray-800/60">
                      <Loader2 className="w-5 h-5 text-brand-500 animate-spin" />
                    </div>
                  )}

                  {/* Main interaction area */}
                  {!isSaving && !isFuture && canEdit && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 pt-4">
                      {rec ? (
                        /* Has record — show status + actions */
                        <>
                          <div className={`w-7 h-7 rounded-full ${cfg.bg} flex items-center justify-center shadow-sm`}
                            title={cfg.label}>
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className={`text-[10px] font-medium ${cfg.text}`}>{cfg.label}</span>
                          {/* Overtime badge */}
                          {rec.overtime > 0 && (
                            <span className="text-[9px] text-purple-600 dark:text-purple-400 font-semibold">+{rec.overtime}h OT</span>
                          )}
                          {/* Action icons */}
                          <div className="flex gap-1 mt-0.5">
                            <button
                              onClick={() => openDetail(rec, dateStr)}
                              className="p-0.5 text-gray-400 hover:text-blue-500 transition-colors"
                              title="Edit details">
                              <Edit2 className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => setQuickMenuDate(showMenu ? null : dateStr)}
                              className="p-0.5 text-gray-400 hover:text-gray-600 transition-colors"
                              title="Change status">
                              <MoreHorizontal className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => setDeleteId(rec.id)}
                              className="p-0.5 text-gray-400 hover:text-red-500 transition-colors"
                              title="Remove">
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </>
                      ) : (
                        /* No record — big tick button */
                        <button
                          onClick={() => quickMark(dateStr, 'present')}
                          className="flex flex-col items-center gap-0.5 group"
                          title="Mark present (8h shift)">
                          <div className="w-8 h-8 rounded-full border-2 border-dashed border-gray-300 dark:border-gray-600 group-hover:border-green-400 group-hover:bg-green-50 dark:group-hover:bg-green-900/20 flex items-center justify-center transition-all">
                            <CheckCircle className="w-5 h-5 text-gray-300 dark:text-gray-600 group-hover:text-green-500 transition-colors" />
                          </div>
                          <span className="text-[9px] text-gray-300 dark:text-gray-600 group-hover:text-green-500 transition-colors">Mark</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* View-only record display */}
                  {!isSaving && !isFuture && !canEdit && rec && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pt-4 gap-1">
                      <div className={`w-6 h-6 rounded-full ${cfg.bg}`} />
                      <span className={`text-[10px] font-medium ${cfg.text}`}>{cfg.label}</span>
                    </div>
                  )}

                  {/* Quick status menu */}
                  {showMenu && (
                    <div className="absolute z-20 top-full left-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl shadow-xl p-2 w-36"
                      style={{ zIndex: 50 }}>
                      <p className="text-[10px] font-semibold text-gray-400 uppercase mb-1.5 px-1">Change status</p>
                      {QUICK_STATUSES.map(s => {
                        const c = STATUS_CONFIG[s];
                        return (
                          <button key={s} onClick={() => quickMark(dateStr, s)}
                            className="flex items-center gap-2 w-full px-2 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left">
                            <div className={`w-2.5 h-2.5 rounded-full ${c.bg}`} />
                            <span className="text-xs text-gray-700 dark:text-gray-300">{c.label}</span>
                          </button>
                        );
                      })}
                      <button onClick={() => { setQuickMenuDate(null); openDetail(rec, dateStr); }}
                        className="flex items-center gap-2 w-full px-2 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors mt-1 border-t border-gray-100 dark:border-gray-700 pt-2">
                        <Edit2 className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-700 dark:text-gray-300">Edit details</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="px-5 py-3 border-t border-gray-100 dark:border-gray-700 flex flex-wrap gap-3">
            {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
              <div key={key} className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
                <div className={`w-3 h-3 rounded-full ${cfg.bg}`} />
                {cfg.label}
              </div>
            ))}
          </div>

          {canEdit && (
            <div className="px-5 py-3 border-t border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/30">
              <p className="text-xs text-gray-400">
                <strong className="text-gray-500 dark:text-gray-400">Tip:</strong> Click ✓ on any day to instantly mark as present (8h shift).
                Use <MoreHorizontal className="w-3 h-3 inline" /> to change status, or <Edit2 className="w-3 h-3 inline" /> to set exact hours & overtime.
              </p>
            </div>
          )}
        </div>
      )}

      {/* ── LIST VIEW ──────────────────────────────────────────────────────── */}
      {viewMode === 'list' && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <button onClick={prevMonth} className="btn-secondary py-1 px-3 text-sm"><ChevronLeft className="w-4 h-4" /></button>
            <span className="font-medium text-gray-900 dark:text-white">{format(currentDate, 'MMMM yyyy')}</span>
            <button onClick={nextMonth} className="btn-secondary py-1 px-3 text-sm"><ChevronRight className="w-4 h-4" /></button>
          </div>

          {records.length === 0 ? (
            <div className="card p-8 text-center text-sm text-gray-400">No records for this month.</div>
          ) : (
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                    {['Date','Status','Check In','Check Out','Hours','Overtime','Notes',''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                  {records.sort((a,b) => new Date(b.date) - new Date(a.date)).map((r, i) => {
                    const cfg = STATUS_CONFIG[r.status] || STATUS_CONFIG.present;
                    return (
                      <tr key={r.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i%2?'bg-gray-50/50 dark:bg-gray-800/30':''}`}>
                        <td className="px-4 py-3 font-medium text-gray-900 dark:text-white whitespace-nowrap">{format(new Date(r.date),'EEE dd MMM')}</td>
                        <td className="px-4 py-3"><span className={cfg.badge}>{cfg.label}</span></td>
                        <td className="px-4 py-3 font-mono text-xs text-gray-500 dark:text-gray-400">{r.checkIn  || '—'}</td>
                        <td className="px-4 py-3 font-mono text-xs text-gray-500 dark:text-gray-400">{r.checkOut || '—'}</td>
                        <td className="px-4 py-3 text-gray-700 dark:text-gray-300">{r.hoursWorked ? `${r.hoursWorked}h` : '—'}</td>
                        <td className="px-4 py-3 text-purple-600 dark:text-purple-400 font-medium">{r.overtime ? `+${r.overtime}h` : '—'}</td>
                        <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs max-w-xs truncate">{r.notes || '—'}</td>
                        <td className="px-4 py-3">
                          {canEdit && (
                            <div className="flex gap-1">
                              <button onClick={() => openDetail(r, null)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>
                              <button onClick={() => setDeleteId(r.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── DETAIL EDITOR MODAL ────────────────────────────────────────────── */}
      <Modal open={detailOpen} onClose={() => setDetailOpen(false)} title="Edit Attendance Details" size="sm">
        <div className="space-y-4">
          {/* Status quick picker */}
          <div>
            <label className="form-label">Status</label>
            <div className="flex flex-wrap gap-2">
              {QUICK_STATUSES.map(s => {
                const c = STATUS_CONFIG[s];
                return (
                  <button key={s} type="button" onClick={() => setDetailForm(f => ({ ...f, status: s }))}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border-2 transition-all ${detailForm.status === s ? `${c.bg} text-white border-transparent` : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-gray-300'}`}>
                    <div className={`w-2 h-2 rounded-full ${detailForm.status === s ? 'bg-white' : c.bg}`} />
                    {c.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Check In</label>
              <input className="form-input" type="time" value={detailForm.checkIn}
                onChange={e => setDetailForm(f => ({ ...f, checkIn: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">Check Out</label>
              <input className="form-input" type="time" value={detailForm.checkOut}
                onChange={e => setDetailForm(f => ({ ...f, checkOut: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">Normal Hours</label>
              <div className="relative">
                <input className="form-input pr-8" type="number" step="0.5" min="0" max="24"
                  value={detailForm.hoursWorked}
                  onChange={e => setDetailForm(f => ({ ...f, hoursWorked: e.target.value }))} />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">h</span>
              </div>
            </div>
            <div>
              <label className="form-label">Overtime Hours</label>
              <div className="relative">
                <input className="form-input pr-8" type="number" step="0.5" min="0"
                  value={detailForm.overtime}
                  onChange={e => setDetailForm(f => ({ ...f, overtime: e.target.value }))} />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-purple-500 font-medium">OT</span>
              </div>
            </div>
          </div>

          {/* Total hours display */}
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
              <Clock className="w-4 h-4" />
              Total hours
            </div>
            <div className="text-sm font-bold text-gray-900 dark:text-white">
              {(parseFloat(detailForm.hoursWorked)||0) + (parseFloat(detailForm.overtime)||0)}h
              {parseFloat(detailForm.overtime) > 0 && (
                <span className="text-purple-500 ml-1 font-normal text-xs">(incl. {detailForm.overtime}h OT)</span>
              )}
            </div>
          </div>

          <div>
            <label className="form-label">Approved By</label>
            <input className="form-input" placeholder="Manager name (optional)"
              value={detailForm.approvedBy}
              onChange={e => setDetailForm(f => ({ ...f, approvedBy: e.target.value }))} />
          </div>
          <div>
            <label className="form-label">Notes</label>
            <textarea className="form-input h-16 resize-none" placeholder="Optional notes..."
              value={detailForm.notes}
              onChange={e => setDetailForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
        </div>

        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setDetailOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={saveDetail} className="btn-primary">Save Details</button>
        </div>
      </Modal>

      {/* Close quick menu on outside click */}
      {quickMenuDate && (
        <div className="fixed inset-0 z-40" onClick={() => setQuickMenuDate(null)} />
      )}

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Remove Record" message="Remove this attendance record?" danger />
    </div>
  );
}
