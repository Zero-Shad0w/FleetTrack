import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Wrench, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format } from 'date-fns';

const STATUS_COLORS = { assigned: 'badge-blue', returned: 'badge-green', damaged: 'badge-red', lost: 'bg-red-200 text-red-900 dark:bg-red-900/50 dark:text-red-200 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium' };
const TOOL_TYPES    = ['Power Tool','Hand Tool','Safety Equipment','Electronic','Vehicle','Uniform','Key/Access','Communication','Other'];
const CONDITIONS    = ['New','Excellent','Good','Fair','Poor','Damaged'];
const STATUSES      = ['assigned','returned','damaged','lost'];

const EMPTY_T = {
  toolName: '', toolType: '', serialNumber: '', assetNumber: '', condition: 'Good',
  assignedDate: format(new Date(), 'yyyy-MM-dd'), returnDate: '', status: 'assigned', notes: '',
};

export default function ToolsTab({ employeeId, canEdit }) {
  const [tools, setTools]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing]   = useState(null);
  const [form, setForm]         = useState(EMPTY_T);
  const [deleteId, setDeleteId] = useState(null);
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/tools`);
      setTools(data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId]);

  const openNew  = () => { setForm(EMPTY_T); setEditing(null); setModalOpen(true); };
  const openEdit = (t) => {
    setEditing(t);
    setForm({ ...t, assignedDate: t.assignedDate ? format(new Date(t.assignedDate), 'yyyy-MM-dd') : '', returnDate: t.returnDate ? format(new Date(t.returnDate), 'yyyy-MM-dd') : '' });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.toolName.trim()) return toast.error('Tool name is required');
    try {
      if (editing) { await api.put(`/employees/${employeeId}/tools/${editing.id}`, form); toast.success('Tool updated'); }
      else         { await api.post(`/employees/${employeeId}/tools`, form);              toast.success('Tool assigned'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/employees/${employeeId}/tools/${deleteId}`); toast.success('Tool removed'); load(); }
    catch (err) { toast.error('Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const assigned = tools.filter(t => t.status === 'assigned').length;

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Wrench className="w-4 h-4 text-blue-500" /> Assigned Tools & Equipment
          {assigned > 0 && <span className="badge-blue">{assigned} active</span>}
        </h3>
        {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Assign Tool</button>}
      </div>

      {tools.length === 0 ? (
        <EmptyState icon={Wrench} title="No tools assigned" message="No equipment currently assigned to this employee."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Assign Tool</button>} />
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-100 dark:border-gray-700">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                {['Tool','Type','Serial / Asset','Condition','Assigned','Return','Status',''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
              {tools.map((t, i) => (
                <tr key={t.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i%2?'bg-gray-50/50 dark:bg-gray-800/30':''}`}>
                  <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{t.toolName}</td>
                  <td className="px-4 py-3 text-gray-500 dark:text-gray-400">{t.toolType || '—'}</td>
                  <td className="px-4 py-3 text-gray-500 dark:text-gray-400 font-mono text-xs">{[t.serialNumber, t.assetNumber].filter(Boolean).join(' / ') || '—'}</td>
                  <td className="px-4 py-3 text-gray-500 dark:text-gray-400">{t.condition || '—'}</td>
                  <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">{t.assignedDate ? format(new Date(t.assignedDate), 'dd MMM yyyy') : '—'}</td>
                  <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">{t.returnDate ? format(new Date(t.returnDate), 'dd MMM yyyy') : '—'}</td>
                  <td className="px-4 py-3"><span className={STATUS_COLORS[t.status] || 'badge-blue'}>{t.status}</span></td>
                  <td className="px-4 py-3">
                    {canEdit && (
                      <div className="flex gap-1">
                        <button onClick={() => openEdit(t)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600"><Edit2 className="w-3.5 h-3.5" /></button>
                        <button onClick={() => setDeleteId(t.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Tool' : 'Assign Tool'} size="md">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="form-label">Tool Name *</label><input className="form-input" placeholder="e.g. Safety Vest" {...f('toolName')} /></div>
          <div><label className="form-label">Type</label>
            <select className="form-select" {...f('toolType')}><option value="">Select...</option>{TOOL_TYPES.map(t => <option key={t}>{t}</option>)}</select>
          </div>
          <div><label className="form-label">Condition</label>
            <select className="form-select" {...f('condition')}>{CONDITIONS.map(c => <option key={c}>{c}</option>)}</select>
          </div>
          <div><label className="form-label">Serial Number</label><input className="form-input" placeholder="SN-001" {...f('serialNumber')} /></div>
          <div><label className="form-label">Asset Number</label><input className="form-input" placeholder="AST-001" {...f('assetNumber')} /></div>
          <div><label className="form-label">Assigned Date</label><input className="form-input" type="date" {...f('assignedDate')} /></div>
          <div><label className="form-label">Return Date</label><input className="form-input" type="date" {...f('returnDate')} /></div>
          <div className="col-span-2"><label className="form-label">Status</label>
            <select className="form-select" {...f('status')}>{STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}</select>
          </div>
          <div className="col-span-2"><label className="form-label">Notes</label><textarea className="form-input h-16 resize-none" {...f('notes')} /></div>
        </div>
        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Assign Tool'}</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Remove Tool" message="Remove this tool assignment from the employee?" danger />
    </div>
  );
}
