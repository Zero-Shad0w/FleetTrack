import React, { useState, useEffect, useRef } from 'react';
import { Plus, Trash2, FolderOpen, Download, FileText, Image, File, AlertCircle, Upload } from 'lucide-react';
import { ConfirmDialog, LoadingSpinner, EmptyState } from '../../../components/ui';
import { Modal } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format } from 'date-fns';

const CATEGORIES = ['Contract','ID Document','Certificate','License','Medical','Training','Performance Review','Other'];
const MAX_SIZE_MB = 20;

const fmtSize = (bytes) => {
  if (!bytes) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024*1024) return `${(bytes/1024).toFixed(1)} KB`;
  return `${(bytes/(1024*1024)).toFixed(1)} MB`;
};

const getIcon = (fileType) => {
  if (!fileType) return File;
  if (fileType.startsWith('image/')) return Image;
  if (fileType === 'application/pdf') return FileText;
  return File;
};

const getIconColor = (fileType) => {
  if (!fileType) return 'text-gray-500';
  if (fileType.startsWith('image/')) return 'text-purple-500';
  if (fileType === 'application/pdf') return 'text-red-500';
  return 'text-blue-500';
};

export default function DocumentsTab({ employeeId, canEdit }) {
  const [docs, setDocs]         = useState([]);
  const [loading, setLoading]   = useState(true);
  const [uploading, setUploading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [previewDoc, setPreviewDoc] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [filterCat, setFilterCat] = useState('');
  const [form, setForm] = useState({ name: '', category: 'Contract', expiryDate: '', notes: '', fileData: null, fileType: '', fileSize: 0 });
  const dropRef  = useRef();
  const inputRef = useRef();
  const toast    = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/documents`);
      setDocs(data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId]);

  const processFile = (file) => {
    if (file.size > MAX_SIZE_MB * 1024 * 1024) { toast.error(`File too large — max ${MAX_SIZE_MB}MB`); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      setForm(f => ({
        ...f,
        name: f.name || file.name,
        fileData: ev.target.result,
        fileType: file.type,
        fileSize: file.size,
      }));
    };
    reader.readAsDataURL(file);
    setModalOpen(true);
  };

  const handleFileInput = (e) => {
    const file = e.target.files[0];
    if (file) processFile(file);
    e.target.value = '';
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const handleSave = async () => {
    if (!form.name.trim())  return toast.error('Document name is required');
    if (!form.fileData)     return toast.error('Please select a file');
    setUploading(true);
    try {
      await api.post(`/employees/${employeeId}/documents`, form);
      toast.success('Document uploaded');
      setModalOpen(false);
      setForm({ name: '', category: 'Contract', expiryDate: '', notes: '', fileData: null, fileType: '', fileSize: 0 });
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Upload failed'); }
    finally { setUploading(false); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/employees/${employeeId}/documents/${deleteId}`); toast.success('Document deleted'); load(); }
    catch { toast.error('Delete failed'); }
  };

  const handleDownload = async (doc) => {
    try {
      const { data } = await api.get(`/employees/${employeeId}/documents/${doc.id}/download`);
      if (data.fileData) {
        const a = document.createElement('a');
        a.href = data.fileData;
        a.download = data.name;
        a.click();
      }
    } catch { toast.error('Download failed'); }
  };

  const handlePreview = async (doc) => {
    try {
      const { data } = await api.get(`/employees/${employeeId}/documents/${doc.id}/download`);
      setPreviewDoc(data);
    } catch { toast.error('Preview failed'); }
  };

  const filtered = filterCat ? docs.filter(d => d.category === filterCat) : docs;

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-yellow-500" /> Files & Documents
          <span className="badge-blue">{docs.length}</span>
        </h3>
        <div className="flex items-center gap-2">
          <select className="form-select text-sm w-36" value={filterCat} onChange={e => setFilterCat(e.target.value)}>
            <option value="">All Categories</option>
            {CATEGORIES.map(c => <option key={c}>{c}</option>)}
          </select>
          {canEdit && (
            <>
              <input ref={inputRef} type="file" className="hidden" onChange={handleFileInput} />
              <button onClick={() => inputRef.current.click()} className="btn-primary">
                <Upload className="w-4 h-4" /> Upload
              </button>
            </>
          )}
        </div>
      </div>

      {/* Drop zone */}
      {canEdit && (
        <div
          ref={dropRef}
          onDragOver={e => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => inputRef.current.click()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 mb-5 text-center cursor-pointer hover:border-brand-400 dark:hover:border-brand-500 hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-all">
          <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-500 dark:text-gray-400">Drag & drop files here, or click to browse</p>
          <p className="text-xs text-gray-400 mt-1">PDF, images, documents — max {MAX_SIZE_MB}MB each</p>
        </div>
      )}

      {filtered.length === 0 ? (
        <EmptyState icon={FolderOpen} title="No documents" message="No files uploaded yet." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filtered.map(doc => {
            const Icon = getIcon(doc.fileType);
            const iconColor = getIconColor(doc.fileType);
            const isExpired = doc.expiryDate && new Date(doc.expiryDate) < new Date();
            return (
              <div key={doc.id} className={`flex items-start gap-3 p-4 border rounded-xl hover:shadow-sm transition-all cursor-pointer ${isExpired ? 'border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-900/10' : 'border-gray-100 dark:border-gray-700 hover:border-brand-200 dark:hover:border-brand-700'}`}
                onClick={() => handlePreview(doc)}>
                <div className={`w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0 ${iconColor}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-gray-900 dark:text-white truncate">{doc.name}</div>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className="text-xs text-gray-400">{doc.category}</span>
                    <span className="text-xs text-gray-400">·</span>
                    <span className="text-xs text-gray-400">{fmtSize(doc.fileSize)}</span>
                    {doc.expiryDate && (
                      <span className={`text-xs flex items-center gap-0.5 ${isExpired ? 'text-red-600 dark:text-red-400 font-medium' : 'text-gray-400'}`}>
                        {isExpired && <AlertCircle className="w-3 h-3" />}
                        {isExpired ? 'Expired' : 'Expires'} {format(new Date(doc.expiryDate), 'dd MMM yyyy')}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">{format(new Date(doc.createdAt), 'dd MMM yyyy')}</div>
                </div>
                <div className="flex gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                  <button onClick={() => handleDownload(doc)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600" title="Download">
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  {canEdit && (
                    <button onClick={() => setDeleteId(doc.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600" title="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Modal */}
      <Modal open={modalOpen} onClose={() => { setModalOpen(false); setForm({ name: '', category: 'Contract', expiryDate: '', notes: '', fileData: null, fileType: '', fileSize: 0 }); }} title="Upload Document" size="sm">
        <div className="space-y-4">
          {form.fileData && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <File className="w-8 h-8 text-brand-500 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{form.name}</p>
                <p className="text-xs text-gray-400">{form.fileType} · {fmtSize(form.fileSize)}</p>
              </div>
            </div>
          )}
          <div><label className="form-label">Document Name *</label><input className="form-input" placeholder="e.g. Employment Contract 2024" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
          <div><label className="form-label">Category</label>
            <select className="form-select" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div><label className="form-label">Expiry Date (optional)</label><input className="form-input" type="date" value={form.expiryDate} onChange={e => setForm(f => ({ ...f, expiryDate: e.target.value }))} /></div>
          <div><label className="form-label">Notes</label><textarea className="form-input h-16 resize-none" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
        </div>
        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} disabled={uploading} className="btn-primary">
            <Upload className="w-4 h-4" /> {uploading ? 'Uploading...' : 'Upload'}
          </button>
        </div>
      </Modal>

      {/* Preview Modal */}
      <Modal open={!!previewDoc} onClose={() => setPreviewDoc(null)} title={previewDoc?.name || 'Preview'} size="lg">
        {previewDoc && (
          <div>
            {previewDoc.fileData && previewDoc.fileType?.startsWith('image/') ? (
              <img src={previewDoc.fileData} alt={previewDoc.name} className="w-full rounded-lg max-h-96 object-contain bg-gray-100 dark:bg-gray-800" />
            ) : previewDoc.fileData && previewDoc.fileType === 'application/pdf' ? (
              <iframe src={previewDoc.fileData} className="w-full h-96 rounded-lg border border-gray-200 dark:border-gray-600" title={previewDoc.name} />
            ) : (
              <div className="text-center py-8 text-gray-400">
                <File className="w-16 h-16 mx-auto mb-3" />
                <p className="text-sm">Preview not available for this file type.</p>
              </div>
            )}
            <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
              <button onClick={() => handleDownload(previewDoc)} className="btn-primary"><Download className="w-4 h-4" /> Download</button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Document" message="Permanently delete this document? This cannot be undone." danger />
    </div>
  );
}
