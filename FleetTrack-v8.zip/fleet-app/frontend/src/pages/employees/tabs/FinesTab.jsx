import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, AlertCircle, CheckCircle, Clock, DollarSign, XCircle } from 'lucide-react';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, StatCard } from '../../../components/ui';
import { useToast } from '../../../context/ToastContext';
import api from '../../../utils/api';
import { format } from 'date-fns';

const STATUS_CONFIG = {
  pending:   { label: 'Pending',   badge: 'badge-yellow', icon: Clock },
  approved:  { label: 'Approved',  badge: 'badge-blue',   icon: CheckCircle },
  deducted:  { label: 'Deducted',  badge: 'badge-red',    icon: DollarSign },
  cancelled: { label: 'Cancelled', badge: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', icon: XCircle },
};

const DEDUCTION_TYPES = [
  { value: 'once',     label: 'One-time deduction' },
  { value: 'monthly',  label: 'Monthly deduction' },
  { value: 'weekly',   label: 'Weekly deduction' },
];

const FINE_REASONS = [
  'Late Arrival','Early Departure','Absence Without Notice','Policy Violation',
  'Damage to Property','Safety Breach','Misconduct','Performance Issue','Other'
];

const EMPTY_F = {
  title: '', reason: '', amount: '', deductionType: 'once',
  deductionDate: format(new Date(), 'yyyy-MM-dd'),
  status: 'pending', issuedBy: '', approvedBy: '', notes: '', relatedWarning: '',
};

export default function FinesTab({ employeeId, canEdit, canSeeSalary }) {
  const [fines, setFines]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing]   = useState(null);
  const [form, setForm]         = useState(EMPTY_F);
  const [deleteId, setDeleteId] = useState(null);
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${employeeId}/fines`);
      setFines(data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [employeeId]);

  const openNew  = () => { setForm(EMPTY_F); setEditing(null); setModalOpen(true); };
  const openEdit = (fine) => {
    setEditing(fine);
    setForm({ ...fine, deductionDate: fine.deductionDate ? format(new Date(fine.deductionDate), 'yyyy-MM-dd') : '' });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim()) return toast.error('Title is required');
    if (!form.amount || parseFloat(form.amount) <= 0) return toast.error('Amount must be greater than 0');
    try {
      if (editing) { await api.put(`/employees/${employeeId}/fines/${editing.id}`, form); toast.success('Fine updated'); }
      else         { await api.post(`/employees/${employeeId}/fines`, form);               toast.success('Fine issued'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/employees/${employeeId}/fines/${deleteId}`); toast.success('Fine deleted'); load(); }
    catch { toast.error('Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const fmt = (n) => `€${parseFloat(n || 0).toLocaleString('de-DE', { minimumFractionDigits: 2 })}`;

  const totalPending  = fines.filter(f => f.status === 'pending').reduce((s, f) => s + f.amount, 0);
  const totalDeducted = fines.filter(f => f.status === 'deducted').reduce((s, f) => s + f.amount, 0);
  const totalAll      = fines.reduce((s, f) => s + f.amount, 0);

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-500" /> Fines & Salary Deductions
          {fines.length > 0 && <span className="badge-red">{fines.length}</span>}
        </h3>
        {canEdit && (
          <button onClick={openNew} className="btn-danger">
            <Plus className="w-4 h-4" /> Issue Fine
          </button>
        )}
      </div>

      {/* Summary */}
      {fines.length > 0 && (
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="card p-4 text-center border-yellow-200 dark:border-yellow-800">
            <div className="text-lg font-bold text-yellow-600 dark:text-yellow-400">{fmt(totalPending)}</div>
            <div className="text-xs text-gray-500 mt-0.5">Pending Deduction</div>
          </div>
          <div className="card p-4 text-center border-red-200 dark:border-red-800">
            <div className="text-lg font-bold text-red-600 dark:text-red-400">{fmt(totalDeducted)}</div>
            <div className="text-xs text-gray-500 mt-0.5">Total Deducted</div>
          </div>
          <div className="card p-4 text-center">
            <div className="text-lg font-bold text-gray-900 dark:text-white">{fmt(totalAll)}</div>
            <div className="text-xs text-gray-500 mt-0.5">Total Fines</div>
          </div>
        </div>
      )}

      {fines.length === 0 ? (
        <EmptyState icon={AlertCircle} title="No fines" message="No salary deductions issued for this employee."
          action={canEdit && <button onClick={openNew} className="btn-danger"><Plus className="w-4 h-4" /> Issue Fine</button>} />
      ) : (
        <div className="space-y-3">
          {fines.map(fine => {
            const cfg = STATUS_CONFIG[fine.status] || STATUS_CONFIG.pending;
            const StatusIcon = cfg.icon;
            return (
              <div key={fine.id} className={`border rounded-xl p-4 transition-shadow hover:shadow-sm ${fine.status === 'deducted' ? 'border-red-200 dark:border-red-800 bg-red-50/30 dark:bg-red-900/10' : fine.status === 'cancelled' ? 'border-gray-200 dark:border-gray-700 opacity-60' : 'border-gray-100 dark:border-gray-700'}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${fine.status === 'deducted' ? 'bg-red-100 dark:bg-red-900/30' : 'bg-orange-100 dark:bg-orange-900/30'}`}>
                      <StatusIcon className={`w-5 h-5 ${fine.status === 'deducted' ? 'text-red-600 dark:text-red-400' : 'text-orange-600 dark:text-orange-400'}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm text-gray-900 dark:text-white">{fine.title}</span>
                        <span className={cfg.badge}>{cfg.label}</span>
                        <span className="text-sm font-bold text-red-600 dark:text-red-400">{fmt(fine.amount)}</span>
                        <span className="badge-blue text-xs">{DEDUCTION_TYPES.find(d => d.value === fine.deductionType)?.label}</span>
                      </div>
                      {fine.reason && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Reason: {fine.reason}</p>}
                      <div className="flex items-center gap-4 mt-1.5 text-xs text-gray-400 flex-wrap">
                        {fine.deductionDate && <span>Deduction date: {format(new Date(fine.deductionDate), 'dd MMM yyyy')}</span>}
                        {fine.issuedBy && <span>Issued by: {fine.issuedBy}</span>}
                        {fine.approvedBy && <span>Approved by: {fine.approvedBy}</span>}
                      </div>
                      {fine.relatedWarning && (
                        <div className="mt-1.5 text-xs text-orange-600 dark:text-orange-400">
                          Related to: {fine.relatedWarning}
                        </div>
                      )}
                      {fine.notes && (
                        <p className="mt-1.5 text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 rounded px-2 py-1">{fine.notes}</p>
                      )}
                    </div>
                  </div>
                  {canEdit && (
                    <div className="flex gap-1 flex-shrink-0">
                      <button onClick={() => openEdit(fine)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>
                      <button onClick={() => setDeleteId(fine.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Issue Fine Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Fine' : 'Issue Fine / Salary Deduction'} size="md">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="form-label">Title *</label>
            <input className="form-input" placeholder="e.g. Late Arrival Fine" {...f('title')} />
          </div>
          <div>
            <label className="form-label">Reason</label>
            <select className="form-select" {...f('reason')}>
              <option value="">Select reason...</option>
              {FINE_REASONS.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Amount (€) *</label>
            <input className="form-input" type="number" step="0.01" placeholder="0.00" {...f('amount')} />
          </div>
          <div>
            <label className="form-label">Deduction Type</label>
            <select className="form-select" {...f('deductionType')}>
              {DEDUCTION_TYPES.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Deduction Date</label>
            <input className="form-input" type="date" {...f('deductionDate')} />
          </div>
          <div>
            <label className="form-label">Status</label>
            <select className="form-select" {...f('status')}>
              {Object.entries(STATUS_CONFIG).map(([v, cfg]) => <option key={v} value={v}>{cfg.label}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Issued By</label>
            <input className="form-input" placeholder="Manager name" {...f('issuedBy')} />
          </div>
          <div>
            <label className="form-label">Approved By</label>
            <input className="form-input" placeholder="Approver name" {...f('approvedBy')} />
          </div>
          <div className="col-span-2">
            <label className="form-label">Related Warning / Incident</label>
            <input className="form-input" placeholder="Reference to warning or incident" {...f('relatedWarning')} />
          </div>
          <div className="col-span-2">
            <label className="form-label">Notes</label>
            <textarea className="form-input h-16 resize-none" placeholder="Additional notes..." {...f('notes')} />
          </div>

          {/* Warning banner */}
          <div className="col-span-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-3 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-red-700 dark:text-red-300">
              Issuing a fine will create a salary deduction record. Ensure this has been authorised by the appropriate manager before marking as <strong>Approved</strong> or <strong>Deducted</strong>.
            </p>
          </div>
        </div>

        <div className="flex gap-3 justify-end mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-danger">
            <AlertCircle className="w-4 h-4" /> {editing ? 'Save Changes' : 'Issue Fine'}
          </button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Fine" message="Permanently delete this fine record? This cannot be undone." danger />
    </div>
  );
}
