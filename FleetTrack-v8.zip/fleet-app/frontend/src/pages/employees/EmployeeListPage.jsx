import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus, Search, Filter, Users, Eye, Edit2, Trash2,
  Archive, ArchiveRestore, Download, UserCheck, UserX, Clock, Briefcase
} from 'lucide-react';
import api from '../../utils/api';
import { ConfirmDialog, LoadingSpinner, EmptyState, PageHeader, StatCard } from '../../components/ui';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { format } from 'date-fns';
import EmployeeModal from './EmployeeModal';

const STATUS_COLORS = {
  active:     'badge-green',
  suspended:  'badge-yellow',
  on_leave:   'badge-blue',
  terminated: 'badge-red',
};
const STATUS_LABELS = {
  active: 'Active', suspended: 'Suspended', on_leave: 'On Leave', terminated: 'Terminated'
};
const TYPE_LABELS = {
  full_time: 'Full Time', part_time: 'Part Time', contract: 'Contract', internship: 'Internship'
};

export default function EmployeeListPage() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [filterStatus, setFilterStatus]   = useState('');
  const [filterDept, setFilterDept]       = useState('');
  const [filterType, setFilterType]       = useState('');
  const [showArchived, setShowArchived]   = useState(false);
  const [showFilters, setShowFilters]     = useState(false);
  const [modalOpen, setModalOpen]         = useState(false);
  const [editing, setEditing]             = useState(null);
  const [deleteId, setDeleteId]           = useState(null);
  const [archiveTarget, setArchiveTarget] = useState(null);
  const [page, setPage]                   = useState(1);
  const PER_PAGE = 15;
  const { user, isAdmin } = useAuth();
  const toast = useToast();

  const canEdit = ['admin','manager','coordinator'].includes(user?.role);

  const load = async () => {
    setLoading(true);
    try {
      const params = { archived: showArchived };
      if (search)       params.search = search;
      if (filterStatus) params.status = filterStatus;
      if (filterDept)   params.department = filterDept;
      if (filterType)   params.type = filterType;
      const { data } = await api.get('/employees', { params });
      setEmployees(data);
      setPage(1);
    } catch (err) {
      toast.error('Failed to load employees');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [search, filterStatus, filterDept, filterType, showArchived]);

  const openNew  = () => { setEditing(null); setModalOpen(true); };
  const openEdit = (emp) => { setEditing(emp); setModalOpen(true); };

  const handleSaved = () => { setModalOpen(false); load(); };

  const handleArchive = async () => {
    try {
      const { data } = await api.put(`/employees/${archiveTarget.id}/archive`);
      toast.success(data.archived ? 'Employee archived' : 'Employee restored');
      load();
    } catch (err) { toast.error('Failed'); }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/employees/${deleteId}`);
      toast.success('Employee deleted');
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  // Stats
  const active     = employees.filter(e => e.employmentStatus === 'active').length;
  const onLeave    = employees.filter(e => e.employmentStatus === 'on_leave').length;
  const terminated = employees.filter(e => e.employmentStatus === 'terminated').length;
  const fullTime   = employees.filter(e => e.employmentType === 'full_time').length;

  // Pagination
  const totalPages = Math.ceil(employees.length / PER_PAGE);
  const paged      = employees.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Employees"
        subtitle={`${employees.length} employee${employees.length !== 1 ? 's' : ''}`}
        actions={
          <div className="flex items-center gap-2">
            <button onClick={() => setShowFilters(f => !f)} className="btn-secondary">
              <Filter className="w-4 h-4" /> Filters
            </button>
            {canEdit && (
              <button onClick={openNew} className="btn-primary">
                <Plus className="w-4 h-4" /> Add Employee
              </button>
            )}
          </div>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total"      value={employees.length} icon={Users}     color="blue" />
        <StatCard label="Active"     value={active}           icon={UserCheck}  color="green" />
        <StatCard label="On Leave"   value={onLeave}          icon={Clock}      color="orange" />
        <StatCard label="Full Time"  value={fullTime}         icon={Briefcase}  color="purple" />
      </div>

      {/* Search + Filters */}
      <div className="card p-4 mb-4 space-y-3">
        <div className="flex gap-3 flex-wrap items-center">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input className="form-input pl-9 w-full" placeholder="Search by name, ID, email, role..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
            <input type="checkbox" checked={showArchived} onChange={e => setShowArchived(e.target.checked)} className="rounded" />
            Show Archived
          </label>
        </div>

        {showFilters && (
          <div className="flex gap-3 flex-wrap pt-2 border-t border-gray-100 dark:border-gray-700">
            <select className="form-select w-44" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="">All Statuses</option>
              {Object.entries(STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
            <select className="form-select w-44" value={filterType} onChange={e => setFilterType(e.target.value)}>
              <option value="">All Types</option>
              {Object.entries(TYPE_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
            <select className="form-select w-44" value={filterDept} onChange={e => setFilterDept(e.target.value)}>
              <option value="">All Departments</option>
              {departments.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            <button onClick={() => { setFilterStatus(''); setFilterType(''); setFilterDept(''); setSearch(''); }}
              className="btn-secondary text-xs">Clear</button>
          </div>
        )}
      </div>

      {loading ? <LoadingSpinner /> : employees.length === 0 ? (
        <EmptyState icon={Users} title="No employees found" message="Add your first employee to get started."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Employee</button>} />
      ) : (
        <>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                    {['Employee','ID','Department','Role','Type','Status','Hire Date',''].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                  {paged.map((emp, i) => (
                    <tr key={emp.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''} ${emp.archived ? 'opacity-60' : ''}`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full overflow-hidden bg-brand-100 dark:bg-brand-900/50 flex-shrink-0 flex items-center justify-center">
                            {emp.profilePhoto
                              ? <img src={emp.profilePhoto} alt="" className="w-full h-full object-cover" />
                              : <span className="text-sm font-bold text-brand-700 dark:text-brand-400">{emp.firstName[0]}{emp.lastName[0]}</span>
                            }
                          </div>
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">{emp.firstName} {emp.lastName}</div>
                            <div className="text-xs text-gray-400">{emp.email || '—'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs font-medium text-brand-700 dark:text-brand-400">{emp.employeeId}</td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{emp.department || '—'}</td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{emp.role || '—'}</td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{TYPE_LABELS[emp.employmentType] || emp.employmentType}</td>
                      <td className="px-4 py-3">
                        <span className={STATUS_COLORS[emp.employmentStatus] || 'badge-blue'}>
                          {STATUS_LABELS[emp.employmentStatus] || emp.employmentStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">
                        {emp.hireDate ? format(new Date(emp.hireDate), 'dd MMM yyyy') : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <Link to={`/employees/${emp.id}`} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg text-gray-500 hover:text-gray-700 transition-colors" title="View Profile">
                            <Eye className="w-4 h-4" />
                          </Link>
                          {canEdit && (
                            <button onClick={() => openEdit(emp)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors" title="Edit">
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}
                          {canEdit && (
                            <button onClick={() => setArchiveTarget(emp)} className="p-1.5 hover:bg-yellow-50 dark:hover:bg-yellow-900/30 rounded-lg text-gray-500 hover:text-yellow-600 transition-colors" title={emp.archived ? 'Restore' : 'Archive'}>
                              {emp.archived ? <ArchiveRestore className="w-4 h-4" /> : <Archive className="w-4 h-4" />}
                            </button>
                          )}
                          {isAdmin && (
                            <button onClick={() => setDeleteId(emp.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors" title="Delete">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Showing {((page-1)*PER_PAGE)+1}–{Math.min(page*PER_PAGE, employees.length)} of {employees.length}
              </p>
              <div className="flex gap-1">
                <button onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1} className="btn-secondary py-1 px-2 disabled:opacity-40">←</button>
                {Array.from({length: Math.min(5, totalPages)}, (_, i) => {
                  const pg = page <= 3 ? i+1 : page-2+i;
                  if (pg > totalPages) return null;
                  return <button key={pg} onClick={() => setPage(pg)}
                    className={`w-8 h-8 text-sm rounded-lg font-medium ${pg===page ? 'bg-brand-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400'}`}>{pg}</button>;
                })}
                <button onClick={() => setPage(p => Math.min(totalPages,p+1))} disabled={page===totalPages} className="btn-secondary py-1 px-2 disabled:opacity-40">→</button>
              </div>
            </div>
          )}
        </>
      )}

      <EmployeeModal open={modalOpen} onClose={() => setModalOpen(false)} employee={editing} onSaved={handleSaved} />

      <ConfirmDialog open={!!archiveTarget} onClose={() => setArchiveTarget(null)} onConfirm={handleArchive}
        title={archiveTarget?.archived ? 'Restore Employee' : 'Archive Employee'}
        message={archiveTarget?.archived
          ? `Restore ${archiveTarget?.firstName} ${archiveTarget?.lastName}?`
          : `Archive ${archiveTarget?.firstName} ${archiveTarget?.lastName}? They will be hidden from active lists.`}
        danger={!archiveTarget?.archived} />

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Employee" message="This permanently deletes the employee and all their records." danger />
    </div>
  );
}
