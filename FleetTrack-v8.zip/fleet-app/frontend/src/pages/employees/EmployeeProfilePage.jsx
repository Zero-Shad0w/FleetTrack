import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, User, AlertTriangle, Wrench, MessageSquare,
  FolderOpen, Edit2, Calendar, Phone, Mail, MapPin,
  Briefcase, Users, Shield, Clock, DollarSign
} from 'lucide-react';
import api from '../../utils/api';
import { LoadingSpinner } from '../../components/ui';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { format } from 'date-fns';
import EmployeeModal from './EmployeeModal';
import WarningsTab from './tabs/WarningsTab';
import AttendanceTab from './tabs/AttendanceTab';
import FinesTab from './tabs/FinesTab';
import ToolsTab from './tabs/ToolsTab';
import ComplaintsTab from './tabs/ComplaintsTab';
import DocumentsTab from './tabs/DocumentsTab';

const STATUS_COLORS = {
  active: 'badge-green', suspended: 'badge-yellow', on_leave: 'badge-blue', terminated: 'badge-red'
};
const STATUS_LABELS = {
  active: 'Active', suspended: 'Suspended', on_leave: 'On Leave', terminated: 'Terminated'
};
const TYPE_LABELS = {
  full_time: 'Full Time', part_time: 'Part Time', contract: 'Contract', internship: 'Internship'
};

const TABS = [
  { key: 'info',       label: 'General Info',  icon: User },
  { key: 'warnings',   label: 'Warnings',      icon: AlertTriangle },
  { key: 'tools',      label: 'Tools',         icon: Wrench },
  { key: 'complaints', label: 'Complaints',    icon: MessageSquare },
  { key: 'documents',  label: 'Documents',     icon: FolderOpen },
  { key: 'attendance',  label: 'Attendance',    icon: Calendar },
  { key: 'fines',       label: 'Fines',         icon: DollarSign },
];

export default function EmployeeProfilePage() {
  const { id }            = useParams();
  const navigate          = useNavigate();
  const [emp, setEmp]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('info');
  const [editOpen, setEditOpen]   = useState(false);
  const { user, isAdmin } = useAuth();
  const toast = useToast();

  const canEdit    = ['admin','manager','coordinator'].includes(user?.role);
  const canWarning = ['admin','manager','coordinator'].includes(user?.role);
  const canSalary  = ['admin','manager'].includes(user?.role);
  const canComplaints = ['admin','manager','coordinator'].includes(user?.role);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/employees/${id}`);
      setEmp(data);
    } catch (err) {
      toast.error('Employee not found');
      navigate('/employees');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [id]);

  const handleSaved = () => { setEditOpen(false); load(); };

  // Filter tabs based on permissions
  const visibleTabs = TABS.filter(t => {
    if (t.key === 'warnings'   && !canWarning)    return false;
    if (t.key === 'complaints' && !canComplaints) return false;
    return true;
  });

  if (loading) return <div className="p-6"><LoadingSpinner message="Loading employee profile..." /></div>;
  if (!emp) return null;

  const completionFields = ['profilePhoto','phone','email','address','dateOfBirth','personalNumber','emergencyContact','hireDate','department','role'];
  const completion = Math.round((completionFields.filter(f => emp[f]).length / completionFields.length) * 100);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Back */}
      <Link to="/employees" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 mb-5 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Employees
      </Link>

      {/* Profile Header */}
      <div className="card overflow-hidden mb-6">
        <div className="bg-gradient-to-r from-brand-600 to-brand-700 px-6 py-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl overflow-hidden bg-white/20 border-2 border-white/30 flex-shrink-0 flex items-center justify-center">
                {emp.profilePhoto
                  ? <img src={emp.profilePhoto} alt="" className="w-full h-full object-cover" />
                  : <span className="text-2xl font-bold text-white">{emp.firstName[0]}{emp.lastName[0]}</span>
                }
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">{emp.firstName} {emp.lastName}</h1>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <span className="text-brand-200 text-sm font-mono">{emp.employeeId}</span>
                  {emp.role && <span className="text-brand-200 text-sm">· {emp.role}</span>}
                  {emp.department && <span className="text-brand-200 text-sm">· {emp.department}</span>}
                </div>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <span className={`${STATUS_COLORS[emp.employmentStatus]} text-xs`}>
                    {STATUS_LABELS[emp.employmentStatus]}
                  </span>
                  <span className="badge-blue text-xs">{TYPE_LABELS[emp.employmentType]}</span>
                  {emp.archived && <span className="badge-red text-xs">Archived</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {/* Profile completion */}
              <div className="hidden sm:flex flex-col items-center bg-white/10 rounded-xl px-4 py-2">
                <span className="text-white text-lg font-bold">{completion}%</span>
                <span className="text-brand-200 text-xs">Complete</span>
                <div className="w-16 h-1.5 bg-white/20 rounded-full mt-1">
                  <div className="h-full bg-white rounded-full" style={{ width: `${completion}%` }} />
                </div>
              </div>
              {canEdit && (
                <button onClick={() => setEditOpen(true)} className="flex items-center gap-2 px-3 py-2 bg-white/20 hover:bg-white/30 text-white text-sm font-medium rounded-lg transition-colors">
                  <Edit2 className="w-4 h-4" /> Edit
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Quick info strip */}
        <div className="px-6 py-3 border-b border-gray-100 dark:border-gray-700 flex flex-wrap gap-x-6 gap-y-1">
          {emp.email && <InfoChip icon={Mail} text={emp.email} />}
          {emp.phone && <InfoChip icon={Phone} text={emp.phone} />}
          {emp.city  && <InfoChip icon={MapPin} text={[emp.city, emp.country].filter(Boolean).join(', ')} />}
          {emp.hireDate && <InfoChip icon={Calendar} text={`Hired ${format(new Date(emp.hireDate), 'dd MMM yyyy')}`} />}
          {emp.manager && <InfoChip icon={Users} text={`Reports to ${emp.manager}`} />}
        </div>

        {/* Tabs */}
        <div className="flex overflow-x-auto border-b border-gray-100 dark:border-gray-700 px-4">
          {visibleTabs.map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setActiveTab(key)}
              className={`flex items-center gap-2 px-4 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition-all -mb-px ${
                activeTab === key
                  ? 'border-brand-600 text-brand-700 dark:text-brand-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}>
              <Icon className="w-4 h-4" /> {label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'info' && <GeneralInfoTab emp={emp} canSalary={canSalary} />}
          {activeTab === 'warnings'   && <WarningsTab   employeeId={id} canEdit={canWarning} />}
          {activeTab === 'tools'      && <ToolsTab      employeeId={id} canEdit={canEdit} />}
          {activeTab === 'complaints' && <ComplaintsTab employeeId={id} canEdit={canComplaints} />}
          {activeTab === 'documents'  && <DocumentsTab  employeeId={id} canEdit={canEdit} />}
          {activeTab === 'attendance'  && <AttendanceTab employeeId={id} canEdit={canEdit} />}
          {activeTab === 'fines'       && <FinesTab      employeeId={id} canEdit={canEdit} canSeeSalary={canSalary} />}
        </div>
      </div>

      <EmployeeModal open={editOpen} onClose={() => setEditOpen(false)} employee={emp} onSaved={handleSaved} />
    </div>
  );
}

function InfoChip({ icon: Icon, text }) {
  return (
    <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 py-1">
      <Icon className="w-3.5 h-3.5" /> {text}
    </div>
  );
}

function GeneralInfoTab({ emp, canSalary }) {
  const sections = [
    {
      title: 'Personal Information',
      fields: [
        ['First Name', emp.firstName], ['Last Name', emp.lastName],
        ['Gender', emp.gender], ['Date of Birth', emp.dateOfBirth ? format(new Date(emp.dateOfBirth), 'dd MMM yyyy') : null],
        ['Personal / ID Number', emp.personalNumber],
      ]
    },
    {
      title: 'Work Information',
      fields: [
        ['Employee ID', emp.employeeId], ['Role / Position', emp.role],
        ['Department', emp.department], ['Manager', emp.manager],
        ['Employment Status', emp.employmentStatus], ['Employment Type', emp.employmentType],
        ['Hire Date', emp.hireDate ? format(new Date(emp.hireDate), 'dd MMM yyyy') : null],
        ...(canSalary ? [['Salary', emp.salary ? `€${parseFloat(emp.salary).toLocaleString('de-DE', {minimumFractionDigits:2})}` : null]] : []),
      ]
    },
    {
      title: 'Contact Information',
      fields: [
        ['Phone', emp.phone], ['Email', emp.email],
        ['Address', emp.address], ['City', emp.city], ['Country', emp.country],
      ]
    },
    {
      title: 'Emergency Contact',
      fields: [
        ['Contact Name', emp.emergencyContact], ['Contact Phone', emp.emergencyPhone],
      ]
    },
  ];

  return (
    <div className="space-y-6">
      {sections.map(({ title, fields }) => (
        <div key={title}>
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <span className="w-1 h-4 bg-brand-500 rounded-full inline-block" />
            {title}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {fields.filter(([, v]) => v).map(([label, val]) => (
              <div key={label} className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-0.5">{label}</div>
                <div className="text-sm font-medium text-gray-900 dark:text-white">{val}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
      {emp.notes && (
        <div>
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <span className="w-1 h-4 bg-brand-500 rounded-full inline-block" /> Notes
          </h3>
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{emp.notes}</div>
        </div>
      )}
    </div>
  );
}
