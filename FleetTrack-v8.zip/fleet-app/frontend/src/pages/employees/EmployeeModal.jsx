import React, { useState, useEffect, useRef } from 'react';
import { Camera, Save } from 'lucide-react';
import { Modal } from '../../components/ui';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../utils/api';
import { format } from 'date-fns';

const toInput = (d) => d ? format(new Date(d), 'yyyy-MM-dd') : '';

const EMPTY = {
  employeeId: '', firstName: '', lastName: '', gender: '', dateOfBirth: '',
  personalNumber: '', phone: '', email: '', address: '', city: '', country: '',
  emergencyContact: '', emergencyPhone: '', role: '', department: '', manager: '',
  employmentStatus: 'active', employmentType: 'full_time', hireDate: '',
  salary: '', notes: '', profilePhoto: null,
};

const STATUSES   = ['active','suspended','on_leave','terminated'];
const TYPES      = ['full_time','part_time','contract','internship'];
const STATUS_LBL = { active:'Active', suspended:'Suspended', on_leave:'On Leave', terminated:'Terminated' };
const TYPE_LBL   = { full_time:'Full Time', part_time:'Part Time', contract:'Contract', internship:'Internship' };

export default function EmployeeModal({ open, onClose, employee, onSaved }) {
  const [form, setForm]   = useState(EMPTY);
  const [tab, setTab]     = useState('personal');
  const [saving, setSaving] = useState(false);
  const photoRef = useRef();
  const toast    = useToast();
  const { user } = useAuth();
  const canSeeSalary = ['admin','manager'].includes(user?.role);

  useEffect(() => {
    if (employee) {
      setForm({
        ...EMPTY, ...employee,
        dateOfBirth: toInput(employee.dateOfBirth),
        hireDate:    toInput(employee.hireDate),
        salary:      employee.salary ?? '',
        profilePhoto: employee.profilePhoto || null,
      });
    } else {
      setForm(EMPTY);
    }
    setTab('personal');
  }, [employee, open]);

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setForm(p => ({ ...p, profilePhoto: ev.target.result }));
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSave = async () => {
    if (!form.employeeId.trim()) return toast.error('Employee ID is required');
    if (!form.firstName.trim())  return toast.error('First name is required');
    if (!form.lastName.trim())   return toast.error('Last name is required');
    setSaving(true);
    try {
      if (employee) {
        await api.put(`/employees/${employee.id}`, form);
        toast.success('Employee updated');
      } else {
        await api.post('/employees', form);
        toast.success('Employee added');
      }
      onSaved();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Save failed');
    } finally { setSaving(false); }
  };

  const TABS = [
    { key: 'personal', label: 'Personal' },
    { key: 'work',     label: 'Work' },
    { key: 'contact',  label: 'Contact' },
    { key: 'notes',    label: 'Notes' },
  ];

  return (
    <Modal open={open} onClose={onClose} title={employee ? `Edit — ${employee.firstName} ${employee.lastName}` : 'Add Employee'} size="lg">
      {/* Photo + Tabs */}
      <div className="flex items-start gap-5 mb-5">
        {/* Profile photo */}
        <div className="flex-shrink-0">
          <div className="relative w-20 h-20 rounded-2xl overflow-hidden bg-gray-100 dark:bg-gray-700 border-2 border-gray-200 dark:border-gray-600 cursor-pointer group"
            onClick={() => photoRef.current.click()}>
            {form.profilePhoto
              ? <img src={form.profilePhoto} alt="" className="w-full h-full object-cover" />
              : <div className="w-full h-full flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-400">
                    {form.firstName?.[0]}{form.lastName?.[0]}
                  </span>
                </div>
            }
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
          </div>
          <input ref={photoRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
          <p className="text-xs text-gray-400 text-center mt-1">Photo</p>
        </div>

        {/* Tab switcher */}
        <div className="flex-1">
          <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl w-fit mb-4">
            {TABS.map(t => (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${tab === t.key ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Personal Tab */}
          {tab === 'personal' && (
            <div className="grid grid-cols-2 gap-3">
              <FG label="Employee ID *"><input className="form-input" placeholder="EMP-001" {...f('employeeId')} /></FG>
              <FG label="Gender">
                <select className="form-select" {...f('gender')}>
                  <option value="">Select...</option>
                  {['Male','Female','Other','Prefer not to say'].map(g => <option key={g}>{g}</option>)}
                </select>
              </FG>
              <FG label="First Name *"><input className="form-input" placeholder="John" {...f('firstName')} /></FG>
              <FG label="Last Name *"><input className="form-input" placeholder="Smith" {...f('lastName')} /></FG>
              <FG label="Date of Birth"><input className="form-input" type="date" {...f('dateOfBirth')} /></FG>
              <FG label="ID / Personal Number"><input className="form-input" placeholder="ID number" {...f('personalNumber')} /></FG>
            </div>
          )}

          {/* Work Tab */}
          {tab === 'work' && (
            <div className="grid grid-cols-2 gap-3">
              <FG label="Role / Position"><input className="form-input" placeholder="Inspector" {...f('role')} /></FG>
              <FG label="Department"><input className="form-input" placeholder="Operations" {...f('department')} /></FG>
              <FG label="Manager / Supervisor"><input className="form-input" placeholder="Manager name" {...f('manager')} /></FG>
              <FG label="Hire Date"><input className="form-input" type="date" {...f('hireDate')} /></FG>
              <FG label="Status">
                <select className="form-select" {...f('employmentStatus')}>
                  {STATUSES.map(s => <option key={s} value={s}>{STATUS_LBL[s]}</option>)}
                </select>
              </FG>
              <FG label="Type">
                <select className="form-select" {...f('employmentType')}>
                  {TYPES.map(t => <option key={t} value={t}>{TYPE_LBL[t]}</option>)}
                </select>
              </FG>
              {canSeeSalary && (
                <FG label="Salary (€)" className="col-span-2">
                  <input className="form-input" type="number" placeholder="0.00" {...f('salary')} />
                </FG>
              )}
            </div>
          )}

          {/* Contact Tab */}
          {tab === 'contact' && (
            <div className="grid grid-cols-2 gap-3">
              <FG label="Phone"><input className="form-input" placeholder="+1 234 567 8900" {...f('phone')} /></FG>
              <FG label="Email"><input className="form-input" type="email" placeholder="john@company.com" {...f('email')} /></FG>
              <FG label="Address" className="col-span-2"><input className="form-input" placeholder="Street address" {...f('address')} /></FG>
              <FG label="City"><input className="form-input" placeholder="City" {...f('city')} /></FG>
              <FG label="Country"><input className="form-input" placeholder="Country" {...f('country')} /></FG>
              <FG label="Emergency Contact"><input className="form-input" placeholder="Contact name" {...f('emergencyContact')} /></FG>
              <FG label="Emergency Phone"><input className="form-input" placeholder="+1 234 567 8900" {...f('emergencyPhone')} /></FG>
            </div>
          )}

          {/* Notes Tab */}
          {tab === 'notes' && (
            <FG label="Notes">
              <textarea className="form-input h-32 resize-none" placeholder="Additional notes about this employee..." {...f('notes')} />
            </FG>
          )}
        </div>
      </div>

      <div className="flex gap-3 justify-end pt-4 border-t border-gray-100 dark:border-gray-700">
        <button onClick={onClose} className="btn-secondary">Cancel</button>
        <button onClick={handleSave} disabled={saving} className="btn-primary">
          <Save className="w-4 h-4" /> {saving ? 'Saving...' : employee ? 'Save Changes' : 'Add Employee'}
        </button>
      </div>
    </Modal>
  );
}

function FG({ label, children, className = '' }) {
  return (
    <div className={className}>
      <label className="form-label">{label}</label>
      {children}
    </div>
  );
}
