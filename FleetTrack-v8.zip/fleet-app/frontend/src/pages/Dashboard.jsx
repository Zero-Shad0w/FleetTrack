import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Truck, Wrench, DollarSign, TrendingUp, AlertTriangle, Calendar,
  ChevronRight, Users, UserCheck, Clock, UserX, MessageSquare,
  AlertCircle, Shield, Activity, User, Settings, Database,
  CheckCircle, XCircle, Eye, Briefcase, Gauge, Radio, ArrowUpRight
} from 'lucide-react';
import api from '../utils/api';
import { StatCard, LoadingSpinner } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useBranding } from '../context/BrandingContext';
import { format, isAfter } from 'date-fns';

const fmt = (n) => `€${(n||0).toLocaleString('de-DE',{minimumFractionDigits:2})}`;

// ── Role greeting ─────────────────────────────────────────────────────────────
function Greeting({ user, branding }) {
  const hour = new Date().getHours();
  const time = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const roleDesc = {
    admin:       'You have full system access.',
    inspector:   'Vehicle inspection dashboard.',
    coordinator: 'Employee management overview.',
    manager:     'Fleet & people overview.',
    viewer:      'Read-only system view.',
  };
  return (
    <div className="rounded-2xl overflow-hidden mb-6" style={{ background: `linear-gradient(135deg, ${branding.primaryColor||'#2563eb'}, ${branding.secondaryColor||'#1d4ed8'})` }}>
      <div className="px-6 py-5 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">{time}, {user?.username}!</h1>
          <p className="text-white/70 text-sm mt-0.5">{roleDesc[user?.role] || ''} · {format(new Date(), 'EEEE, dd MMMM yyyy')}</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2">
          <Shield className="w-4 h-4 text-white/80" />
          <span className="text-white text-sm font-medium capitalize">{user?.role}</span>
        </div>
      </div>
    </div>
  );
}

// ── Vehicle section ───────────────────────────────────────────────────────────
function VehicleSection({ data }) {
  return (
    <div className="space-y-5">
      <SectionTitle icon={Truck} label="Fleet Overview" to="/vehicles" />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Vehicles"    value={data.totalVehicles}              icon={Truck}       color="blue"   />
        <StatCard label="Total Repairs"     value={data.totalRepairs}               icon={Wrench}      color="orange" />
        <StatCard label="Total Repair Cost" value={fmt(data.totalRepairCost)}       icon={DollarSign}  color="green"  />
        <StatCard label="This Month"        value={fmt(data.monthlyRepairCost)}     icon={TrendingUp}  color="purple" sub={`${data.monthlyRepairCount} repairs`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Expiries */}
        <Card title="Upcoming Expiries" icon={AlertTriangle} iconColor="text-orange-500" to="/vehicles">
          {data.upcomingExpiries?.length === 0
            ? <Empty text="No upcoming expiries" />
            : data.upcomingExpiries?.map(v => {
                const items = [];
                if (v.insuranceExpiry)    items.push({ label: 'Insurance',    date: v.insuranceExpiry });
                if (v.registrationExpiry) items.push({ label: 'Registration', date: v.registrationExpiry });
                if (v.serviceDueDate)     items.push({ label: 'Service Due',  date: v.serviceDueDate });
                return items.map((item,i) => {
                  const d = new Date(item.date);
                  const overdue = isAfter(new Date(), d);
                  return (
                    <div key={`${v.id}-${i}`} className="flex items-center gap-3 py-2.5 border-b border-gray-50 dark:border-gray-700 last:border-0">
                      <div className={`w-2 h-2 rounded-full flex-shrink-0 ${overdue?'bg-red-500':'bg-orange-400'}`} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 dark:text-white truncate">{v.vehicleId} — {v.make} {v.model}</div>
                        <div className="text-xs text-gray-400">{item.label} · {format(d,'dd MMM yyyy')}</div>
                      </div>
                      <span className={overdue?'badge-red':'badge-yellow'}>{overdue?'Overdue':'Soon'}</span>
                    </div>
                  );
                });
              })
          }
        </Card>

        {/* Recent inspections */}
        <Card title="Recent Inspections" icon={Calendar} iconColor="text-brand-500" to="/weekly-logs">
          {data.recentLogs?.length === 0
            ? <Empty text="No inspections yet" />
            : data.recentLogs?.map(log => (
                <div key={log.id} className="flex items-center gap-3 py-2.5 border-b border-gray-50 dark:border-gray-700 last:border-0">
                  <div className="w-9 h-9 rounded-lg bg-brand-50 dark:bg-brand-900/30 flex items-center justify-center flex-shrink-0">
                    <Truck className="w-4 h-4 text-brand-600 dark:text-brand-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 dark:text-white truncate">{log.vehicle?.vehicleId} · {log.vehicle?.make} {log.vehicle?.model}</div>
                    <div className="text-xs text-gray-400">{log.employeeName} · {format(new Date(log.inspectionDate),'dd MMM yyyy')}</div>
                  </div>
                  <span className={log.equipmentComplete?'badge-green':'badge-red'}>{log.equipmentComplete?'Complete':'Incomplete'}</span>
                </div>
              ))
          }
        </Card>
      </div>

      {/* Recent damage */}
      {data.recentDamage?.length > 0 && (
        <div>
          <SectionTitle icon={Shield} label="Recent Damage Reports" to="/damage" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {data.recentDamage.map(insp => {
              const total = ['frontDamageMarkers','rearDamageMarkers','leftDamageMarkers','rightDamageMarkers','topDamageMarkers']
                .reduce((s,k) => { try { return s + JSON.parse(insp[k]||'[]').length; } catch { return s; } }, 0);
              return (
                <Link key={insp.id} to="/damage" className="card p-4 hover:shadow-md transition-shadow">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">{insp.vehicle?.vehicleId}</div>
                  <div className="text-xs text-gray-400 mt-0.5">{insp.vehicle?.make} {insp.vehicle?.model}</div>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-gray-500">{format(new Date(insp.inspectionDate),'dd MMM yyyy')}</span>
                    <span className={total>0?'badge-red':'badge-green'}>{total>0?`${total} markers`:'Clean'}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {to:'/vehicles',    icon:Truck,          label:'Add Vehicle',   color:'blue'},
          {to:'/repairs',     icon:Wrench,         label:'Log Repair',    color:'orange'},
          {to:'/damage',      icon:AlertTriangle,  label:'Damage Report', color:'red'},
          {to:'/weekly-logs', icon:Calendar,       label:'Weekly Log',    color:'green'},
        ].map(({to,icon:Icon,label,color})=>(
          <Link key={to} to={to} className="card p-4 hover:shadow-md transition-shadow flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${{blue:'bg-blue-50 text-blue-600',orange:'bg-orange-50 text-orange-600',red:'bg-red-50 text-red-600',green:'bg-green-50 text-green-600'}[color]}`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
            <ChevronRight className="w-4 h-4 text-gray-400 ml-auto" />
          </Link>
        ))}
      </div>
    </div>
  );
}

// ── Employee section ──────────────────────────────────────────────────────────
function EmployeeSection({ data }) {
  return (
    <div className="space-y-5">
      <SectionTitle icon={Users} label="People Overview" to="/employees" />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Employees" value={data.totalEmployees}  icon={Users}     color="blue" />
        <StatCard label="Active"          value={data.activeEmployees} icon={UserCheck} color="green" />
        <StatCard label="On Leave"        value={data.onLeave}         icon={Clock}     color="orange" />
        <StatCard label="Open Complaints" value={data.openComplaints}  icon={MessageSquare} color="red" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Today's attendance */}
        <Card title={`Today's Attendance · ${format(new Date(),'dd MMM yyyy')}`} icon={CheckCircle} iconColor="text-green-500" to="/employees">
          <div className="flex items-center gap-6 py-4 justify-center">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 dark:text-green-400">{data.todayPresent}</div>
              <div className="text-xs text-gray-500 mt-1 flex items-center gap-1"><CheckCircle className="w-3 h-3 text-green-500"/>Present</div>
            </div>
            <div className="w-px h-12 bg-gray-200 dark:bg-gray-600" />
            <div className="text-center">
              <div className="text-3xl font-bold text-red-500 dark:text-red-400">{data.todayAbsent}</div>
              <div className="text-xs text-gray-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3 text-red-500"/>Absent</div>
            </div>
            <div className="w-px h-12 bg-gray-200 dark:bg-gray-600" />
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-900 dark:text-white">{data.activeEmployees}</div>
              <div className="text-xs text-gray-500 mt-1 flex items-center gap-1"><Users className="w-3 h-3"/>Total Staff</div>
            </div>
          </div>
          {data.todayPresent + data.todayAbsent > 0 && (
            <div className="px-4 pb-3">
              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                <span>Attendance rate</span>
                <span className="font-medium">{Math.round((data.todayPresent/(data.todayPresent+data.todayAbsent))*100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-green-500 rounded-full transition-all"
                  style={{width:`${Math.round((data.todayPresent/(data.todayPresent+data.todayAbsent))*100)}%`}} />
              </div>
            </div>
          )}
        </Card>

        {/* Recent warnings */}
        <Card title="Recent Warnings" icon={AlertTriangle} iconColor="text-orange-500" to="/employees">
          {data.recentWarnings?.length === 0
            ? <Empty text="No recent warnings" />
            : data.recentWarnings?.map(w => (
                <div key={w.id} className="flex items-center gap-3 py-2.5 border-b border-gray-50 dark:border-gray-700 last:border-0">
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-brand-100 dark:bg-brand-900/50 flex-shrink-0 flex items-center justify-center">
                    {w.employee?.profilePhoto
                      ? <img src={w.employee.profilePhoto} alt="" className="w-full h-full object-cover"/>
                      : <span className="text-xs font-bold text-brand-700 dark:text-brand-400">{w.employee?.firstName?.[0]}{w.employee?.lastName?.[0]}</span>
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 dark:text-white truncate">{w.employee?.firstName} {w.employee?.lastName}</div>
                    <div className="text-xs text-gray-400 truncate">{w.title} · {format(new Date(w.dateIssued),'dd MMM yyyy')}</div>
                  </div>
                  <span className={{minor:'badge-yellow',moderate:'badge-orange',serious:'badge-red',final:'badge-red'}[w.severity]||'badge-yellow'}>{w.severity}</span>
                </div>
              ))
          }
        </Card>
      </div>

      {/* Pending fines */}
      {data.pendingFinesCount > 0 && (
        <div className="card p-5 border-l-4 border-red-500">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="font-semibold text-gray-900 dark:text-white">Pending Salary Deductions</div>
              <div className="text-sm text-gray-500">{data.pendingFinesCount} fine{data.pendingFinesCount>1?'s':''} awaiting deduction totalling <span className="font-semibold text-red-600">{fmt(data.pendingFinesAmount)}</span></div>
            </div>
            <Link to="/employees" className="btn-secondary text-sm">Review</Link>
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {to:'/employees',  icon:Users,          label:'Add Employee',  color:'blue'},
          {to:'/employees',  icon:AlertTriangle,  label:'Add Warning',   color:'orange'},
          {to:'/employees',  icon:MessageSquare,  label:'Complaints',    color:'purple'},
          {to:'/employees',  icon:Briefcase,      label:'Assign Tool',   color:'green'},
        ].map(({to,icon:Icon,label,color},i)=>(
          <Link key={i} to={to} className="card p-4 hover:shadow-md transition-shadow flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${{blue:'bg-blue-50 text-blue-600',orange:'bg-orange-50 text-orange-600',purple:'bg-purple-50 text-purple-600',green:'bg-green-50 text-green-600'}[color]}`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
            <ChevronRight className="w-4 h-4 text-gray-400 ml-auto" />
          </Link>
        ))}
      </div>
    </div>
  );
}

// ── Admin section ─────────────────────────────────────────────────────────────
function AdminSection({ data }) {
  return (
    <div className="space-y-5">
      <SectionTitle icon={Settings} label="System Overview" />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Users"   value={data.totalUsers}  icon={User}     color="blue" />
        <StatCard label="Active Users"  value={data.activeUsers} icon={UserCheck} color="green" />
      </div>

      <Card title="Recent Activity" icon={Activity} iconColor="text-brand-500" to="/admin/users">
        {data.recentActivity?.length === 0
          ? <Empty text="No activity yet" />
          : data.recentActivity?.map(log => (
              <div key={log.id} className="flex items-center gap-3 py-2.5 border-b border-gray-50 dark:border-gray-700 last:border-0">
                <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                  <Activity className="w-4 h-4 text-gray-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">{log.user?.username} <span className="font-mono text-brand-600 dark:text-brand-400 text-xs">{log.action}</span></div>
                  <div className="text-xs text-gray-400 truncate">{log.details || '—'} · {format(new Date(log.createdAt),'dd MMM HH:mm')}</div>
                </div>
                <span className={{admin:'bg-purple-100 text-purple-700',inspector:'badge-blue',coordinator:'bg-teal-100 text-teal-700',manager:'bg-orange-100 text-orange-700',viewer:'bg-gray-100 text-gray-600'}[log.user?.role]||'badge-blue'} style={{display:'inline-flex',alignItems:'center',padding:'2px 8px',borderRadius:'4px',fontSize:'11px',fontWeight:600}}>
                  {log.user?.role}
                </span>
              </div>
            ))
        }
      </Card>

      {/* Admin quick links */}
      <div className="grid grid-cols-3 gap-3">
        {[
          {to:'/admin/users',    icon:Users,    label:'User Management', color:'purple'},
          {to:'/admin/backup',   icon:Database, label:'Backup & Restore', color:'blue'},
          {to:'/admin/branding', icon:Eye,      label:'Branding',         color:'orange'},
        ].map(({to,icon:Icon,label,color})=>(
          <Link key={to} to={to} className="card p-4 hover:shadow-md transition-shadow flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${{purple:'bg-purple-50 text-purple-600',blue:'bg-blue-50 text-blue-600',orange:'bg-orange-50 text-orange-600'}[color]}`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
            <ChevronRight className="w-4 h-4 text-gray-400 ml-auto" />
          </Link>
        ))}
      </div>
    </div>
  );
}

// ── Shared helpers ────────────────────────────────────────────────────────────
function SectionTitle({ icon: Icon, label, to }) {
  const inner = (
    <div className="flex items-center gap-2 mb-4">
      <Icon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
      <span className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">{label}</span>
      {to && <ChevronRight className="w-4 h-4 text-gray-400 ml-auto" />}
    </div>
  );
  return to ? <Link to={to} className="block hover:opacity-80 transition-opacity">{inner}</Link> : inner;
}

function Card({ title, icon: Icon, iconColor, to, children }) {
  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-gray-50 dark:border-gray-700">
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 ${iconColor}`} />
          <span className="font-semibold text-gray-900 dark:text-white text-sm">{title}</span>
        </div>
        {to && <Link to={to} className="text-xs text-brand-600 hover:text-brand-700 flex items-center gap-1">View all <ChevronRight className="w-3 h-3"/></Link>}
      </div>
      <div className="px-5 py-1">{children}</div>
    </div>
  );
}

function Empty({ text }) {
  return <div className="py-8 text-center text-sm text-gray-400">{text}</div>;
}

// NEXUS dashboard visual layer: only displays existing server statistics.
function Dial({label,value,max=100,unit='',color='#ff3758',icon:Icon=Gauge}) {
  const n=Number(value)||0, ratio=Math.max(0,Math.min(1,n/Math.max(1,max)));
  return <div className="nexus-dial"><div className="nexus-eyebrow"><Icon size={14}/>{label}</div>
    <div className="nexus-ring" style={{'--fill':`${ratio*270}deg`,'--ring-color':color}}><div className="nexus-ring-inner"><strong>{n.toLocaleString()}</strong><small>{unit}</small></div></div>
  </div>;
}
function Telemetry({label,value,max=100,color='#ff3758'}) {
  const ratio=Math.max(0,Math.min(100,100*(Number(value)||0)/Math.max(1,max)));
  return <div className="nexus-telemetry"><div className="flex justify-between gap-3"><span>{label}</span><b>{value ?? 0}</b></div><div className="nexus-track"><i style={{width:`${ratio}%`,background:color}}/></div></div>;
}
function CommandCenter({data, user}) {
  const vehicles=Number(data.totalVehicles)||0, repairs=Number(data.totalRepairs)||0;
  const expiries=data.upcomingExpiries||[], inspections=data.recentLogs||[], damages=data.recentDamage||[];
  return <section className="nexus-command" aria-label="Fleet command center">
    <div className="nexus-command-heading"><div><span className="nexus-overline"><Radio size={13}/> FLEET OPERATIONS / LIVE DATABASE</span><h2>Fleet Command Center</h2><p>Vehicle readiness, maintenance and inspections — from your existing FleetTrack records</p></div><Link to="/vehicles" className="nexus-action">OPEN FLEET <ArrowUpRight size={15}/></Link></div>
    <div className="nexus-dial-grid"><Dial label="REGISTERED VEHICLES" value={vehicles} max={Math.max(vehicles,10)} icon={Truck}/><Dial label="REPAIR RECORDS" value={repairs} max={Math.max(repairs,10)} icon={Wrench} color="#ff784d"/><Dial label="EXPIRY ALERTS" value={expiries.length} max={Math.max(vehicles,10)} icon={AlertTriangle} color="#ffc26d"/><Dial label="RECENT INSPECTIONS" value={inspections.length} max={Math.max(vehicles,10)} icon={Calendar} color="#38c6ec"/></div>
    <div className="nexus-command-grid"><div className="nexus-screen"><div className="nexus-panel-head"><span><Activity size={16}/> OPERATIONS ANALYTICS</span><span className="nexus-panel-status">● DATABASE CONNECTED</span></div>
      <Telemetry label="Vehicles registered" value={vehicles} max={Math.max(vehicles,10)}/><Telemetry label="Recorded repairs" value={repairs} max={Math.max(repairs,10)} color="#ff875b"/><Telemetry label="Upcoming expiry records" value={expiries.length} max={Math.max(vehicles,10)} color="#f5bf6e"/><Telemetry label="Recent damage inspections" value={damages.length} max={Math.max(vehicles,10)} color="#3ab9e5"/>
      <div className="nexus-cost"><span>TOTAL REPAIR EXPENDITURE</span><strong>{fmt(data.totalRepairCost)}</strong><small>Monthly: {fmt(data.monthlyRepairCost)}</small></div>
    </div><div className="nexus-screen nexus-fleet-panel"><div className="nexus-panel-head"><span><Truck size={16}/> FLEET STATUS MATRIX</span><Link to="/vehicles">ALL VEHICLES →</Link></div>
      <div className="nexus-radar"><div className="nexus-radar-rings"/><Truck size={58} strokeWidth={1.2}/><span>FLEET MONITOR</span></div>
      <div className="nexus-fleet-bottom"><div><strong>{vehicles}</strong><span>REGISTERED</span></div><div><strong>{inspections.length}</strong><span>RECENT LOGS</span></div><div><strong>{expiries.length}</strong><span>ALERTS</span></div></div>
    </div></div>
    <div className="nexus-shortcuts">{[{to:'/vehicles',icon:Truck,text:'VEHICLE REGISTRY'},{to:'/damage',icon:Shield,text:'DAMAGE CONTROL'},{to:'/repairs',icon:Wrench,text:'MAINTENANCE'},{to:'/weekly-logs',icon:Calendar,text:'INSPECTION LOGS'}].map(({to,icon:Icon,text})=><Link key={to} to={to}><Icon size={18}/><span>{text}</span><ChevronRight size={15}/></Link>)}</div>
  </section>;
}

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [stats, setStats]   = useState(null);
  const [loading, setLoading] = useState(true);
  const { user }  = useAuth();
  const { branding } = useBranding();

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(r => setStats(r.data))
      .catch(() => setStats({ role: user?.role, vehicleStats: null, employeeStats: null, adminStats: null }))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-6"><LoadingSpinner message="Loading dashboard..." /></div>;
  if (!stats)  return null;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <Greeting user={user} branding={branding} />
      {stats.vehicleStats && <CommandCenter data={stats.vehicleStats} user={user} />}

      {/* Inspector: vehicles only */}
      {stats.role === 'inspector' && stats.vehicleStats && (
        <VehicleSection data={stats.vehicleStats} />
      )}

      {/* Coordinator: employees only */}
      {stats.role === 'coordinator' && stats.employeeStats && (
        <EmployeeSection data={stats.employeeStats} />
      )}

      {/* Viewer: sees both but no write actions */}
      {stats.role === 'viewer' && (
        <div className="space-y-8">
          {stats.vehicleStats  && <VehicleSection  data={stats.vehicleStats} />}
          {stats.employeeStats && <EmployeeSection data={stats.employeeStats} />}
        </div>
      )}

      {/* Manager: both sections */}
      {stats.role === 'manager' && (
        <div className="space-y-8">
          {stats.vehicleStats  && <VehicleSection  data={stats.vehicleStats} />}
          {stats.employeeStats && <EmployeeSection data={stats.employeeStats} />}
        </div>
      )}

      {/* Admin: everything */}
      {stats.role === 'admin' && (
        <div className="space-y-8">
          {stats.vehicleStats  && <VehicleSection  data={stats.vehicleStats} />}
          {stats.employeeStats && <EmployeeSection data={stats.employeeStats} />}
          {stats.adminStats    && <AdminSection    data={stats.adminStats} />}
        </div>
      )}
    </div>
  );
}
