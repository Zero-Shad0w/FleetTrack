import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Users, Key, ToggleLeft, ToggleRight, Activity, Shield, Eye, UserCheck } from 'lucide-react';
import api from '../../utils/api';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, PageHeader, StatCard } from '../../components/ui';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import { format } from 'date-fns';

const ROLE_COLORS = {
  admin: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  inspector: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  coordinator: 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400',
  manager: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  viewer: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
};

const ROLE_ICONS = { admin: Shield, inspector: UserCheck, viewer: Eye };

const EMPTY_USER = { username: '', email: '', password: '', role: 'viewer' };

export default function UserManagementPage() {
  const [users, setUsers] = useState([]);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('users');
  const [modalOpen, setModalOpen] = useState(false);
  const [pwdModalOpen, setPwdModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_USER);
  const [newPassword, setNewPassword] = useState('');
  const [resetTarget, setResetTarget] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const toast = useToast();
  const { user: me } = useAuth();

  const load = async () => {
    setLoading(true);
    try {
      const [u, a] = await Promise.all([api.get('/users'), api.get('/users/activity')]);
      setUsers(u.data);
      setActivity(a.data);
    } catch (err) {
      toast.error('Failed to load users');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openNew = () => { setForm(EMPTY_USER); setEditing(null); setModalOpen(true); };
  const openEdit = (u) => { setEditing(u); setForm({ username: u.username, email: u.email, role: u.role, password: '' }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.username || !form.email) return toast.error('Username and email required');
    if (!editing && !form.password) return toast.error('Password required for new user');
    try {
      if (editing) {
        const data = { username: form.username, email: form.email, role: form.role };
        await api.put(`/users/${editing.id}`, data);
        toast.success('User updated');
      } else {
        await api.post('/users', form);
        toast.success('User created');
      }
      setModalOpen(false);
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleToggleActive = async (u) => {
    try {
      await api.put(`/users/${u.id}/toggle-active`);
      toast.success(`User ${u.active ? 'disabled' : 'enabled'}`);
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const handleResetPassword = async () => {
    if (!newPassword || newPassword.length < 6) return toast.error('Password must be at least 6 characters');
    try {
      await api.put(`/users/${resetTarget.id}/reset-password`, { newPassword });
      toast.success(`Password reset for ${resetTarget.username}`);
      setPwdModalOpen(false);
      setNewPassword('');
    } catch (err) { toast.error(err.response?.data?.error || 'Reset failed'); }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/users/${deleteId}`);
      toast.success('User deleted');
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const f = (k) => ({ value: form[k], onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const adminCount = users.filter(u => u.role === 'admin').length;
  const inspectorCount = users.filter(u => u.role === 'inspector').length;
  const activeCount = users.filter(u => u.active).length;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader
        title="User Management"
        subtitle="Manage system users and permissions"
        actions={<button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add User</button>}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Users" value={users.length} icon={Users} color="blue" />
        <StatCard label="Active" value={activeCount} icon={UserCheck} color="green" />
        <StatCard label="Admins" value={adminCount} icon={Shield} color="purple" />
        <StatCard label="Inspectors" value={inspectorCount} icon={Eye} color="orange" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl mb-5 w-fit">
        {[['users', Users, 'Users'], ['activity', Activity, 'Activity Log']].map(([key, Icon, label]) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === key ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      {loading ? <LoadingSpinner /> : tab === 'users' ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                  {['User','Email','Role','Status','Last Login','Created',''].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                {users.map((u, i) => {
                  const RoleIcon = ROLE_ICONS[u.role] || Eye;
                  return (
                    <tr key={u.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''} ${!u.active ? 'opacity-50' : ''}`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-brand-100 dark:bg-brand-900/50 rounded-lg flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-brand-700 dark:text-brand-400">{u.username[0].toUpperCase()}</span>
                          </div>
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">{u.username}</div>
                            {u.id === me?.id && <span className="text-xs text-gray-400">(you)</span>}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{u.email}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold ${ROLE_COLORS[u.role]}`}>
                          <RoleIcon className="w-3 h-3" />{u.role}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={u.active ? 'badge-green' : 'badge-red'}>{u.active ? 'Active' : 'Disabled'}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">
                        {u.lastLogin ? format(new Date(u.lastLogin), 'dd MMM yyyy HH:mm') : 'Never'}
                      </td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 text-xs">
                        {format(new Date(u.createdAt), 'dd MMM yyyy')}
                      </td>
                      <td className="px-4 py-3">
                        {u.id !== me?.id && (
                          <div className="flex items-center gap-1">
                            <button onClick={() => openEdit(u)} title="Edit" className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors">
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => { setResetTarget(u); setPwdModalOpen(true); }} title="Reset Password" className="p-1.5 hover:bg-orange-50 dark:hover:bg-orange-900/30 rounded-lg text-gray-500 hover:text-orange-600 transition-colors">
                              <Key className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => handleToggleActive(u)} title={u.active ? 'Disable' : 'Enable'} className="p-1.5 hover:bg-yellow-50 dark:hover:bg-yellow-900/30 rounded-lg text-gray-500 hover:text-yellow-600 transition-colors">
                              {u.active ? <ToggleRight className="w-3.5 h-3.5" /> : <ToggleLeft className="w-3.5 h-3.5" />}
                            </button>
                            <button onClick={() => setDeleteId(u.id)} title="Delete" className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Activity Log */
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                  {['Time','User','Role','Action','Details'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                {activity.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-400">No activity recorded yet</td></tr>
                ) : activity.map((log, i) => (
                  <tr key={log.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''}`}>
                    <td className="px-4 py-2.5 text-gray-500 dark:text-gray-400 text-xs whitespace-nowrap">{format(new Date(log.createdAt), 'dd MMM yyyy HH:mm')}</td>
                    <td className="px-4 py-2.5 font-medium text-gray-900 dark:text-white">{log.user?.username}</td>
                    <td className="px-4 py-2.5"><span className={`text-xs px-2 py-0.5 rounded font-medium ${ROLE_COLORS[log.user?.role]}`}>{log.user?.role}</span></td>
                    <td className="px-4 py-2.5"><span className="font-mono text-xs text-brand-700 dark:text-brand-400">{log.action}</span></td>
                    <td className="px-4 py-2.5 text-gray-600 dark:text-gray-400 text-xs">{log.details || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create/Edit User Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit User' : 'Add User'} size="sm">
        <div className="space-y-4">
          <div>
            <label className="form-label">Username *</label>
            <input className="form-input" placeholder="johndoe" {...f('username')} />
          </div>
          <div>
            <label className="form-label">Email *</label>
            <input className="form-input" type="email" placeholder="john@company.com" {...f('email')} />
          </div>
          {!editing && (
            <div>
              <label className="form-label">Password *</label>
              <input className="form-input" type="password" placeholder="Min 6 characters" {...f('password')} />
            </div>
          )}
          <div>
            <label className="form-label">Role</label>
            <select className="form-select" value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))}>
              <option value="viewer">Viewer — Read only</option>
              <option value="inspector">Inspector — Vehicle access only</option>
              <option value="coordinator">Coordinator — Employee access only</option>
              <option value="manager">Manager — Vehicles + Employees</option>
              <option value="admin">Admin — Full access</option>
            </select>
          </div>

          {/* Role description */}
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 text-xs text-gray-600 dark:text-gray-400">
            {form.role === 'admin' && '⚡ Full access to everything including user management and backups.'}
            {form.role === 'inspector' && '🚗 Vehicle side only. Cannot see employee module or admin settings.'}
            {form.role === 'coordinator' && '👥 Employee side only. Cannot see vehicle module or admin settings.'}
            {form.role === 'manager' && '📋 Both vehicles and employees, but no admin/system access.'}
            {form.role === 'viewer' && '👁 Read-only access. Can view and export data only.'}
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Create User'}</button>
        </div>
      </Modal>

      {/* Reset Password Modal */}
      <Modal open={pwdModalOpen} onClose={() => { setPwdModalOpen(false); setNewPassword(''); }} title={`Reset Password — ${resetTarget?.username}`} size="sm">
        <div className="space-y-3">
          <p className="text-sm text-gray-500 dark:text-gray-400">Enter a new password for this user.</p>
          <div>
            <label className="form-label">New Password</label>
            <input className="form-input" type="password" placeholder="Min 6 characters"
              value={newPassword} onChange={e => setNewPassword(e.target.value)} />
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => { setPwdModalOpen(false); setNewPassword(''); }} className="btn-secondary">Cancel</button>
          <button onClick={handleResetPassword} className="btn-primary"><Key className="w-4 h-4" /> Reset Password</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete User" message="This will permanently delete the user and all their activity logs. This cannot be undone." danger />
    </div>
  );
}
