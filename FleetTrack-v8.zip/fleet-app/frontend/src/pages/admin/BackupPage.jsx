import React, { useState, useEffect, useRef } from 'react';
import { Database, Download, Upload, RotateCcw, Trash2, Plus, HardDrive, CheckCircle, Clock } from 'lucide-react';
import api from '../../utils/api';
import { ConfirmDialog, LoadingSpinner, PageHeader, StatCard } from '../../components/ui';
import { useToast } from '../../context/ToastContext';
import { format } from 'date-fns';

const fmtSize = (bytes) => {
  if (!bytes) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};

export default function BackupPage() {
  const [backups, setBackups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const uploadRef = useRef();
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/backup');
      setBackups(data.backups || []);
    } catch (err) {
      toast.error('Failed to load backups');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    setCreating(true);
    try {
      const { data } = await api.post('/backup/create');
      toast.success(`Backup created: ${data.filename}`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Backup failed');
    } finally { setCreating(false); }
  };

  const handleDownload = (filename) => {
    const token = localStorage.getItem('fleet_token');
    const a = document.createElement('a');
    a.href = `/api/backup/download/${filename}`;
    // Add auth header via fetch + blob
    fetch(`/api/backup/download/${filename}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(r => r.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
      })
      .catch(() => toast.error('Download failed'));
  };

  const handleRestore = async () => {
    try {
      const { data } = await api.post(`/backup/restore/${restoreTarget}`);
      toast.success(data.message);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Restore failed');
    }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/backup/${deleteTarget}`);
      toast.success('Backup deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.name.endsWith('.db')) return toast.error('Please select a valid .db backup file');
    try {
      const buffer = await file.arrayBuffer();
      await fetch('/api/backup/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          'X-Filename': file.name,
          Authorization: `Bearer ${localStorage.getItem('fleet_token')}`
        },
        body: buffer
      });
      toast.success('Backup uploaded successfully');
      load();
    } catch (err) {
      toast.error('Upload failed');
    }
    e.target.value = '';
  };

  const totalSize = backups.reduce((s, b) => s + (b.size || 0), 0);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader
        title="Backup & Restore"
        subtitle="Manage database backups and recovery"
        actions={
          <div className="flex gap-2">
            <input ref={uploadRef} type="file" accept=".db" className="hidden" onChange={handleUpload} />
            <button onClick={() => uploadRef.current.click()} className="btn-secondary">
              <Upload className="w-4 h-4" /> Upload Backup
            </button>
            <button onClick={handleCreate} disabled={creating} className="btn-primary">
              <Plus className="w-4 h-4" /> {creating ? 'Creating...' : 'Create Backup'}
            </button>
          </div>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Backups" value={backups.length} icon={Database} color="blue" />
        <StatCard label="Total Size" value={fmtSize(totalSize)} icon={HardDrive} color="green" />
        <StatCard label="Latest Backup" value={backups[0] ? format(new Date(backups[0].createdAt), 'dd MMM HH:mm') : 'None'} icon={Clock} color="orange" />
      </div>

      {/* Info box */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4 mb-5">
        <div className="flex gap-3">
          <CheckCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-800 dark:text-blue-300">
            <strong>How backups work:</strong> Backups are complete copies of the SQLite database file including all vehicles, repairs, inspections, photos, and user data.
            Restoring a backup will <strong>replace</strong> the current database — a safety backup is automatically created before any restore.
            After restoring, restart the backend server for changes to take effect.
          </div>
        </div>
      </div>

      {/* Backup list */}
      {loading ? <LoadingSpinner /> : backups.length === 0 ? (
        <div className="card p-12 text-center">
          <Database className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <h3 className="font-semibold text-gray-900 dark:text-white mb-1">No backups yet</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Create your first backup to protect your data.</p>
          <button onClick={handleCreate} disabled={creating} className="btn-primary mx-auto">
            <Plus className="w-4 h-4" /> Create First Backup
          </button>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 dark:text-white text-sm">Backup Files</h3>
            <span className="text-xs text-gray-500">{backups.length} backup{backups.length !== 1 ? 's' : ''} · {fmtSize(totalSize)} total</span>
          </div>
          <div className="divide-y divide-gray-50 dark:divide-gray-700">
            {backups.map((b, i) => (
              <div key={b.filename} className={`flex items-center gap-4 px-5 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${i === 0 ? 'bg-green-50/50 dark:bg-green-900/10' : ''}`}>
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${i === 0 ? 'bg-green-100 dark:bg-green-900/30' : 'bg-gray-100 dark:bg-gray-700'}`}>
                  <Database className={`w-4 h-4 ${i === 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-500'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white font-mono truncate">{b.filename}</span>
                    {i === 0 && <span className="badge-green text-xs flex-shrink-0">Latest</span>}
                    {b.filename.startsWith('pre-restore') && <span className="badge-yellow text-xs flex-shrink-0">Safety</span>}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                    {format(new Date(b.createdAt), 'dd MMM yyyy HH:mm:ss')} · {fmtSize(b.size)}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    onClick={() => handleDownload(b.filename)}
                    title="Download backup"
                    className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors">
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setRestoreTarget(b.filename)}
                    title="Restore this backup"
                    className="p-1.5 hover:bg-orange-50 dark:hover:bg-orange-900/30 rounded-lg text-gray-500 hover:text-orange-600 transition-colors">
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteTarget(b.filename)}
                    title="Delete backup"
                    className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Restore confirm */}
      <ConfirmDialog
        open={!!restoreTarget}
        onClose={() => setRestoreTarget(null)}
        onConfirm={handleRestore}
        title="Restore Database"
        message={`This will replace the current database with "${restoreTarget}". A safety backup will be created first. The backend server must be restarted after restore. Continue?`}
        danger
      />

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Backup"
        message={`Permanently delete "${deleteTarget}"? This cannot be undone.`}
        danger
      />
    </div>
  );
}
