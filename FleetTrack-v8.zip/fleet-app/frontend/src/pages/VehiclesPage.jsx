import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Truck, Eye, Camera, Info, Save, ImagePlus } from 'lucide-react';
import VehiclePhotoUploader, { VIEWS } from '../components/ui/VehiclePhotoUploader';
import api from '../utils/api';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, PageHeader, SearchInput } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { format } from 'date-fns';

const EMPTY = {
  companyName: '', vehicleId: '', licensePlate: '', vinNumber: '', make: '', model: '',
  year: '', color: '', fuelType: 'Diesel', transmission: 'Manual', assignedEmployee: '',
  department: '', insuranceProvider: '', insuranceExpiry: '', registrationExpiry: '',
  mileage: '', serviceDueDate: '', notes: '',
  photoFront: null, photoRear: null, photoLeft: null, photoRight: null, photoTop: null,
};

const fmtDate = (d) => d ? format(new Date(d), 'dd MMM yyyy') : '—';
const toInput  = (d) => d ? format(new Date(d), 'yyyy-MM-dd') : '';

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Add / Edit modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [modalTab, setModalTab] = useState('info'); // 'info' | 'photos'

  // View modal
  const [viewOpen, setViewOpen] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [viewTab, setViewTab] = useState('info');
  const [viewPhotos, setViewPhotos] = useState({});
  const [savingPhotos, setSavingPhotos] = useState(false);

  const [deleteId, setDeleteId] = useState(null);
  const { canEdit, isAdmin } = useAuth();
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/vehicles', { params: { search: search || undefined } });
      setVehicles(data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [search]);

  // ── Open Add ──────────────────────────────────────────────────────────────
  const openNew = () => {
    setForm(EMPTY);
    setEditing(null);
    setModalTab('info');
    setModalOpen(true);
  };

  // ── Open Edit ─────────────────────────────────────────────────────────────
  const openEdit = (v) => {
    setEditing(v);
    setForm({
      ...v,
      year:               v.year     || '',
      mileage:            v.mileage  || '',
      insuranceExpiry:    toInput(v.insuranceExpiry),
      registrationExpiry: toInput(v.registrationExpiry),
      serviceDueDate:     toInput(v.serviceDueDate),
      photoFront: v.photoFront || null,
      photoRear:  v.photoRear  || null,
      photoLeft:  v.photoLeft  || null,
      photoRight: v.photoRight || null,
      photoTop:   v.photoTop   || null,
    });
    setModalTab('info');
    setModalOpen(true);
  };

  // ── Open View ─────────────────────────────────────────────────────────────
  const openView = (v) => {
    setViewing(v);
    setViewPhotos({
      photoFront: v.photoFront || null,
      photoRear:  v.photoRear  || null,
      photoLeft:  v.photoLeft  || null,
      photoRight: v.photoRight || null,
      photoTop:   v.photoTop   || null,
    });
    setViewTab('info');
    setViewOpen(true);
  };

  // ── Save vehicle (info + photos together) ─────────────────────────────────
  const handleSave = async () => {
    if (!form.vehicleId.trim())    return toast.error('Vehicle ID is required');
    if (!form.licensePlate.trim()) return toast.error('License plate is required');
    if (!form.make.trim())         return toast.error('Make is required');
    if (!form.model.trim())        return toast.error('Model is required');
    try {
      if (editing) {
        await api.put(`/vehicles/${editing.id}`, form);
        toast.success('Vehicle updated');
      } else {
        await api.post('/vehicles', form);
        toast.success('Vehicle added');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      const msg = err.response?.data?.error || err.message || 'Save failed — check connection';
      toast.error(msg);
    }
  };

  // ── Save ONLY photos from the view modal ──────────────────────────────────
  const handleSavePhotos = async () => {
    if (!viewing) return;
    setSavingPhotos(true);
    try {
      await api.put(`/vehicles/${viewing.id}`, viewPhotos);
      toast.success('Vehicle photos saved!');
      // Refresh vehicles list and update viewing object
      const { data } = await api.get('/vehicles');
      setVehicles(data);
      const updated = data.find(v => v.id === viewing.id);
      if (updated) setViewing(updated);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save photos');
    } finally { setSavingPhotos(false); }
  };

  // ── Delete ────────────────────────────────────────────────────────────────
  const handleDelete = async () => {
    try {
      await api.delete(`/vehicles/${deleteId}`);
      toast.success('Vehicle deleted');
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const f = (k) => ({ value: form[k] ?? '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const photoCount = (v) => VIEWS.filter(view => v[view.key]).length;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Vehicles"
        subtitle={`${vehicles.length} vehicles in fleet`}
        actions={<>
          <SearchInput value={search} onChange={setSearch} placeholder="Search vehicles..." />
          {canEdit && (
            <button onClick={openNew} className="btn-primary">
              <Plus className="w-4 h-4" /> Add Vehicle
            </button>
          )}
        </>}
      />

      {loading ? <LoadingSpinner /> : vehicles.length === 0 ? (
        <EmptyState icon={Truck} title="No vehicles found" message="Add your first vehicle to get started."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Vehicle</button>} />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                  {['Vehicle ID','Plate','Make / Model','Year','Employee','Department','Ins. Expiry','Reg. Expiry','Mileage','Photos',''].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                {vehicles.map((v, i) => (
                  <tr key={v.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${i % 2 === 0 ? '' : 'bg-gray-50/50 dark:bg-gray-800/30'}`}>
                    <td className="px-4 py-3 font-mono text-xs font-medium text-brand-700 dark:text-brand-400">{v.vehicleId}</td>
                    <td className="px-4 py-3 font-medium text-gray-900 dark:text-gray-100">{v.licensePlate}</td>
                    <td className="px-4 py-3 text-gray-700 dark:text-gray-300">{v.make} {v.model}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{v.year || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{v.assignedEmployee || '—'}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{v.department || '—'}</td>
                    <td className="px-4 py-3"><ExpiryBadge date={v.insuranceExpiry} /></td>
                    <td className="px-4 py-3"><ExpiryBadge date={v.registrationExpiry} /></td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{v.mileage ? v.mileage.toLocaleString() + ' km' : '—'}</td>
                    <td className="px-4 py-3">
                      {photoCount(v) > 0
                        ? <span className="badge-blue flex items-center gap-1 w-fit"><Camera className="w-3 h-3" />{photoCount(v)}/5</span>
                        : <button onClick={() => { openView(v); setViewTab('photos'); }}
                            className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 hover:underline">
                            <ImagePlus className="w-3 h-3" /> Add
                          </button>
                      }
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => openView(v)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg transition-colors text-gray-500 hover:text-gray-700" title="View details">
                          <Eye className="w-4 h-4" />
                        </button>
                        {canEdit && (
                          <button onClick={() => openEdit(v)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors text-gray-500 hover:text-blue-600" title="Edit vehicle">
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                        {isAdmin && (
                          <button onClick={() => setDeleteId(v.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors text-gray-500 hover:text-red-600" title="Delete vehicle">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Add / Edit Modal ─────────────────────────────────────────────── */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? `Edit Vehicle — ${editing.vehicleId}` : 'Add Vehicle'} size="lg">
        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl mb-5 w-fit">
          {[['info', Info, 'Vehicle Info'], ['photos', Camera, 'Photos']].map(([key, Icon, label]) => (
            <button key={key} onClick={() => setModalTab(key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${modalTab === key ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
              <Icon className="w-4 h-4" />{label}
              {key === 'photos' && !editing && <span className="text-xs text-gray-400">(optional)</span>}
            </button>
          ))}
        </div>

        {/* Info tab */}
        {modalTab === 'info' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormGroup label="Vehicle ID *"><input className="form-input" placeholder="VH-001" {...f('vehicleId')} /></FormGroup>
            <FormGroup label="License Plate *"><input className="form-input" placeholder="ABC 123 GP" {...f('licensePlate')} /></FormGroup>
            <FormGroup label="Company Name"><input className="form-input" placeholder="FleetCo Ltd" {...f('companyName')} /></FormGroup>
            <FormGroup label="VIN Number"><input className="form-input" placeholder="WV1ZZZ..." {...f('vinNumber')} /></FormGroup>
            <FormGroup label="Make *"><input className="form-input" placeholder="Volkswagen" {...f('make')} /></FormGroup>
            <FormGroup label="Model *"><input className="form-input" placeholder="Caddy" {...f('model')} /></FormGroup>
            <FormGroup label="Year"><input className="form-input" type="number" placeholder="2021" {...f('year')} /></FormGroup>
            <FormGroup label="Color"><input className="form-input" placeholder="White" {...f('color')} /></FormGroup>
            <FormGroup label="Fuel Type">
              <select className="form-select" {...f('fuelType')}>
                {['Diesel','Petrol','Electric','Hybrid','LPG'].map(o => <option key={o}>{o}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Transmission">
              <select className="form-select" {...f('transmission')}>
                {['Manual','Automatic'].map(o => <option key={o}>{o}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Assigned Employee"><input className="form-input" placeholder="John Smith" {...f('assignedEmployee')} /></FormGroup>
            <FormGroup label="Department"><input className="form-input" placeholder="Logistics" {...f('department')} /></FormGroup>
            <FormGroup label="Insurance Provider"><input className="form-input" placeholder="Mutual Insurance" {...f('insuranceProvider')} /></FormGroup>
            <FormGroup label="Insurance Expiry"><input className="form-input" type="date" {...f('insuranceExpiry')} /></FormGroup>
            <FormGroup label="Registration Expiry"><input className="form-input" type="date" {...f('registrationExpiry')} /></FormGroup>
            <FormGroup label="Service Due Date"><input className="form-input" type="date" {...f('serviceDueDate')} /></FormGroup>
            <FormGroup label="Current Mileage (km)"><input className="form-input" type="number" placeholder="45000" {...f('mileage')} /></FormGroup>
            <FormGroup label="Notes" className="md:col-span-2">
              <textarea className="form-input h-20 resize-none" placeholder="Additional notes..." {...f('notes')} />
            </FormGroup>
          </div>
        )}

        {/* Photos tab inside add/edit modal */}
        {modalTab === 'photos' && (
          <div>
            <div className="flex items-center gap-2 mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl text-sm text-blue-800 dark:text-blue-300">
              <Camera className="w-4 h-4 flex-shrink-0" />
              <span>These photos appear as the background when marking damage. You can skip this now and add photos later by clicking the <strong>eye icon</strong> on any vehicle.</span>
            </div>
            <VehiclePhotoUploader
              photos={{ photoFront: form.photoFront, photoRear: form.photoRear, photoLeft: form.photoLeft, photoRight: form.photoRight, photoTop: form.photoTop }}
              onChange={(key, val) => setForm(p => ({ ...p, [key]: val }))}
            />
          </div>
        )}

        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          {modalTab === 'info' && (
            <button onClick={() => setModalTab('photos')} className="btn-secondary">
              <Camera className="w-4 h-4" /> Next: Add Photos
            </button>
          )}
          <button onClick={handleSave} className="btn-primary">
            <Save className="w-4 h-4" /> {editing ? 'Save Changes' : 'Add Vehicle'}
          </button>
        </div>
      </Modal>

      {/* ── View Modal (tabbed: Info + Photos) ──────────────────────────── */}
      <Modal open={viewOpen} onClose={() => setViewOpen(false)} title={`${viewing?.vehicleId} — ${viewing?.make} ${viewing?.model}`} size="lg">
        {viewing && (
          <>
            {/* Tabs */}
            <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl mb-5 w-fit">
              {[['info', Info, 'Vehicle Info'], ['photos', Camera, 'Photos']].map(([key, Icon, label]) => (
                <button key={key} onClick={() => setViewTab(key)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${viewTab === key ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}>
                  <Icon className="w-4 h-4" />{label}
                  {key === 'photos' && (
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${photoCount(viewing) > 0 ? 'badge-blue' : 'badge-yellow'}`}>
                      {photoCount(viewing)}/5
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Info tab */}
            {viewTab === 'info' && (
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['Vehicle ID', viewing.vehicleId], ['License Plate', viewing.licensePlate],
                  ['Make', viewing.make], ['Model', viewing.model],
                  ['Year', viewing.year], ['Color', viewing.color],
                  ['Fuel Type', viewing.fuelType], ['Transmission', viewing.transmission],
                  ['VIN Number', viewing.vinNumber], ['Company', viewing.companyName],
                  ['Employee', viewing.assignedEmployee], ['Department', viewing.department],
                  ['Insurance Provider', viewing.insuranceProvider], ['Insurance Expiry', fmtDate(viewing.insuranceExpiry)],
                  ['Registration Expiry', fmtDate(viewing.registrationExpiry)], ['Service Due', fmtDate(viewing.serviceDueDate)],
                  ['Mileage', viewing.mileage ? `${viewing.mileage.toLocaleString()} km` : '—'],
                ].map(([label, val]) => (
                  <div key={label} className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                    <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-0.5">{label}</div>
                    <div className="text-sm font-medium text-gray-900 dark:text-gray-100">{val || '—'}</div>
                  </div>
                ))}
                {viewing.notes && (
                  <div className="col-span-2 bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
                    <div className="text-xs font-medium text-gray-500 mb-0.5">Notes</div>
                    <div className="text-sm text-gray-700 dark:text-gray-300">{viewing.notes}</div>
                  </div>
                )}
                {canEdit && (
                  <div className="col-span-2 pt-2">
                    <button onClick={() => openEdit(viewing)} className="btn-secondary">
                      <Edit2 className="w-4 h-4" /> Edit Vehicle
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Photos tab — fully standalone, save independently */}
            {viewTab === 'photos' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl text-sm text-blue-800 dark:text-blue-300">
                  <Camera className="w-4 h-4 flex-shrink-0" />
                  <span>
                    {canEdit
                      ? 'Add or replace photos for each view angle. Click a photo to replace it, or the × to remove it. Save when done.'
                      : 'Vehicle photos uploaded by your team.'}
                  </span>
                </div>

                <VehiclePhotoUploader
                  photos={viewPhotos}
                  onChange={canEdit ? (key, val) => setViewPhotos(p => ({ ...p, [key]: val })) : () => {}}
                />

                {/* Show a note if no photos at all */}
                {VIEWS.every(v => !viewPhotos[v.key]) && (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <ImagePlus className="w-10 h-10 text-gray-300 dark:text-gray-600 mb-2" />
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">No photos uploaded yet</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                      {canEdit ? 'Click any slot above to add a photo of that vehicle angle.' : 'Ask an admin or inspector to upload photos.'}
                    </p>
                  </div>
                )}

                {canEdit && (
                  <div className="flex justify-end pt-2 border-t border-gray-100 dark:border-gray-700">
                    <button onClick={handleSavePhotos} disabled={savingPhotos} className="btn-primary">
                      {savingPhotos
                        ? <><span className="animate-spin mr-2">⏳</span> Saving...</>
                        : <><Save className="w-4 h-4" /> Save Photos</>
                      }
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Vehicle"
        message="This will permanently delete the vehicle and all its records. This cannot be undone."
        danger
      />
    </div>
  );
}

function FormGroup({ label, children, className = '' }) {
  return (
    <div className={className}>
      <label className="form-label">{label}</label>
      {children}
    </div>
  );
}

function ExpiryBadge({ date }) {
  if (!date) return <span className="text-gray-400">—</span>;
  const d = new Date(date);
  const diff = (d - new Date()) / (1000 * 60 * 60 * 24);
  const cls = diff < 0 ? 'badge-red' : diff < 30 ? 'badge-yellow' : 'badge-green';
  return <span className={cls}>{format(d, 'dd MMM yy')}</span>;
}
