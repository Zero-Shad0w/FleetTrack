import React, { useState, useEffect, useRef } from 'react';
import { Plus, Edit2, Trash2, Wrench, Printer, DollarSign, TrendingUp, FileText } from 'lucide-react';
import api from '../utils/api';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, PageHeader, SearchInput, StatCard } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { format } from 'date-fns';

const EMPTY = { vehicleId: '', repairDate: format(new Date(), 'yyyy-MM-dd'), description: '', category: 'Service', workshop: '', mileage: '', labourCost: '', partsCost: '', invoiceNumber: '', authorisedBy: '', notes: '' };
const CATEGORIES = ['Service', 'Brakes', 'Tyres', 'Engine', 'Electrical', 'Body', 'Suspension', 'Transmission', 'Maintenance', 'Other'];

export default function RepairsPage() {
  const [repairs, setRepairs] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterVehicle, setFilterVehicle] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStart, setFilterStart] = useState('');
  const [filterEnd, setFilterEnd] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [deleteId, setDeleteId] = useState(null);
  const { canEdit, isAdmin } = useAuth();
  const toast = useToast();
  const printRef = useRef();

  const load = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filterVehicle) params.vehicleId = filterVehicle;
      if (filterCategory) params.category = filterCategory;
      if (filterStart) params.startDate = filterStart;
      if (filterEnd) params.endDate = filterEnd;
      const [r, v] = await Promise.all([api.get('/repairs', { params }), api.get('/vehicles')]);
      setRepairs(r.data); setVehicles(v.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filterVehicle, filterCategory, filterStart, filterEnd]);

  const openNew = () => { setForm({ ...EMPTY, vehicleId: filterVehicle || '' }); setEditing(null); setModalOpen(true); };
  const openEdit = (r) => { setEditing(r); setForm({ ...r, repairDate: format(new Date(r.repairDate), 'yyyy-MM-dd'), vehicleId: r.vehicleId }); setModalOpen(true); };

  const handleSave = async () => {
    try {
      if (editing) { await api.put(`/repairs/${editing.id}`, form); toast.success('Repair updated'); }
      else { await api.post('/repairs', form); toast.success('Repair logged'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/repairs/${deleteId}`); toast.success('Repair deleted'); load(); }
    catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const f = (k) => ({ value: form[k] || '', onChange: e => setForm(p => ({ ...p, [k]: e.target.value })) });

  const totalCost = repairs.reduce((s, r) => s + (r.totalCost || 0), 0);
  const totalLabour = repairs.reduce((s, r) => s + (r.labourCost || 0), 0);
  const totalParts = repairs.reduce((s, r) => s + (r.partsCost || 0), 0);
  const fmt = (n) => `€${n.toLocaleString('de-DE', { minimumFractionDigits: 2 })}`;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Repairs & Parts" subtitle="Track all maintenance and repairs"
        actions={<>
          <button onClick={() => window.print()} className="btn-secondary no-print"><Printer className="w-4 h-4" /> Print</button>
          {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Repair</button>}
        </>}
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Repairs" value={repairs.length} icon={Wrench} color="blue" />
        <StatCard label="Total Cost" value={fmt(totalCost)} icon={DollarSign} color="green" />
        <StatCard label="Labour / Parts" value={`${fmt(totalLabour)} / ${fmt(totalParts)}`} icon={TrendingUp} color="orange" />
      </div>

      {/* Filters */}
      <div className="card p-4 mb-4 flex flex-wrap gap-3 no-print">
        <select className="form-select w-48" value={filterVehicle} onChange={e => setFilterVehicle(e.target.value)}>
          <option value="">All Vehicles</option>
          {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
        </select>
        <select className="form-select w-40" value={filterCategory} onChange={e => setFilterCategory(e.target.value)}>
          <option value="">All Categories</option>
          {CATEGORIES.map(c => <option key={c}>{c}</option>)}
        </select>
        <input type="date" className="form-input w-40" value={filterStart} onChange={e => setFilterStart(e.target.value)} />
        <input type="date" className="form-input w-40" value={filterEnd} onChange={e => setFilterEnd(e.target.value)} />
        <button onClick={() => { setFilterVehicle(''); setFilterCategory(''); setFilterStart(''); setFilterEnd(''); }} className="btn-secondary text-xs">Clear</button>
      </div>

      {loading ? <LoadingSpinner /> : repairs.length === 0 ? (
        <EmptyState icon={Wrench} title="No repairs found" message="Log your first repair record."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> Add Repair</button>} />
      ) : (
        <div className="card overflow-hidden" ref={printRef}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                  {['Date','Vehicle','Description','Category','Workshop','Mileage','Labour','Parts','Total','Invoice','Authorised',''].map(h => (
                    <th key={h} className="px-3 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                {repairs.map((r, i) => (
                  <tr key={r.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''}`}>
                    <td className="px-3 py-3 whitespace-nowrap text-gray-600 dark:text-gray-400">{format(new Date(r.repairDate), 'dd MMM yyyy')}</td>
                    <td className="px-3 py-3 font-mono text-xs font-medium text-brand-700 dark:text-brand-400">{r.vehicle?.vehicleId}</td>
                    <td className="px-3 py-3 text-gray-700 dark:text-gray-300 max-w-xs truncate">{r.description}</td>
                    <td className="px-3 py-3"><span className="badge-blue">{r.category}</span></td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400">{r.workshop || '—'}</td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400">{r.mileage ? r.mileage.toLocaleString() : '—'}</td>
                    <td className="px-3 py-3 text-gray-700 dark:text-gray-300">€{(r.labourCost || 0).toFixed(2)}</td>
                    <td className="px-3 py-3 text-gray-700 dark:text-gray-300">€{(r.partsCost || 0).toFixed(2)}</td>
                    <td className="px-3 py-3 font-semibold text-gray-900 dark:text-white">€{(r.totalCost || 0).toFixed(2)}</td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400 font-mono text-xs">{r.invoiceNumber || '—'}</td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400">{r.authorisedBy || '—'}</td>
                    <td className="px-3 py-3 no-print">
                      <div className="flex items-center gap-1">
                        {canEdit && <button onClick={() => openEdit(r)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>}
                        {isAdmin && <button onClick={() => setDeleteId(r.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
                {/* Totals row */}
                <tr className="bg-gray-50 dark:bg-gray-700/50 font-semibold border-t-2 border-gray-200 dark:border-gray-600">
                  <td colSpan={6} className="px-3 py-3 text-sm text-gray-700 dark:text-gray-300">Totals ({repairs.length} records)</td>
                  <td className="px-3 py-3 text-gray-900 dark:text-white">{fmt(totalLabour)}</td>
                  <td className="px-3 py-3 text-gray-900 dark:text-white">{fmt(totalParts)}</td>
                  <td className="px-3 py-3 text-brand-700 dark:text-brand-400 text-base">{fmt(totalCost)}</td>
                  <td colSpan={3} />
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Repair' : 'Log Repair'} size="lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Vehicle *</label>
            <select className="form-select" value={form.vehicleId} onChange={e => setForm(p => ({ ...p, vehicleId: e.target.value }))} required>
              <option value="">Select vehicle...</option>
              {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
            </select>
          </div>
          <div><label className="form-label">Repair Date *</label><input className="form-input" type="date" {...f('repairDate')} required /></div>
          <div className="md:col-span-2"><label className="form-label">Description *</label><input className="form-input" placeholder="Describe the repair..." {...f('description')} required /></div>
          <div>
            <label className="form-label">Category</label>
            <select className="form-select" {...f('category')}>
              {CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div><label className="form-label">Workshop</label><input className="form-input" placeholder="Workshop name" {...f('workshop')} /></div>
          <div><label className="form-label">Mileage at Repair</label><input className="form-input" type="number" placeholder="45000" {...f('mileage')} /></div>
          <div><label className="form-label">Invoice Number</label><input className="form-input" placeholder="INV-001" {...f('invoiceNumber')} /></div>
          <div>
            <label className="form-label">Labour Cost (R)</label>
            <input className="form-input" type="number" step="0.01" placeholder="0.00" {...f('labourCost')} />
          </div>
          <div>
            <label className="form-label">Parts Cost (R)</label>
            <input className="form-input" type="number" step="0.01" placeholder="0.00" {...f('partsCost')} />
          </div>
          <div>
            <label className="form-label">Total Cost (auto)</label>
            <div className="form-input bg-gray-50 dark:bg-gray-600 font-semibold text-brand-700 dark:text-brand-400">
              €{((parseFloat(form.labourCost) || 0) + (parseFloat(form.partsCost) || 0)).toFixed(2)}
            </div>
          </div>
          <div><label className="form-label">Authorised By</label><input className="form-input" placeholder="Fleet Manager" {...f('authorisedBy')} /></div>
          <div className="md:col-span-2"><label className="form-label">Notes</label><textarea className="form-input h-16 resize-none" {...f('notes')} /></div>
        </div>
        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary">{editing ? 'Save Changes' : 'Log Repair'}</button>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Repair" message="Are you sure you want to delete this repair record?" danger />
    </div>
  );
}
