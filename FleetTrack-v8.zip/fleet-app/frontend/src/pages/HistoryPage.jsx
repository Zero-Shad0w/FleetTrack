import React, { useState, useEffect } from 'react';
import { History, Truck, Wrench, Shield, ClipboardCheck, FileText, DollarSign, Calendar, ChevronDown, ChevronUp, Printer, FileDown } from 'lucide-react';
import api from '../utils/api';
import { LoadingSpinner, PageHeader, EmptyState } from '../components/ui';
import { format } from 'date-fns';

export default function HistoryPage() {
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [vehicleData, setVehicleData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [vehiclesLoading, setVehiclesLoading] = useState(true);
  const [expanded, setExpanded] = useState({ repairs: true, damage: true, logs: true, equipment: false });

  useEffect(() => {
    api.get('/vehicles').then(r => setVehicles(r.data)).finally(() => setVehiclesLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedVehicle) { setVehicleData(null); return; }
    setLoading(true);
    api.get(`/vehicles/${selectedVehicle}`)
      .then(r => setVehicleData(r.data))
      .finally(() => setLoading(false));
  }, [selectedVehicle]);

  const fmt = (n) => `€${(n || 0).toLocaleString('de-DE', { minimumFractionDigits: 2 })}`;
  const totalRepairCost = vehicleData?.repairs?.reduce((s, r) => s + (r.totalCost || 0), 0) || 0;

  const toggle = (k) => setExpanded(e => ({ ...e, [k]: !e[k] }));

  const exportPDF = async () => {
    if (!selectedVehicle) return;
    const token = localStorage.getItem('fleet_token');
    try {
      const res = await fetch(`/api/reports/vehicle/${selectedVehicle}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const html = await res.text();
      const win = window.open('', '_blank');
      win.document.write(html);
      win.document.close();
      setTimeout(() => win.print(), 800);
    } catch (err) {
      alert('Failed to generate report');
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader
        title="Vehicle History"
        subtitle="Full lifecycle history per vehicle"
        actions={
          <div className="flex gap-2">
            <button onClick={() => window.print()} className="btn-secondary no-print">
              <Printer className="w-4 h-4" /> Print
            </button>
            {selectedVehicle && (
              <button onClick={exportPDF} className="btn-primary no-print">
                <FileDown className="w-4 h-4" /> Export Full PDF Report
              </button>
            )}
          </div>
        }
      />

      {/* Vehicle selector */}
      <div className="card p-4 mb-6">
        <label className="form-label">Select Vehicle</label>
        {vehiclesLoading ? <div className="h-10 bg-gray-100 dark:bg-gray-700 rounded-lg animate-pulse" /> : (
          <select className="form-select max-w-sm" value={selectedVehicle} onChange={e => setSelectedVehicle(e.target.value)}>
            <option value="">— Choose a vehicle —</option>
            {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model} ({v.licensePlate})</option>)}
          </select>
        )}
      </div>

      {!selectedVehicle && (
        <EmptyState icon={History} title="Select a vehicle" message="Choose a vehicle above to view its full history and timeline." />
      )}

      {loading && <LoadingSpinner message="Loading vehicle history..." />}

      {vehicleData && !loading && (
        <div className="space-y-6">
          {/* Vehicle Profile */}
          <div className="card overflow-hidden">
            <div className="bg-gradient-to-r from-brand-600 to-brand-700 px-6 py-4 print:bg-brand-600">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Truck className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">{vehicleData.vehicleId} — {vehicleData.make} {vehicleData.model}</h2>
                  <p className="text-brand-200 text-sm">{vehicleData.licensePlate} · {vehicleData.year} · {vehicleData.color}</p>
                </div>
              </div>
            </div>
            <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                ['Company', vehicleData.companyName],
                ['Assigned To', vehicleData.assignedEmployee],
                ['Department', vehicleData.department],
                ['Fuel Type', vehicleData.fuelType],
                ['VIN', vehicleData.vinNumber],
                ['Mileage', vehicleData.mileage ? `${vehicleData.mileage.toLocaleString()} km` : '—'],
                ['Insurance Expiry', vehicleData.insuranceExpiry ? format(new Date(vehicleData.insuranceExpiry), 'dd MMM yyyy') : '—'],
                ['Registration Expiry', vehicleData.registrationExpiry ? format(new Date(vehicleData.registrationExpiry), 'dd MMM yyyy') : '—'],
              ].map(([label, val]) => (
                <div key={label}>
                  <div className="text-xs text-gray-500 dark:text-gray-400 mb-0.5">{label}</div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white">{val || '—'}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Cost Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="card p-4 text-center">
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{vehicleData.repairs?.length || 0}</div>
              <div className="text-xs text-gray-500 mt-0.5">Total Repairs</div>
            </div>
            <div className="card p-4 text-center">
              <div className="text-2xl font-bold text-brand-700 dark:text-brand-400">{fmt(totalRepairCost)}</div>
              <div className="text-xs text-gray-500 mt-0.5">Total Repair Cost</div>
            </div>
            <div className="card p-4 text-center">
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{vehicleData.weeklyLogs?.length || 0}</div>
              <div className="text-xs text-gray-500 mt-0.5">Inspections</div>
            </div>
          </div>

          {/* Repairs Section */}
          <Section
            title="Repair History" icon={Wrench} color="orange" count={vehicleData.repairs?.length}
            expanded={expanded.repairs} onToggle={() => toggle('repairs')}>
            {vehicleData.repairs?.length === 0 ? (
              <p className="text-sm text-gray-400 py-4 text-center">No repairs recorded</p>
            ) : (
              <div className="space-y-2">
                {vehicleData.repairs?.sort((a, b) => new Date(b.repairDate) - new Date(a.repairDate)).map(r => (
                  <div key={r.id} className="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                    <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-medium text-sm text-gray-900 dark:text-white">{r.description}</div>
                          <div className="text-xs text-gray-500 mt-0.5">{r.workshop || 'N/A'} · {r.category} · {r.authorisedBy || 'N/A'}</div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="font-semibold text-sm text-gray-900 dark:text-white">{fmt(r.totalCost)}</div>
                          <div className="text-xs text-gray-400">{r.invoiceNumber || ''}</div>
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-400 flex-shrink-0">{format(new Date(r.repairDate), 'dd MMM yyyy')}</div>
                  </div>
                ))}
                <div className="flex justify-end pt-2 border-t border-gray-100 dark:border-gray-700">
                  <span className="text-sm font-semibold text-brand-700 dark:text-brand-400">Total: {fmt(totalRepairCost)}</span>
                </div>
              </div>
            )}
          </Section>

          {/* Damage Inspections */}
          <Section
            title="Damage Inspections" icon={Shield} color="red" count={vehicleData.damageInspections?.length}
            expanded={expanded.damage} onToggle={() => toggle('damage')}>
            {vehicleData.damageInspections?.length === 0 ? (
              <p className="text-sm text-gray-400 py-4 text-center">No damage inspections recorded</p>
            ) : (
              <div className="space-y-2">
                {vehicleData.damageInspections?.sort((a, b) => new Date(b.inspectionDate) - new Date(a.inspectionDate)).map(insp => {
                  const totalMarkers = ['frontDamageMarkers','rearDamageMarkers','sideDamageMarkers','topDamageMarkers']
                    .reduce((s, k) => { try { return s + JSON.parse(insp[k] || '[]').length; } catch { return s; } }, 0);
                  return (
                    <div key={insp.id} className="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                      <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Shield className="w-5 h-5 text-red-600 dark:text-red-400" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium text-sm text-gray-900 dark:text-white">Inspector: {insp.inspectorName}</div>
                            {insp.damageNotes && <div className="text-xs text-gray-500 mt-0.5">{insp.damageNotes}</div>}
                          </div>
                          <span className={totalMarkers > 0 ? 'badge-red' : 'badge-green'}>{totalMarkers > 0 ? `${totalMarkers} damage markers` : 'No damage'}</span>
                        </div>
                      </div>
                      <div className="text-xs text-gray-400 flex-shrink-0">{format(new Date(insp.inspectionDate), 'dd MMM yyyy')}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </Section>

          {/* Weekly Logs */}
          <Section
            title="Weekly Inspection Logs" icon={FileText} color="blue" count={vehicleData.weeklyLogs?.length}
            expanded={expanded.logs} onToggle={() => toggle('logs')}>
            {vehicleData.weeklyLogs?.length === 0 ? (
              <p className="text-sm text-gray-400 py-4 text-center">No logs recorded</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-gray-100 dark:border-gray-700">
                      {['Date','Employee','Mileage','Fuel','Damage','Equipment','Comments'].map(h => (
                        <th key={h} className="pb-2 text-left font-semibold text-gray-500 pr-4">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                    {vehicleData.weeklyLogs?.sort((a, b) => new Date(b.inspectionDate) - new Date(a.inspectionDate)).map(log => (
                      <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                        <td className="py-2 pr-4 whitespace-nowrap">{format(new Date(log.inspectionDate), 'dd MMM yyyy')}</td>
                        <td className="py-2 pr-4">{log.employeeName}</td>
                        <td className="py-2 pr-4">{log.mileage ? `${log.mileage.toLocaleString()} km` : '—'}</td>
                        <td className="py-2 pr-4">{log.fuelLevel || '—'}</td>
                        <td className="py-2 pr-4"><span className={log.damageFound ? 'badge-red' : 'badge-green'}>{log.damageFound ? 'Yes' : 'No'}</span></td>
                        <td className="py-2 pr-4"><span className={log.equipmentComplete ? 'badge-green' : 'badge-red'}>{log.equipmentComplete ? '✓' : '✗'}</span></td>
                        <td className="py-2 text-gray-500 max-w-xs truncate">{log.comments || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Section>

          {/* Equipment Checks */}
          <Section
            title="Equipment Check History" icon={ClipboardCheck} color="green" count={vehicleData.equipmentChecks?.length}
            expanded={expanded.equipment} onToggle={() => toggle('equipment')}>
            {vehicleData.equipmentChecks?.length === 0 ? (
              <p className="text-sm text-gray-400 py-4 text-center">No equipment checks recorded</p>
            ) : (
              <div className="text-sm text-gray-500 dark:text-gray-400">{vehicleData.equipmentChecks?.length} check items recorded.</div>
            )}
          </Section>
        </div>
      )}
    </div>
  );
}

function Section({ title, icon: Icon, color, count, expanded, onToggle, children }) {
  const colors = {
    orange: 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400',
    red: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400',
    blue: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
    green: 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400',
  };
  return (
    <div className="card overflow-hidden">
      <button className="w-full flex items-center gap-3 px-5 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors" onClick={onToggle}>
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${colors[color]}`}>
          <Icon className="w-4 h-4" />
        </div>
        <span className="font-semibold text-gray-900 dark:text-white text-sm flex-1 text-left">{title}</span>
        <span className="text-xs text-gray-400 mr-2">{count || 0} records</span>
        {expanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
      </button>
      {expanded && <div className="px-5 pb-5 border-t border-gray-50 dark:border-gray-700 pt-4">{children}</div>}
    </div>
  );
}
