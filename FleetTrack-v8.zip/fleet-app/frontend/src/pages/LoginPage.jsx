import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBranding } from '../context/BrandingContext';
import { useToast } from '../context/ToastContext';

export default function LoginPage() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const { branding } = useBranding();
  const toast = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.username, form.password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-950 dark:to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex w-16 h-16 rounded-2xl items-center justify-center mb-4 shadow-lg overflow-hidden" style={{ background: branding.logoData ? 'transparent' : branding.primaryColor || '#2563eb' }}>
            {branding.logoData
              ? <img src={branding.logoData} alt="Logo" className="w-full h-full object-contain p-1" />
              : <Truck className="w-8 h-8 text-white" />
            }
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{branding.softwareName || 'FleetTrack Pro'}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Vehicle Inspection Management</p>
        </div>

        <div className="card p-8">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Sign in to your account</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="form-label">Username or Email</label>
              <input
                type="text" className="form-input" placeholder="admin"
                value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                required autoFocus
              />
            </div>
            <div>
              <label className="form-label">Password</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'} className="form-input pr-10" placeholder="••••••••"
                  value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  required
                />
                <button type="button" onClick={() => setShowPass(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-100 dark:border-gray-700">
            <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-3">Demo credentials</p>
            <div className="grid grid-cols-5 gap-2">
              {[
                ['admin','admin123','Admin'],
                ['inspector1','inspector123','Inspector'],
                ['coordinator1','coordinator123','Coordinator'],
                ['manager1','manager123','Manager'],
                ['viewer1','viewer123','Viewer'],
              ].map(([u, p, label]) => (
                <button key={u} type="button" onClick={() => setForm({ username: u, password: p })}
                  className="text-xs p-2 rounded-lg bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors text-center">
                  <div className="font-medium text-gray-700 dark:text-gray-300">{label}</div>
                  <div className="text-gray-400 truncate">{u}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
