import React, { useState, useEffect, useRef } from 'react';
import { Plus, Edit2, Trash2, Shield, Save, Printer, Camera, X, ZoomIn, ChevronLeft, ChevronRight, Image, ImagePlus } from 'lucide-react';
import PLACEHOLDER_IMAGES from '../utils/placeholderImages';
import api from '../utils/api';
import { Modal, ConfirmDialog, LoadingSpinner, EmptyState, PageHeader } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { format } from 'date-fns';

const DAMAGE_TYPES = {
  dent:    { label: 'Dent',    color: '#ef4444', bg: '#fee2e2' },
  scratch: { label: 'Scratch', color: '#f59e0b', bg: '#fef3c7' },
  crack:   { label: 'Crack',   color: '#8b5cf6', bg: '#ede9fe' },
  chip:    { label: 'Chip',    color: '#3b82f6', bg: '#dbeafe' },
};

const EMPTY_FORM = {
  vehicleId: '', inspectionDate: format(new Date(), 'yyyy-MM-dd'),
  inspectorName: '', mileage: '', damageNotes: '', signature: '',
  frontDamageMarkers: [], rearDamageMarkers: [], sideDamageMarkers: [], leftDamageMarkers: [], rightDamageMarkers: [], topDamageMarkers: [],
  photos: [],
};

const VIEW_PHOTO_MAP = { front: 'photoFront', rear: 'photoRear', left: 'photoLeft', right: 'photoRight', top: 'photoTop' };
const VIEW_PLACEHOLDER_MAP = { front: 'front', rear: 'rear', left: 'left', right: 'right', top: 'top' };

// ── Photo Upload Component ────────────────────────────────────────────────────
function PhotoUploader({ photos, onChange, readOnly }) {
  const inputRef = useRef();
  const [lightbox, setLightbox] = useState(null); // index of photo in lightbox

  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      if (file.size > 10 * 1024 * 1024) { alert(`${file.name} is too large (max 10MB)`); return; }
      const reader = new FileReader();
      reader.onload = (ev) => {
        onChange(prev => [...prev, {
          id: Date.now() + Math.random(),
          name: file.name,
          dataUrl: ev.target.result,
          caption: '',
        }]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const removePhoto = (id) => onChange(prev => prev.filter(p => p.id !== id));
  const updateCaption = (id, caption) => onChange(prev => prev.map(p => p.id === id ? { ...p, caption } : p));

  return (
    <div className="space-y-3">
      {/* Upload button */}
      {!readOnly && (
        <div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFiles}
          />
          <button
            type="button"
            onClick={() => inputRef.current.click()}
            className="flex items-center gap-2 px-4 py-2.5 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-500 dark:text-gray-400 hover:border-brand-400 hover:text-brand-600 dark:hover:border-brand-500 dark:hover:text-brand-400 transition-all w-full justify-center"
          >
            <Camera className="w-4 h-4" />
            Click to add photos (JPG, PNG, HEIC — max 10MB each)
          </button>
        </div>
      )}

      {/* Photo grid */}
      {photos.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {photos.map((photo, idx) => (
            <div key={photo.id} className="group relative">
              <div
                className="aspect-square rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-700 cursor-pointer border border-gray-200 dark:border-gray-600 hover:border-brand-400 transition-all"
                onClick={() => setLightbox(idx)}
              >
                <img
                  src={photo.dataUrl}
                  alt={photo.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center">
                  <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              </div>

              {/* Remove button */}
              {!readOnly && (
                <button
                  onClick={(e) => { e.stopPropagation(); removePhoto(photo.id); }}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center shadow-md hover:bg-red-600 transition-colors z-10"
                >
                  <X className="w-3 h-3" />
                </button>
              )}

              {/* Caption */}
              {!readOnly ? (
                <input
                  type="text"
                  value={photo.caption}
                  onChange={e => updateCaption(photo.id, e.target.value)}
                  placeholder="Add caption..."
                  className="mt-1.5 w-full text-xs form-input py-1"
                  onClick={e => e.stopPropagation()}
                />
              ) : photo.caption ? (
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 truncate">{photo.caption}</p>
              ) : null}
            </div>
          ))}
        </div>
      )}

      {photos.length === 0 && readOnly && (
        <div className="flex items-center gap-2 text-sm text-gray-400 py-3">
          <Image className="w-4 h-4" /> No photos attached
        </div>
      )}

      {/* Lightbox */}
      {lightbox !== null && photos[lightbox] && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-4 right-4 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white"
            onClick={() => setLightbox(null)}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Prev */}
          {lightbox > 0 && (
            <button
              className="absolute left-4 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white"
              onClick={e => { e.stopPropagation(); setLightbox(lightbox - 1); }}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {/* Image */}
          <div onClick={e => e.stopPropagation()} className="max-w-4xl max-h-full">
            <img
              src={photos[lightbox].dataUrl}
              alt={photos[lightbox].name}
              className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl"
            />
            {photos[lightbox].caption && (
              <p className="text-center text-white/80 text-sm mt-3">{photos[lightbox].caption}</p>
            )}
            <p className="text-center text-white/50 text-xs mt-1">
              {lightbox + 1} / {photos.length}
            </p>
          </div>

          {/* Next */}
          {lightbox < photos.length - 1 && (
            <button
              className="absolute right-4 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white"
              onClick={e => { e.stopPropagation(); setLightbox(lightbox + 1); }}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}


// ── Marker Detail Modal (per-marker photos & notes) ──────────────────────────
function MarkerDetailModal({ marker, onUpdate, onClose, readOnly }) {
  const [localMarker, setLocalMarker] = useState({ ...marker });
  const inputRef = useRef();

  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        setLocalMarker(m => ({
          ...m,
          photos: [...(m.photos || []), { id: Date.now() + Math.random(), name: file.name, dataUrl: ev.target.result, caption: '' }]
        }));
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const removePhoto = (pid) => setLocalMarker(m => ({ ...m, photos: m.photos.filter(p => p.id !== pid) }));

  const handleSave = () => { onUpdate(localMarker); onClose(); };

  const dt = DAMAGE_TYPES[localMarker.type] || DAMAGE_TYPES.dent;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <span className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
            style={{ background: dt.color }}>{localMarker.type?.[0]?.toUpperCase()}</span>
          <h3 className="font-semibold text-gray-900 dark:text-white flex-1">
            {dt.label} — Damage Details
          </h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-4">
          {!readOnly && (
            <div>
              <label className="form-label">Damage Type</label>
              <select className="form-select" value={localMarker.type}
                onChange={e => setLocalMarker(m => ({ ...m, type: e.target.value }))}>
                {Object.entries(DAMAGE_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="form-label">Notes</label>
            {readOnly
              ? <p className="text-sm text-gray-700 dark:text-gray-300">{localMarker.notes || '—'}</p>
              : <textarea className="form-input h-20 resize-none" placeholder="Describe this damage..."
                  value={localMarker.notes || ''} onChange={e => setLocalMarker(m => ({ ...m, notes: e.target.value }))} />
            }
          </div>
          {localMarker.timestamp && (
            <div className="text-xs text-gray-400">
              Added: {new Date(localMarker.timestamp).toLocaleString()}
            </div>
          )}
          <div>
            <label className="form-label flex items-center gap-2">
              <Camera className="w-3.5 h-3.5 text-gray-400" />
              Photos for this damage point
              {(localMarker.photos?.length > 0) && <span className="badge-blue">{localMarker.photos.length}</span>}
            </label>
            {!readOnly && (
              <>
                <input ref={inputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
                <button onClick={() => inputRef.current.click()}
                  className="flex items-center gap-2 px-3 py-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl text-xs text-gray-500 hover:border-brand-400 hover:text-brand-600 transition-all w-full justify-center mb-3">
                  <Camera className="w-4 h-4" /> Add photos for this damage point
                </button>
              </>
            )}
            {(localMarker.photos?.length > 0) ? (
              <div className="grid grid-cols-2 gap-2">
                {localMarker.photos.map((p) => (
                  <div key={p.id} className="relative group">
                    <img src={p.dataUrl} alt={p.name} className="w-full h-24 object-cover rounded-lg border border-gray-200 dark:border-gray-600" />
                    {!readOnly && (
                      <button onClick={() => removePhoto(p.id)}
                        className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center shadow-md hover:bg-red-600 z-10">
                        <X className="w-3 h-3" />
                      </button>
                    )}
                    {p.caption && <p className="text-xs text-gray-500 mt-1 truncate">{p.caption}</p>}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-gray-400 py-2">No photos for this damage point.</p>
            )}
          </div>
        </div>
        {!readOnly && (
          <div className="px-5 py-4 border-t border-gray-100 dark:border-gray-700 flex gap-3 justify-end">
            <button onClick={onClose} className="btn-secondary">Cancel</button>
            <button onClick={handleSave} className="btn-primary"><Save className="w-4 h-4" /> Save</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Vehicle Diagram ───────────────────────────────────────────────────────────
function VehicleDiagram({ view, markers, onAddMarker, onRemoveMarker, onUpdateMarker, readOnly, vehiclePhoto }) {
  const svgRef = useRef();
  const [adding, setAdding] = useState(false);
  const [addType, setAddType] = useState('dent');

  const handleClick = (e) => {
    if (!adding || readOnly) return;
    const svg = svgRef.current;
    const rect = svg.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width * 200).toFixed(1);
    const y = ((e.clientY - rect.top) / rect.height * 120).toFixed(1);
    onAddMarker({ x: parseFloat(x), y: parseFloat(y), type: addType, id: Date.now() });
    setAdding(false);
  };

  const [selectedMarker, setSelectedMarker] = useState(null);

  const MarkerGroup = ({ m }) => {
    const photoCount = m.photos?.length || 0;
    return (
      <g key={m.id}>
        <circle cx={m.x} cy={m.y} r="7" fill={DAMAGE_TYPES[m.type]?.color || '#ef4444'} opacity="0.9" stroke="white" strokeWidth="1.5"
          className="cursor-pointer" onClick={e => { e.stopPropagation(); setSelectedMarker(m); }} />
        <text x={m.x} y={m.y + 1} textAnchor="middle" dominantBaseline="middle" fontSize="6" fill="white" fontWeight="bold"
          className="cursor-pointer" onClick={e => { e.stopPropagation(); setSelectedMarker(m); }}>
          {m.type?.[0]?.toUpperCase()}
        </text>
        {photoCount > 0 && (
          <g>
            <circle cx={m.x + 8} cy={m.y - 8} r="5" fill="#2563eb" stroke="white" strokeWidth="1"/>
            <text x={m.x + 8} y={m.y - 7} textAnchor="middle" dominantBaseline="middle" fontSize="5" fill="white" fontWeight="bold">{photoCount}</text>
          </g>
        )}
        {!readOnly && (
          <>
            <circle cx={m.x - 8} cy={m.y - 8} r="4" fill="#1f2937" className="cursor-pointer"
              onClick={e => { e.stopPropagation(); onRemoveMarker(m.id); }}/>
            <text x={m.x - 8} y={m.y - 7} textAnchor="middle" dominantBaseline="middle" fontSize="5" fill="white"
              className="cursor-pointer" onClick={e => { e.stopPropagation(); onRemoveMarker(m.id); }}>×</text>
          </>
        )}
      </g>
    );
  };

  const handleMarkerUpdate = (updatedMarker) => {
    if (onUpdateMarker) onUpdateMarker(updatedMarker);
    setSelectedMarker(null);
  };

  const svgProps = {
    ref: svgRef,
    onClick: handleClick,
    style: { cursor: adding ? 'crosshair' : 'default' },
    className: 'w-full'
  };

  // Map left/right to side SVG, with correct placeholder
  const effectiveView = (view === 'left' || view === 'right') ? 'side' : view;

  const outlines = {
    front: (
      <svg viewBox="0 0 200 120" {...svgProps}>
        <image href={vehiclePhoto || PLACEHOLDER_IMAGES['front']} x="0" y="0" width="200" height="120" preserveAspectRatio="xMidYMid meet" />
        {markers.map(m => <MarkerGroup key={m.id} m={m} />)}
      </svg>
    ),
    rear: (
      <svg viewBox="0 0 200 120" {...svgProps}>
        <image href={vehiclePhoto || PLACEHOLDER_IMAGES['rear']} x="0" y="0" width="200" height="120" preserveAspectRatio="xMidYMid meet" />
        {markers.map(m => <MarkerGroup key={m.id} m={m} />)}
      </svg>
    ),
    side: (
      <svg viewBox="0 0 300 120" {...svgProps}>
        <image href={vehiclePhoto || PLACEHOLDER_IMAGES[view === 'right' ? 'right' : 'left']} x="0" y="0" width="300" height="120" preserveAspectRatio="xMidYMid meet" />
        {markers.map(m => <MarkerGroup key={m.id} m={m} />)}
      </svg>
    ),
    top: (
      <svg viewBox="0 0 200 300" className="w-full max-h-64" ref={svgRef} onClick={handleClick} style={{ cursor: adding ? 'crosshair' : 'default' }}>
        <image href={vehiclePhoto || PLACEHOLDER_IMAGES['top']} x="0" y="0" width="200" height="300" preserveAspectRatio="xMidYMid meet" />
        {markers.map(m => <MarkerGroup key={m.id} m={m} />)}
      </svg>
    ),
  };

  return (
    <div className="space-y-3">
      {!readOnly && (
        <div className="flex items-center gap-2 flex-wrap">
          {Object.entries(DAMAGE_TYPES).map(([key, dt]) => (
            <button key={key} onClick={() => { setAdding(true); setAddType(key); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${adding && addType === key ? 'ring-2 ring-offset-1 opacity-100' : 'opacity-70 hover:opacity-100'}`}
              style={{ background: dt.bg, color: dt.color, borderColor: dt.color }}>
              <span className="w-2 h-2 rounded-full" style={{ background: dt.color }} />
              {dt.label}
            </button>
          ))}
          {adding && <button onClick={() => setAdding(false)} className="btn-secondary text-xs py-1">Cancel</button>}
          {adding && <span className="text-xs text-brand-600 font-medium animate-pulse">Click on diagram to place marker</span>}
        </div>
      )}
      {outlines[effectiveView]}
    {selectedMarker && (
      <MarkerDetailModal
        marker={selectedMarker}
        onUpdate={handleMarkerUpdate}
        onClose={() => setSelectedMarker(null)}
        readOnly={readOnly}
      />
    )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function DamagePage() {
  const [inspections, setInspections] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterVehicle, setFilterVehicle] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [deleteId, setDeleteId] = useState(null);
  const [activeView, setActiveView] = useState('front');
  const [vehiclePhotos, setVehiclePhotos] = useState({});
  const { canEdit, isAdmin } = useAuth();
  const toast = useToast();

  const markerKey = { front: 'frontDamageMarkers', rear: 'rearDamageMarkers', left: 'leftDamageMarkers', right: 'rightDamageMarkers', top: 'topDamageMarkers' };

  const parsePhotos = (raw) => {
    if (!raw) return [];
    try { return JSON.parse(raw); } catch { return []; }
  };

  const load = async () => {
    setLoading(true);
    try {
      const params = filterVehicle ? { vehicleId: filterVehicle } : {};
      const [i, v] = await Promise.all([api.get('/damage', { params }), api.get('/vehicles')]);
      setInspections(i.data); setVehicles(v.data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [filterVehicle]);

  const loadVehiclePhotos = (vehicleId) => {
    if (!vehicleId) { setVehiclePhotos({}); return; }
    const v = vehicles.find(v => v.id === parseInt(vehicleId));
    if (v) setVehiclePhotos({ photoFront: v.photoFront, photoRear: v.photoRear, photoLeft: v.photoLeft, photoRight: v.photoRight, photoTop: v.photoTop });
    else setVehiclePhotos({});
  };

  const openNew = () => {
    setForm({ ...EMPTY_FORM, vehicleId: filterVehicle || '' });
    loadVehiclePhotos(filterVehicle);
    setEditing(null); setModalOpen(true); setActiveView('front');
  };

  const openEdit = (insp) => {
    setEditing(insp);
    setForm({
      ...insp,
      inspectionDate: format(new Date(insp.inspectionDate), 'yyyy-MM-dd'),
      frontDamageMarkers: insp.frontDamageMarkers ? JSON.parse(insp.frontDamageMarkers) : [],
      rearDamageMarkers:  insp.rearDamageMarkers  ? JSON.parse(insp.rearDamageMarkers)  : [],
      sideDamageMarkers:  insp.sideDamageMarkers  ? JSON.parse(insp.sideDamageMarkers)  : [],
      leftDamageMarkers:  insp.leftDamageMarkers  ? JSON.parse(insp.leftDamageMarkers)  : [],
      rightDamageMarkers: insp.rightDamageMarkers ? JSON.parse(insp.rightDamageMarkers) : [],
      topDamageMarkers:   insp.topDamageMarkers   ? JSON.parse(insp.topDamageMarkers)   : [],
      photos: parsePhotos(insp.photos),
    });
    loadVehiclePhotos(insp.vehicleId);
    setModalOpen(true); setActiveView('front');
  };

  const openView = (insp) => {
    setViewing(insp);
    const v = vehicles.find(v => v.id === insp.vehicleId);
    const vp = v ? { photoFront: v.photoFront, photoRear: v.photoRear, photoLeft: v.photoLeft, photoRight: v.photoRight, photoTop: v.photoTop } : {};
    setViewing({ ...insp, _vehiclePhotos: vp });
    setViewOpen(true);
  };

  const addMarker = (view, marker) => {
    const key = markerKey[view];
    setForm(f => ({ ...f, [key]: [...(f[key] || []), marker] }));
  };
  const removeMarker = (view, id) => {
    const key = markerKey[view];
    setForm(f => ({ ...f, [key]: (f[key] || []).filter(m => m.id !== id) }));
  };

  const updateMarker = (view, updatedMarker) => {
    const key = markerKey[view];
    setForm(f => ({ ...f, [key]: (f[key] || []).map(m => m.id === updatedMarker.id ? updatedMarker : m) }));
  };

  const handleSave = async () => {
    if (!form.vehicleId || !form.inspectorName) return toast.error('Vehicle and inspector name are required');
    try {
      if (editing) { await api.put(`/damage/${editing.id}`, form); toast.success('Inspection updated'); }
      else { await api.post('/damage', form); toast.success('Inspection saved'); }
      setModalOpen(false); load();
    } catch (err) { toast.error(err.response?.data?.error || 'Save failed'); }
  };

  const handleDelete = async () => {
    try { await api.delete(`/damage/${deleteId}`); toast.success('Inspection deleted'); load(); }
    catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const totalMarkers = (insp) =>
    ['frontDamageMarkers','rearDamageMarkers','sideDamageMarkers','leftDamageMarkers','rightDamageMarkers','topDamageMarkers']
      .reduce((s, k) => { try { return s + JSON.parse(insp[k] || '[]').length; } catch { return s; } }, 0);

  const photoCount = (insp) => { try { return JSON.parse(insp.photos || '[]').length; } catch { return 0; } };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Damage Inspection" subtitle="Vehicle damage marking and photo documentation"
        actions={<>
          <button onClick={() => window.print()} className="btn-secondary no-print"><Printer className="w-4 h-4" /> Print</button>
          {canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> New Inspection</button>}
        </>}
      />

      {/* Filter */}
      <div className="mb-4 no-print">
        <select className="form-select w-64" value={filterVehicle} onChange={e => setFilterVehicle(e.target.value)}>
          <option value="">All Vehicles</option>
          {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
        </select>
      </div>

      {loading ? <LoadingSpinner /> : inspections.length === 0 ? (
        <EmptyState icon={Shield} title="No inspections" message="Create your first damage inspection."
          action={canEdit && <button onClick={openNew} className="btn-primary"><Plus className="w-4 h-4" /> New Inspection</button>} />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-100 dark:border-gray-700">
                  {['Date','Vehicle','Inspector','Mileage','Damage','Photos','Notes',''].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                {inspections.map((insp, i) => (
                  <tr key={insp.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${i % 2 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''}`}>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400 whitespace-nowrap">{format(new Date(insp.inspectionDate), 'dd MMM yyyy')}</td>
                    <td className="px-4 py-3 font-mono text-xs font-medium text-brand-700 dark:text-brand-400">{insp.vehicle?.vehicleId}</td>
                    <td className="px-4 py-3 text-gray-700 dark:text-gray-300">{insp.inspectorName}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{insp.mileage ? `${insp.mileage.toLocaleString()} km` : '—'}</td>
                    <td className="px-4 py-3">
                      {totalMarkers(insp) > 0
                        ? <span className="badge-red">{totalMarkers(insp)} markers</span>
                        : <span className="badge-green">No damage</span>}
                    </td>
                    <td className="px-4 py-3">
                      {photoCount(insp) > 0
                        ? <span className="badge-blue flex items-center gap-1 w-fit"><Camera className="w-3 h-3" />{photoCount(insp)} photo{photoCount(insp) > 1 ? 's' : ''}</span>
                        : <span className="text-gray-400 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400 max-w-xs truncate">{insp.damageNotes || '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => openView(insp)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg text-gray-500 transition-colors" title="View"><Shield className="w-4 h-4" /></button>
                        {canEdit && <button onClick={() => openEdit(insp)} className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg text-gray-500 hover:text-blue-600 transition-colors" title="Edit"><Edit2 className="w-4 h-4" /></button>}
                        {isAdmin && <button onClick={() => setDeleteId(insp.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg text-gray-500 hover:text-red-600 transition-colors" title="Delete"><Trash2 className="w-4 h-4" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Damage Inspection' : 'New Damage Inspection'} size="xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left column: form fields + photos */}
          <div className="space-y-4">
            <div>
              <label className="form-label">Vehicle *</label>
              <select className="form-select" value={form.vehicleId} onChange={e => { setForm(f => ({ ...f, vehicleId: e.target.value })); loadVehiclePhotos(e.target.value); }} required>
                <option value="">Select vehicle...</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.vehicleId} — {v.make} {v.model}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="form-label">Date</label>
                <input className="form-input" type="date" value={form.inspectionDate} onChange={e => setForm(f => ({ ...f, inspectionDate: e.target.value }))} />
              </div>
              <div>
                <label className="form-label">Mileage</label>
                <input className="form-input" type="number" value={form.mileage} onChange={e => setForm(f => ({ ...f, mileage: e.target.value }))} />
              </div>
            </div>
            <div>
              <label className="form-label">Inspector Name *</label>
              <input className="form-input" value={form.inspectorName} onChange={e => setForm(f => ({ ...f, inspectorName: e.target.value }))} />
            </div>
            <div>
              <label className="form-label">Damage Notes</label>
              <textarea className="form-input h-16 resize-none" value={form.damageNotes} onChange={e => setForm(f => ({ ...f, damageNotes: e.target.value }))} placeholder="Describe any damage found..." />
            </div>
            <div>
              <label className="form-label">Signature</label>
              <input className="form-input" value={form.signature} onChange={e => setForm(f => ({ ...f, signature: e.target.value }))} placeholder="Type full name as signature" />
            </div>

            {/* Photos */}
            <div>
              <label className="form-label flex items-center gap-2">
                <Camera className="w-4 h-4 text-gray-400" />
                Damage Photos
                {form.photos.length > 0 && <span className="badge-blue ml-1">{form.photos.length}</span>}
              </label>
              <PhotoUploader
                photos={form.photos}
                onChange={(updater) => setForm(f => ({ ...f, photos: typeof updater === 'function' ? updater(f.photos) : updater }))}
              />
            </div>
          </div>

          {/* Right column: vehicle diagram */}
          <div className="space-y-3">
            <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-lg">
              {['front','rear','side','top'].map(v => (
                <button key={v} onClick={() => setActiveView(v)}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all capitalize ${activeView === v ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
                  {v}
                </button>
              ))}
            </div>

            {/* Photo upload hint — only show if no custom photo uploaded */}
            {!vehiclePhotos[VIEW_PHOTO_MAP[activeView]] && (
              <div className="flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2">
                <Camera className="w-3.5 h-3.5 flex-shrink-0" />
                Showing default outline. Upload a real photo of this vehicle in the <strong>Vehicles</strong> page to use it here.
              </div>
            )}
            {/* Legend */}
            <div className="flex gap-2 flex-wrap">
              {Object.entries(DAMAGE_TYPES).map(([k, v]) => (
                <div key={k} className="flex items-center gap-1 text-xs px-2 py-1 rounded" style={{ background: v.bg, color: v.color }}>
                  <span className="w-2 h-2 rounded-full" style={{ background: v.color }} />{v.label}
                </div>
              ))}
            </div>

            <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-4">
              <VehicleDiagram
                view={activeView}
                markers={form[markerKey[activeView]] || []}
                onAddMarker={(m) => addMarker(activeView, { ...m, timestamp: new Date().toISOString(), photos: [], notes: '' })}
                onRemoveMarker={(id) => removeMarker(activeView, id)}
                onUpdateMarker={(updated) => updateMarker(activeView, updated)}
                vehiclePhoto={vehiclePhotos[VIEW_PHOTO_MAP[activeView]]}
              />
            </div>
            <div className="text-xs text-gray-500 text-center">
              Total damage markers: {['front','rear','left','right','top'].reduce((s, v) => s + (form[markerKey[v]]?.length || 0), 0)}
            </div>
          </div>
        </div>

        <div className="flex gap-3 justify-end mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
          <button onClick={() => setModalOpen(false)} className="btn-secondary">Cancel</button>
          <button onClick={handleSave} className="btn-primary"><Save className="w-4 h-4" /> {editing ? 'Save Changes' : 'Save Inspection'}</button>
        </div>
      </Modal>

      {/* View Modal */}
      <Modal open={viewOpen} onClose={() => setViewOpen(false)} title="Damage Inspection Report" size="xl">
        {viewing && <DamageViewReport inspection={viewing} />}
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Inspection" message="Are you sure you want to delete this inspection?" danger />
    </div>
  );
}

// ── View Report ───────────────────────────────────────────────────────────────
function DamageViewReport({ inspection }) {
  const [activeView, setActiveView] = useState('front');
  const markerKey = { front: 'frontDamageMarkers', rear: 'rearDamageMarkers', left: 'leftDamageMarkers', right: 'rightDamageMarkers', top: 'topDamageMarkers' };
  const getMarkers = (k) => { try { return JSON.parse(inspection[k] || '[]'); } catch { return []; } };
  const photos = (() => { try { return JSON.parse(inspection.photos || '[]'); } catch { return []; } })();
  const vehiclePhotos = inspection._vehiclePhotos || {};

  return (
    <div className="space-y-5">
      {/* Info grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ['Date', format(new Date(inspection.inspectionDate), 'dd MMM yyyy')],
          ['Inspector', inspection.inspectorName],
          ['Mileage', inspection.mileage ? `${inspection.mileage.toLocaleString()} km` : '—'],
          ['Vehicle', inspection.vehicle?.vehicleId],
        ].map(([l, v]) => (
          <div key={l} className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3">
            <div className="text-xs text-gray-500 mb-0.5">{l}</div>
            <div className="text-sm font-medium text-gray-900 dark:text-white">{v}</div>
          </div>
        ))}
      </div>

      {inspection.damageNotes && (
        <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-3">
          <div className="text-xs font-medium text-orange-700 dark:text-orange-400 mb-1">Damage Notes</div>
          <p className="text-sm text-orange-900 dark:text-orange-300">{inspection.damageNotes}</p>
        </div>
      )}

      {/* Diagram */}
      <div>
        <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-lg mb-3">
          {[['front','Front'],['rear','Rear'],['left','Left'],['right','Right'],['top','Top']].map(([v, label]) => (
            <button key={v} onClick={() => setActiveView(v)}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${activeView === v ? 'bg-white dark:bg-gray-600 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500'}`}>
              {label} ({getMarkers(markerKey[v]).length})
            </button>
          ))}
        </div>
        <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-4">
          <VehicleDiagram view={activeView} markers={getMarkers(markerKey[activeView])} readOnly onUpdateMarker={null} vehiclePhoto={vehiclePhotos[VIEW_PHOTO_MAP[activeView]]} />
        </div>
      </div>

      {/* Photos */}
      {photos.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <Camera className="w-4 h-4 text-gray-400" /> Damage Photos ({photos.length})
          </h4>
          <PhotoUploader photos={photos} onChange={() => {}} readOnly />
        </div>
      )}

      {inspection.signature && (
        <div className="text-right text-sm text-gray-500 pt-2 border-t border-gray-100 dark:border-gray-700">
          Signed: <span className="font-medium text-gray-900 dark:text-white italic">{inspection.signature}</span>
        </div>
      )}
    </div>
  );
}
