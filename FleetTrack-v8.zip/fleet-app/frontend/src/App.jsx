import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { DarkModeProvider } from './context/DarkModeContext';
import { BrandingProvider } from './context/BrandingContext';
import Layout from './components/layout/Layout';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import VehiclesPage from './pages/VehiclesPage';
import RepairsPage from './pages/RepairsPage';
import DamagePage from './pages/DamagePage';
import EquipmentPage from './pages/EquipmentPage';
import WeeklyLogsPage from './pages/WeeklyLogsPage';
import HistoryPage from './pages/HistoryPage';
import UserManagementPage from './pages/admin/UserManagementPage';
import BackupPage from './pages/admin/BackupPage';
import BrandingPage from './pages/admin/BrandingPage';
import EmployeeListPage from './pages/employees/EmployeeListPage';
import EmployeeProfilePage from './pages/employees/EmployeeProfilePage';

function ProtectedRoute({ children, requireVehicles, requireEmployees, adminOnly }) {
  const { user, canAccessVehicles, canAccessEmployees } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/" replace />;
  if (requireVehicles  && !canAccessVehicles)  return <Navigate to="/" replace />;
  if (requireEmployees && !canAccessEmployees) return <Navigate to="/" replace />;
  return <Layout>{children}</Layout>;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />

      <Route path="/vehicles"    element={<ProtectedRoute requireVehicles><VehiclesPage /></ProtectedRoute>} />
      <Route path="/repairs"     element={<ProtectedRoute requireVehicles><RepairsPage /></ProtectedRoute>} />
      <Route path="/damage"      element={<ProtectedRoute requireVehicles><DamagePage /></ProtectedRoute>} />
      <Route path="/equipment"   element={<ProtectedRoute requireVehicles><EquipmentPage /></ProtectedRoute>} />
      <Route path="/weekly-logs" element={<ProtectedRoute requireVehicles><WeeklyLogsPage /></ProtectedRoute>} />
      <Route path="/history"     element={<ProtectedRoute requireVehicles><HistoryPage /></ProtectedRoute>} />

      <Route path="/employees"     element={<ProtectedRoute requireEmployees><EmployeeListPage /></ProtectedRoute>} />
      <Route path="/employees/:id" element={<ProtectedRoute requireEmployees><EmployeeProfilePage /></ProtectedRoute>} />

      <Route path="/admin/users"    element={<ProtectedRoute adminOnly><UserManagementPage /></ProtectedRoute>} />
      <Route path="/admin/backup"   element={<ProtectedRoute adminOnly><BackupPage /></ProtectedRoute>} />
      <Route path="/admin/branding" element={<ProtectedRoute adminOnly><BrandingPage /></ProtectedRoute>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <DarkModeProvider>
      <BrandingProvider>
        <AuthProvider>
          <ToastProvider>
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </ToastProvider>
        </AuthProvider>
      </BrandingProvider>
    </DarkModeProvider>
  );
}
