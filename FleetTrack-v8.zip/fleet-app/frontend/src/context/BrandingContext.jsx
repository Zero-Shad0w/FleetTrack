import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

const BrandingContext = createContext(null);

// Convert hex to HSL for CSS variable generation
function hexToHsl(hex) {
  let r = parseInt(hex.slice(1,3),16)/255;
  let g = parseInt(hex.slice(3,5),16)/255;
  let b = parseInt(hex.slice(5,7),16)/255;
  const max = Math.max(r,g,b), min = Math.min(r,g,b);
  let h, s, l = (max+min)/2;
  if (max === min) { h = s = 0; }
  else {
    const d = max - min;
    s = l > 0.5 ? d/(2-max-min) : d/(max+min);
    switch(max) {
      case r: h = ((g-b)/d + (g<b?6:0))/6; break;
      case g: h = ((b-r)/d + 2)/6; break;
      case b: h = ((r-g)/d + 4)/6; break;
    }
  }
  return [Math.round(h*360), Math.round(s*100), Math.round(l*100)];
}

// Generate a palette of shades from a base color
function generateShades(hex) {
  const [h, s] = hexToHsl(hex);
  return {
    50:  `hsl(${h},${Math.min(s+20,100)}%,97%)`,
    100: `hsl(${h},${Math.min(s+15,100)}%,93%)`,
    200: `hsl(${h},${Math.min(s+10,100)}%,85%)`,
    300: `hsl(${h},${s}%,72%)`,
    400: `hsl(${h},${s}%,60%)`,
    500: `hsl(${h},${s}%,50%)`,
    600: hex,
    700: `hsl(${h},${Math.min(s+5,100)}%,38%)`,
    800: `hsl(${h},${Math.min(s+8,100)}%,28%)`,
    900: `hsl(${h},${Math.min(s+10,100)}%,18%)`,
  };
}

// Extract dominant colors from image using canvas
export async function extractColorsFromImage(dataUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 50; canvas.height = 50;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, 50, 50);
        const data = ctx.getImageData(0, 0, 50, 50).data;

        // Collect non-transparent, non-white, non-black pixels
        const colorMap = {};
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i], g = data[i+1], b = data[i+2], a = data[i+3];
          if (a < 128) continue; // transparent
          const brightness = (r+g+b)/3;
          if (brightness > 230 || brightness < 25) continue; // white/black
          const key = `${Math.round(r/20)*20},${Math.round(g/20)*20},${Math.round(b/20)*20}`;
          colorMap[key] = (colorMap[key] || 0) + 1;
        }

        const sorted = Object.entries(colorMap).sort((a,b) => b[1]-a[1]);
        if (sorted.length === 0) { resolve(null); return; }

        const [r,g,b] = sorted[0][0].split(',').map(Number);
        const primary = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;

        // Secondary from second most common color
        let secondary = primary;
        if (sorted.length > 1) {
          const [r2,g2,b2] = sorted[1][0].split(',').map(Number);
          secondary = `#${r2.toString(16).padStart(2,'0')}${g2.toString(16).padStart(2,'0')}${b2.toString(16).padStart(2,'0')}`;
        }

        const [h,s,l] = hexToHsl(primary);
        const darker  = `hsl(${h},${Math.min(s+5,100)}%,${Math.max(l-15,10)}%)`;
        const lighter = `hsl(${h},${s}%,${Math.min(l+10,90)}%)`;

        resolve({ primary, secondary, darker, lighter });
      } catch { resolve(null); }
    };
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

// Apply branding CSS variables to document root
function applyBrandingToDom(branding, isDark) {
  const root = document.documentElement;
  const primary = isDark ? (branding.darkPrimary || branding.primaryColor) : branding.primaryColor;
  const shades  = generateShades(primary);

  Object.entries(shades).forEach(([shade, val]) => {
    root.style.setProperty(`--brand-${shade}`, val);
  });

  // Also update Tailwind brand- classes via CSS variable bridge
  root.style.setProperty('--color-brand-50',  shades[50]);
  root.style.setProperty('--color-brand-100', shades[100]);
  root.style.setProperty('--color-brand-200', shades[200]);
  root.style.setProperty('--color-brand-300', shades[300]);
  root.style.setProperty('--color-brand-400', shades[400]);
  root.style.setProperty('--color-brand-500', shades[500]);
  root.style.setProperty('--color-brand-600', shades[600]);
  root.style.setProperty('--color-brand-700', shades[700]);
  root.style.setProperty('--color-brand-800', shades[800]);
  root.style.setProperty('--color-brand-900', shades[900]);

  // Sidebar and header colors
  if (!isDark && branding.sidebarColor) {
    root.style.setProperty('--sidebar-bg', branding.sidebarColor);
  } else if (isDark && branding.darkSidebar) {
    root.style.setProperty('--sidebar-bg', branding.darkSidebar);
  }
}

export const BrandingProvider = ({ children }) => {
  const [branding, setBranding] = useState({
    softwareName: 'FleetTrack Pro',
    primaryColor: '#e63854', secondaryColor: '#b91c37', accentColor: '#27d3e9',
    sidebarColor: '#ffffff', textColor: '#111827', darkPrimary: '#ff4968', darkSidebar: '#0a1020',
    logoData: null, hasLogo: false,
  });
  const [loading, setLoading] = useState(true);
  const isDark = document.documentElement.classList.contains('dark');

  const loadBranding = useCallback(async () => {
    try {
      const { data } = await api.get('/branding/full');
      setBranding(data);
      applyBrandingToDom(data, isDark);
    } catch {
      // Use defaults if not logged in yet
      try {
        const { data } = await api.get('/branding');
        setBranding(prev => ({ ...prev, ...data }));
        applyBrandingToDom({ ...branding, ...data }, isDark);
      } catch { /* silently use defaults */ }
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadBranding(); }, []);

  // Re-apply when dark mode changes
  useEffect(() => {
    applyBrandingToDom(branding, isDark);
  }, [isDark, branding]);

  const updateBranding = async (newData) => {
    const { data } = await api.put('/branding', newData);
    // Fetch full branding with logo
    const full = await api.get('/branding/full');
    setBranding(full.data);
    applyBrandingToDom(full.data, isDark);
    return full.data;
  };

  const removeLogo = async () => {
    await api.delete('/branding/logo');
    setBranding(prev => ({ ...prev, logoData: null, hasLogo: false }));
  };

  return (
    <BrandingContext.Provider value={{ branding, loading, updateBranding, removeLogo, loadBranding }}>
      {children}
    </BrandingContext.Provider>
  );
};

export const useBranding = () => useContext(BrandingContext);
