import React, { createContext, useContext, useState } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('fleet_user');
    try { return stored ? JSON.parse(stored) : null; } catch { localStorage.removeItem('fleet_user'); return null; }
  });

  const login = async (username, password) => {
    const { data } = await api.post('/auth/login', { username, password });
    localStorage.setItem('fleet_token', data.token);
    localStorage.setItem('fleet_user', JSON.stringify(data.user));
    setUser(data.user);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('fleet_token');
    localStorage.removeItem('fleet_user');
    setUser(null);
  };

  // Role helpers
  const isAdmin       = user?.role === 'admin';
  const isInspector   = user?.role === 'inspector';
  const isCoordinator = user?.role === 'coordinator';
  const isManager     = user?.role === 'manager';
  const isViewer      = user?.role === 'viewer';

  // Feature access
  const canAccessVehicles   = ['admin','inspector','manager','viewer'].includes(user?.role);
  const canAccessEmployees  = ['admin','coordinator','manager','viewer'].includes(user?.role);
  const canEdit             = ['admin','inspector','manager','coordinator'].includes(user?.role);
  const canEditVehicles     = ['admin','inspector','manager'].includes(user?.role);
  const canEditEmployees    = ['admin','coordinator','manager'].includes(user?.role);
  const canDelete           = user?.role === 'admin';
  const canSeeSalary        = ['admin','manager'].includes(user?.role);
  const canSeeWarnings      = ['admin','manager','coordinator'].includes(user?.role);
  const canSeeComplaints    = ['admin','manager','coordinator'].includes(user?.role);
  const canManageUsers      = user?.role === 'admin';
  const canManageBackup     = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{
      user, login, logout,
      isAdmin, isInspector, isCoordinator, isManager, isViewer,
      canAccessVehicles, canAccessEmployees,
      canEdit, canEditVehicles, canEditEmployees,
      canDelete, canSeeSalary, canSeeWarnings, canSeeComplaints,
      canManageUsers, canManageBackup,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
