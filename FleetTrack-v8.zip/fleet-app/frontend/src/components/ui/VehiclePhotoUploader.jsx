import React, { useRef } from 'react';
import { Camera, X, ImagePlus } from 'lucide-react';
import PLACEHOLDER_IMAGES from '../../utils/placeholderImages';

const VIEWS = [
  { key: 'photoFront', label: 'Front',  icon: '⬆', placeholder: 'front' },
  { key: 'photoRear',  label: 'Rear',   icon: '⬇', placeholder: 'rear'  },
  { key: 'photoLeft',  label: 'Left',   icon: '⬅', placeholder: 'left'  },
  { key: 'photoRight', label: 'Right',  icon: '➡', placeholder: 'right' },
  { key: 'photoTop',   label: 'Top',    icon: '⊕', placeholder: 'top'   },
];

export { VIEWS };

export default function VehiclePhotoUploader({ photos, onChange, compact = false }) {
  const inputRefs = useRef({});

  const handleFile = (key, e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    if (file.size > 15 * 1024 * 1024) { alert('Image too large — max 15MB'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => onChange(key, ev.target.result);
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const clearPhoto = (key, e) => {
    e.stopPropagation();
    onChange(key, null);
  };

  if (compact) {
    // Small thumbnails for view-only / history
    return (
      <div className="flex gap-2 flex-wrap">
        {VIEWS.map(({ key, label }) =>
          photos[key] ? (
            <div key={key} className="relative group">
              <img src={photos[key]} alt={label}
                className="w-16 h-16 object-cover rounded-lg border border-gray-200 dark:border-gray-600" />
              <span className="absolute bottom-0 left-0 right-0 text-center text-white text-xs bg-black/50 rounded-b-lg py-0.5">{label}</span>
            </div>
          ) : null
        )}
        {VIEWS.every(v => !photos[v.key]) && (
          <span className="text-xs text-gray-400 py-2">No vehicle photos uploaded</span>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
      {VIEWS.map(({ key, label, icon, placeholder }) => (
        <div key={key} className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-gray-600 dark:text-gray-400 text-center">{icon} {label}</span>
          <input
            ref={el => inputRefs.current[key] = el}
            type="file" accept="image/*" className="hidden"
            onChange={e => handleFile(key, e)}
          />
          {photos[key] ? (
            <div className="relative group aspect-[4/3] rounded-xl overflow-hidden border-2 border-brand-300 dark:border-brand-600 cursor-pointer"
              onClick={() => inputRefs.current[key]?.click()}>
              <img src={photos[key]} alt={label} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
                <Camera className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-all" />
              </div>
              <button
                type="button"
                onClick={e => clearPhoto(key, e)}
                className="absolute top-1 right-1 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-colors z-10">
                <X className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => inputRefs.current[key]?.click()}
              className="relative aspect-[4/3] rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-brand-400 dark:hover:border-brand-500 transition-all overflow-hidden group">
              {/* Placeholder outline image */}
              <img
                src={PLACEHOLDER_IMAGES[placeholder]}
                alt={label}
                className="w-full h-full object-contain opacity-30 dark:opacity-20 bg-gray-100 dark:bg-gray-800"
              />
              {/* Overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 text-gray-500 dark:text-gray-400 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                <div className="bg-white/80 dark:bg-gray-800/80 rounded-lg px-2 py-1 flex flex-col items-center gap-1">
                  <ImagePlus className="w-5 h-5" />
                  <span className="text-xs font-semibold">Add Photo</span>
                </div>
              </div>
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
