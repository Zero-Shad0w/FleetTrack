import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const backendPort = Number(process.env.FLEET_BACKEND_PORT || process.env.PORT_BACKEND || 3001)
const frontendPort = Number(process.env.FLEET_FRONTEND_PORT || 5173)

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: frontendPort,
    strictPort: true,
    proxy: { '/api': { target: `http://127.0.0.1:${backendPort}`, changeOrigin: true } }
  }
})
