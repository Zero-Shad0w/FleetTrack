@echo off
setlocal
cd /d "%~dp0"
call npm install || goto :fail
cd backend
call npm install || goto :fail
call npx prisma generate || goto :fail
cd ..
cd frontend
call npm install || goto :fail
cd ..
call npm run dist:win || goto :fail
echo Installer created under installer-output
pause
exit /b 0
:fail
echo BUILD FAILED. Read errors above.
pause
exit /b 1
