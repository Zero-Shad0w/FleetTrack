@echo off
setlocal EnableExtensions
title FleetTrack Pro - One Click Windows Installer Builder
cd /d "%~dp0"
echo ============================================================
echo     FLEETTRACK PRO - WINDOWS INSTALLER BUILDER
echo ============================================================
echo.
where node >nul 2>&1 || goto :missing_node
where npm >nul 2>&1 || goto :missing_node
for /f "tokens=1 delims=." %%V in ('node -p "process.versions.node"') do set "NODE_MAJOR=%%V"
if %NODE_MAJOR% LSS 20 goto :old_node
echo Node:
node --version
echo.
where py >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%P in ('py -3.11 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON=%%P"
)
if defined PYTHON echo Python: %PYTHON%
echo.
echo [1/5] Installing desktop dependencies...
call npm install || goto :fail
echo.
echo [2/5] Installing backend dependencies...
pushd backend || goto :fail
call npm install
if errorlevel 1 (popd & goto :fail)
echo.
echo [3/5] Generating Prisma client...
call npx prisma generate
if errorlevel 1 (popd & goto :fail)
popd
echo.
echo [4/5] Installing frontend dependencies...
pushd frontend || goto :fail
call npm install
if errorlevel 1 (popd & goto :fail)
popd
echo.
echo [5/5] Building Windows installer...
call npm run dist:win || goto :fail
echo.
echo ============================================================
echo SUCCESS! Opening the installer folder...
echo ============================================================
if exist "installer-output" start "" explorer.exe "%CD%\installer-output"
pause
exit /b 0
:missing_node
echo ERROR: Node.js and npm are required. Install Node.js 22 LTS.
goto :fail
:old_node
echo ERROR: Node.js 20 or newer required; Node.js 22 recommended.
goto :fail
:fail
echo.
echo BUILD FAILED. Copy the last error lines and send them to ChatGPT.
pause
exit /b 1
